import {
  closeQueue,
  clearAllPlayerTiers,
  clearPlayerTiers,
  completeRestriction,
  createRestriction,
  createTicket,
  createApplication,
  findActiveRestriction,
  findActiveKitCooldown,
  getDueRestrictions,
  getState,
  assertKitCooldownAvailable,
  isDiscordUserRestricted,
  isMinecraftUserRestricted,
  joinTester,
  joinQueue,
  leaveQueue,
  leaveTester,
  nextTicket,
  openQueue,
  queueTicketForChannel,
  saveState,
  setQueueTicketChannel,
  setManualTiers,
  skipTicket,
  submitResult,
  recordTesterRun,
  getTestingLeaderboard,
  ticketForChannel,
  updateTicket,
  updateApplication,
  verifyAccount,
  type NexusRestriction,
  ApplicationType,
  NexusApplication,
  NexusTicket,
  KITS,
  KIT_LABELS,
  NEXUS_SUBTIERS_GUILD_ID,
  NEXUS_TIERS_GUILD_ID,
  getKitsForGuild,
  isKitAllowedInGuild,
  isNexusTestingGuild,
  TIERS,
  TicketType,
  removeKitCooldown,
  setKitCooldownDuration,
} from "./nexus";
import { logger } from "./logger";

function requireNexusTestingGuild(guildId: string | undefined): string {
  if (!guildId || !isNexusTestingGuild(guildId)) {
    throw new Error("Test requests are only available in NexusTiers and Nexus Subtiers.");
  }
  return guildId;
}

function assertKitAssignedToGuild(guildId: string, kit: string) {
  if (!isKitAllowedInGuild(guildId, kit)) {
    throw new Error(`The ${kit} kit is not available in this Discord server.`);
  }
}

type GatewaySocket = {
  addEventListener: (
    type: string,
    listener: (event: {
      data?: string;
      code?: number;
      reason?: string;
      error?: unknown;
    }) => void,
  ) => void;
  send: (data: string) => void;
  close: () => void;
};
type DiscordOption = {
  name: string;
  value?: string;
  type?: number;
  options?: DiscordOption[];
};
type DiscordComponent = {
  type?: number;
  custom_id?: string;
  value?: string;
  label?: string;
  style?: number;
  min_length?: number;
  max_length?: number;
  required?: boolean;
  placeholder?: string;
  min_values?: number;
  max_values?: number;
  components?: DiscordComponent[];
  options?: Array<{
    label: string;
    value: string;
    description?: string;
    default?: boolean;
  }>;
  disabled?: boolean;
};
type DiscordInteraction = {
  id: string;
  token: string;
  guild_id?: string;
  channel_id?: string;
  member?: {
    user?: { id: string; username: string };
    roles?: string[];
    permissions?: string;
  };
  user?: { id: string; username: string };
  data?: {
    name?: string;
    options?: DiscordOption[];
    custom_id?: string;
    component_type?: number;
    components?: DiscordComponent[];
    values?: string[];
  };
};
type DiscordGuildMember = {
  guild_id?: string;
  user?: { id: string; username?: string };
  roles?: string[];
  premium_since?: string | null;
};
type DiscordRole = {
  id: string;
  name: string;
  managed?: boolean;
  position?: number;
  color?: number;
};
type DiscordMessage = {
  id: string;
  channel_id: string;
  channel_type?: number;
  guild_id?: string;
  content?: string;
  author?: { id: string; bot?: boolean; username?: string };
};
type DiscordChannel = {
  id: string;
  name?: string;
  type?: number;
  parent_id?: string | null;
  guild_id?: string;
  permission_overwrites?: Array<{
    id: string;
    type: number;
    allow: string;
    deny: string;
  }>;
};

type NexusChannelSpec = {
  name: string;
  type: 0 | 2;
};
type NexusChannelCategorySpec = {
  name: string;
  channels: NexusChannelSpec[];
};

const NEXUS_CHANNEL_LAYOUT: NexusChannelCategorySpec[] = [
  {
    name: "🔸 Server",
    channels: [
      { name: "❓│faq", type: 0 },
      { name: "📕│server-rules", type: 0 },
      { name: "📢│announcements", type: 0 },
      { name: "🚨│advertisement", type: 0 },
      { name: "💖│kindness", type: 0 },
      { name: "👥│member-count", type: 0 },
      { name: "🔗│discord-invite", type: 0 },
    ],
  },
  {
    name: "📄 Tierlist",
    channels: [
      { name: "📖│ranked-rubric", type: 0 },
      { name: "📖│ranked-rules", type: 0 },
      { name: "❌│punishments", type: 0 },
      { name: "🥇│testing-leaderboard", type: 0 },
      { name: "🏆│high-results", type: 0 },
      { name: "🏆│results", type: 0 },
      { name: "📋│form-posting", type: 0 },
    ],
  },
  {
    name: "🔹 General",
    channels: [
      { name: "💬│general", type: 0 },
      { name: "📸│media", type: 0 },
      { name: "🦌│pets", type: 0 },
      { name: "🚩│your-videos", type: 0 },
      { name: "🔧│commands-music", type: 0 },
    ],
  },
  {
    name: "🎁 Fun",
    channels: [
      { name: "🔔│poll-pings", type: 0 },
      { name: "📊│poll-of-the-day", type: 0 },
      { name: "💭│poll-discuss", type: 0 },
    ],
  },
  {
    name: "📩 Requests",
    channels: [
      { name: "📨│request-test", type: 0 },
      { name: "📫│request-support", type: 0 },
      { name: "❌│report-staff", type: 0 },
    ],
  },
  {
    name: "🔊 Voice Channels",
    channels: [
      { name: "🍵 Lounge", type: 2 },
      { name: "🍵 Lounge 2", type: 2 },
    ],
  },
];

const rest = (path: string, init: RequestInit = {}) => {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) throw new Error("DISCORD_BOT_TOKEN is not configured.");
  return fetch(`https://discord.com/api/v10${path}`, {
    ...init,
    headers: {
      Authorization: `Bot ${token}`,
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
};

async function findMinecraftJavaProfile(ign: string): Promise<string> {
  const username = ign.trim();
  if (!/^[A-Za-z0-9_]{3,16}$/.test(username)) {
    throw new Error(
      "Please enter a valid Minecraft Java username (3–16 characters; letters, numbers, and underscores only).",
    );
  }

  let response: Response;
  try {
    response = await fetch(
      `https://api.mojang.com/users/profiles/minecraft/${encodeURIComponent(username)}`,
      {
        headers: { Accept: "application/json" },
        signal: AbortSignal.timeout(5_000),
      },
    );
  } catch {
    throw new Error(
      "The Minecraft profile service is temporarily unavailable. Your account was not verified; please try again shortly.",
    );
  }

  if (response.status === 204 || response.status === 404) {
    throw new Error(
      `No Minecraft Java profile was found for **${username}**. Check the spelling and try again.`,
    );
  }
  if (!response.ok) {
    throw new Error(
      "Minecraft account verification is temporarily unavailable. Your account was not verified; please try again shortly.",
    );
  }

  let profile: unknown;
  try {
    profile = await response.json();
  } catch {
    throw new Error(
      "The Minecraft profile service returned an invalid response. Please try again later.",
    );
  }

  if (
    !profile ||
    typeof profile !== "object" ||
    !("id" in profile) ||
    !("name" in profile) ||
    typeof profile.id !== "string" ||
    !/^[a-f0-9]{32}$/i.test(profile.id) ||
    typeof profile.name !== "string" ||
    !/^[A-Za-z0-9_]{3,16}$/.test(profile.name)
  ) {
    throw new Error(
      "The Minecraft profile service returned an invalid profile. Please try again later.",
    );
  }

  return profile.name;
}

const deferredInteractionIds = new Set<string>();

async function createTicketChannel(
  guildId: string,
  kit: string,
  playerUsername: string,
  testerUsername: string,
  playerUserId: string,
  testerUserId: string,
  botUserId?: string,
) {
  const safePlayer = playerUsername
    .toLowerCase()
    .replace(/[^a-z0-9-]/g, "-")
    .slice(0, 24);
  const categoryResponse = await rest(`/guilds/${guildId}/channels`);
  const guildChannels = categoryResponse.ok
    ? ((await categoryResponse.json()) as Array<{
        id: string;
        name: string;
        type?: number;
      }>)
    : [];
  let ticketsCategory = guildChannels.find(
    (channel) =>
      channel.type === 4 &&
      (channel.name === "Tickets" || channel.name === "🎫・Tickets"),
  );
  if (!ticketsCategory) {
    const createCategoryResponse = await rest(`/guilds/${guildId}/channels`, {
      method: "POST",
      body: JSON.stringify({ name: "Tickets", type: 4 }),
    });
    if (!createCategoryResponse.ok) {
      throw new Error(
        `Could not create the Tickets category: ${createCategoryResponse.status}`,
      );
    }
    ticketsCategory = (await createCategoryResponse.json()) as {
      id: string;
      name: string;
      type?: number;
    };
  }
  const response = await rest(`/guilds/${guildId}/channels`, {
    method: "POST",
    body: JSON.stringify({
      name: `🎫・ticket-${kit}-${safePlayer}`,
      type: 0,
      ...(ticketsCategory ? { parent_id: ticketsCategory.id } : {}),
      topic: `NexusTiers ${kit} ticket • player ${playerUsername} • tester ${testerUsername}`,
      permission_overwrites: [
        { id: guildId, type: 0, deny: "1024" },
        { id: playerUserId, type: 1, allow: "68608" },
        { id: testerUserId, type: 1, allow: "68608" },
        ...(botUserId ? [{ id: botUserId, type: 1, allow: "68608" }] : []),
      ],
    }),
  });
  if (!response.ok)
    throw new Error(`Could not create ticket channel: ${response.status}`);
  return (await response.json()) as { id: string; name: string };
}

async function findChannel(guildId: string, name: string) {
  const response = await rest("/guilds/" + guildId + "/channels");
  if (!response.ok) return null;
  const channels = (await response.json()) as Array<{
    id: string;
    name: string;
    type?: number;
  }>;
  return (
    channels.find((channel) => channel.name === name) ??
    channels.find(
      (channel) => channel.type === 0 && channel.name.endsWith("・" + name),
    ) ??
    channels.find(
      (channel) => channel.type === 0 && channel.name.endsWith("-" + name),
    ) ??
    channels.find(
      (channel) =>
        channel.type === 0 &&
        normalizeDiscordChannelName(channel.name) ===
          normalizeDiscordChannelName(name),
    ) ??
    null
  );
}

function normalizeDiscordChannelName(name: string) {
  return name.toLowerCase().replace(/[^a-z0-9]/g, "");
}

async function createDiscordGuildChannel(
  guildId: string,
  channel: {
    name: string;
    type: number;
    parent_id?: string;
    permission_overwrites?: Array<{
      id: string;
      type: 0 | 1;
      allow?: string;
      deny?: string;
    }>;
  },
) {
  let response: Response | undefined;
  for (let attempt = 0; attempt < 5; attempt += 1) {
    response = await rest(`/guilds/${guildId}/channels`, {
      method: "POST",
      body: JSON.stringify(channel),
    });
    if (response.status !== 429) break;
    const retryAfter = Number(response.headers.get("retry-after") ?? "1");
    await new Promise((resolve) =>
      setTimeout(resolve, Math.max(1000, Math.ceil(retryAfter * 1000))),
    );
  }

  if (!response?.ok) {
    const details = response ? await response.text() : "";
    throw new Error(
      `Could not create Discord channel "${channel.name}": ${response?.status ?? "unknown error"}${details ? ` ${details}` : ""}`,
    );
  }
  return (await response.json()) as DiscordChannel;
}

async function updateDiscordGuildChannel(
  channelId: string,
  channel: Record<string, unknown>,
) {
  let response: Response | undefined;
  for (let attempt = 0; attempt < 5; attempt += 1) {
    response = await rest(`/channels/${channelId}`, {
      method: "PATCH",
      body: JSON.stringify(channel),
    });
    if (response.status !== 429) break;
    const retryAfter = Number(response.headers.get("retry-after") ?? "1");
    await new Promise((resolve) =>
      setTimeout(resolve, Math.max(1000, Math.ceil(retryAfter * 1000))),
    );
  }

  if (!response?.ok) {
    const details = response ? await response.text() : "";
    throw new Error(
      `Could not update Discord channel ${channelId}: ${response?.status ?? "unknown error"}${details ? ` ${details}` : ""}`,
    );
  }
  return (await response.json()) as DiscordChannel;
}

async function createKitWaitlistChannels(
  guildId: string,
  botUserId: string,
  kitsToSetup: readonly (typeof KITS)[number][] = KITS,
) {
  const [channelsResponse, roles] = await Promise.all([
    rest(`/guilds/${guildId}/channels`),
    getGuildRoles(guildId),
  ]);
  if (!channelsResponse.ok) {
    throw new Error(
      `Could not read Discord channels: ${channelsResponse.status} ${await channelsResponse.text()}`,
    );
  }
  const channels = (await channelsResponse.json()) as DiscordChannel[];

  const kitRoles = await Promise.all(
    kitsToSetup.map(async (kit) => ({
      kit,
      kitRole: await findRoleWithConfig(guildId, [], KIT_LABELS[kit], roles),
      queueRole: await findRoleWithConfig(
        guildId,
        queueRoleEnvNames(kit),
        `${KIT_LABELS[kit]} Queue`,
        roles,
      ),
    })),
  );
  const missingRoles = kitRoles.flatMap(({ kit, kitRole, queueRole }) => [
    ...(!kitRole ? [KIT_LABELS[kit]] : []),
    ...(!queueRole ? [`${KIT_LABELS[kit]} Queue`] : []),
  ]);
  if (missingRoles.length > 0) {
    throw new Error(
      `Create these roles first with /create new, then run /waitlist again: ${missingRoles.join(", ")}`,
    );
  }

  const everyoneOverwrite = { id: guildId, type: 0 as const, deny: "3072" };
  const categoryPermissions = [
    everyoneOverwrite,
    { id: botUserId, type: 1 as const, allow: "68624" },
  ];
  const categoryName = "Kit Waitlists";
  const existingCategory = channels.find(
    (channel) =>
      channel.type === 4 &&
      normalizeDiscordChannelName(channel.name ?? "") === "kitwaitlists",
  );
  const category = existingCategory
    ? await updateDiscordGuildChannel(existingCategory.id, {
        name: categoryName,
        permission_overwrites: categoryPermissions,
      })
    : await createDiscordGuildChannel(guildId, {
        name: categoryName,
        type: 4,
        permission_overwrites: categoryPermissions,
      });

  let channelsCreated = 0;
  let channelsUpdated = 0;
  for (const { kit, kitRole, queueRole } of kitRoles) {
    if (!kitRole || !queueRole) continue;
    const channelName = `${kit}-waitlist`;
    const channelPermissions = [
      everyoneOverwrite,
      { id: kitRole.id, type: 0 as const, allow: "66560", deny: "2048" },
      { id: queueRole.id, type: 0 as const, allow: "66560", deny: "2048" },
      { id: botUserId, type: 1 as const, allow: "68624" },
    ];
    const existingChannel = channels.find(
      (channel) =>
        channel.type === 0 &&
        normalizeDiscordChannelName(channel.name ?? "") ===
          normalizeDiscordChannelName(channelName),
    );
    if (existingChannel) {
      await updateDiscordGuildChannel(existingChannel.id, {
        name: channelName,
        parent_id: category.id,
        permission_overwrites: channelPermissions,
      });
      channelsUpdated += 1;
    } else {
      await createDiscordGuildChannel(guildId, {
        name: channelName,
        type: 0,
        parent_id: category.id,
        permission_overwrites: channelPermissions,
      });
      channelsCreated += 1;
    }
  }

  return {
    categoryCreated: !existingCategory,
    channelsCreated,
    channelsUpdated,
  };
}

async function createNexusChannelLayout(guildId: string) {
  const response = await rest(`/guilds/${guildId}/channels`);
  if (!response.ok) {
    throw new Error(
      `Could not read Discord channels: ${response.status} ${await response.text()}`,
    );
  }

  const channels = (await response.json()) as DiscordChannel[];
  let categoriesCreated = 0;
  let categoriesExisting = 0;
  let channelsCreated = 0;
  let channelsExisting = 0;

  for (const categorySpec of NEXUS_CHANNEL_LAYOUT) {
    const categoryKey = normalizeDiscordChannelName(categorySpec.name);
    let category = channels.find(
      (candidate) =>
        candidate.type === 4 &&
        normalizeDiscordChannelName(candidate.name ?? "") === categoryKey,
    );
    if (category) {
      categoriesExisting += 1;
    } else {
      category = await createDiscordGuildChannel(guildId, {
        name: categorySpec.name,
        type: 4,
      });
      channels.push(category);
      categoriesCreated += 1;
    }

    for (const channelSpec of categorySpec.channels) {
      const channelKey = normalizeDiscordChannelName(channelSpec.name);
      const existing = channels.find(
        (candidate) =>
          candidate.type === channelSpec.type &&
          normalizeDiscordChannelName(candidate.name ?? "") === channelKey,
      );
      if (existing) {
        channelsExisting += 1;
        continue;
      }

      const created = await createDiscordGuildChannel(guildId, {
        name: channelSpec.name,
        type: channelSpec.type,
        parent_id: category.id,
      });
      channels.push(created);
      channelsCreated += 1;
    }
  }

  return {
    categoriesCreated,
    categoriesExisting,
    channelsCreated,
    channelsExisting,
  };
}

async function postToChannel(
  channelId: string,
  content: string,
  extra: Record<string, unknown> = {},
) {
  const response = await rest(`/channels/${channelId}/messages`, {
    method: "POST",
    body: JSON.stringify({
      ...(content ? { content } : {}),
      ...extra,
    }),
  });
  if (!response.ok) {
    throw new Error(`Could not send a Discord message: ${response.status}`);
  }
  return (await response.json()) as { id: string; channel_id?: string };
}

let testerLeaderboardRefreshQueue: Promise<void> = Promise.resolve();
let testerLeaderboardMonthTimer: ReturnType<typeof setInterval> | undefined;
let observedTesterLeaderboardMonth: string | undefined;

function currentTestingMonthKey() {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Europe/Berlin",
    year: "numeric",
    month: "2-digit",
  }).formatToParts(new Date());
  const year = parts.find((part) => part.type === "year")?.value ?? "";
  const month = parts.find((part) => part.type === "month")?.value ?? "";
  return year + "-" + month;
}

function testingLeaderboardDescription(
  board: Awaited<ReturnType<typeof getTestingLeaderboard>>,
) {
  const renderRows = (entries: typeof board.allTime) =>
    entries.slice(0, 10).map((entry, index) => {
      const rank = index + 1;
      const medal =
        rank === 1
          ? "🥇"
          : rank === 2
            ? "🥈"
            : rank === 3
              ? "🥉"
              : String(rank) + ".";
      const suffix = entry.tests === 1 ? "test" : "tests";
      return (
        medal +
        " <@" +
        entry.testerDiscordUserId +
        "> — " +
        entry.tests.toLocaleString("en-US") +
        " " +
        suffix
      );
    });
  const allTimeRows = renderRows(board.allTime);
  const monthRows = renderRows(board.monthly);
  return [
    "**🏆 All-Time Testing Leaderboard**",
    ...(allTimeRows.length ? allTimeRows : ["No tests yet."]),
    "",
    "**Total ALL-Time Tests: " +
      board.totalAllTime.toLocaleString("en-US") +
      "**",
    "",
    "**🏅 " + board.monthLabel + " Testing Leaderboard**",
    ...(monthRows.length ? monthRows : ["No tests this month yet."]),
    "",
    "**Total Tests in " +
      board.monthLabel +
      ": " +
      board.totalThisMonth.toLocaleString("en-US") +
      "**",
  ].join("\n");
}

async function updateTestingLeaderboard(
  guildId: string,
  createIfMissing = false,
) {
  const channel =
    (await findChannel(guildId, "leaderboard")) ??
    (await findChannel(guildId, "testing-leaderboard"));
  if (!channel)
    throw new Error("Could not find a leaderboard channel in this server.");
  const [board, state] = await Promise.all([
    getTestingLeaderboard(),
    getState(),
  ]);
  const embed = {
    title: "🏆 Testing Leaderboard",
    description: testingLeaderboardDescription(board),
    color: 0xffd700,
    footer: {
      text: "Counts include /result only; /adminresult is excluded. Month uses Europe/Berlin.",
    },
  };
  const messageId = state.testerLeaderboardMessageIds[guildId];
  if (messageId) {
    const response = await rest(
      "/channels/" + channel.id + "/messages/" + messageId,
      {
        method: "PATCH",
        body: JSON.stringify({
          embeds: [embed],
          allowed_mentions: { parse: [] },
        }),
      },
    );
    if (response.ok) return;
    if (response.status !== 404)
      throw new Error(
        "Could not update the Discord testing leaderboard: " + response.status,
      );
    delete state.testerLeaderboardMessageIds[guildId];
    await saveState(state);
  }
  if (!createIfMissing) return;
  const message = await postToChannel(channel.id, "", {
    embeds: [embed],
    allowed_mentions: { parse: [] },
  });
  state.testerLeaderboardMessageIds[guildId] = message.id;
  await saveState(state);
}

function refreshTestingLeaderboard(guildId: string, createIfMissing = false) {
  const next = testerLeaderboardRefreshQueue
    .catch(() => undefined)
    .then(() => updateTestingLeaderboard(guildId, createIfMissing));
  testerLeaderboardRefreshQueue = next;
  return next;
}

function monitorTestingLeaderboardMonth(guildId: string) {
  if (testerLeaderboardMonthTimer) return;
  observedTesterLeaderboardMonth = currentTestingMonthKey();
  testerLeaderboardMonthTimer = setInterval(() => {
    const month = currentTestingMonthKey();
    if (month === observedTesterLeaderboardMonth) return;
    observedTesterLeaderboardMonth = month;
    void refreshTestingLeaderboard(guildId).catch((error) => {
      logger.warn(
        { error, guildId, month },
        "Could not refresh the monthly testing leaderboard",
      );
    });
  }, 60_000);
}

async function deleteMessage(channelId: string, messageId: string) {
  const response = await rest(`/channels/${channelId}/messages/${messageId}`, {
    method: "DELETE",
  });
  if (!response.ok && response.status !== 404) {
    throw new Error(`Could not delete the Discord message: ${response.status}`);
  }
}

async function getChannel(channelId: string) {
  const response = await rest(`/channels/${channelId}`);
  if (!response.ok)
    throw new Error(
      `Could not inspect the Discord channel: ${response.status}`,
    );
  return (await response.json()) as DiscordChannel;
}

function safeChannelSegment(value: string) {
  return (
    value
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, "-")
      .replace(/-+/g, "-")
      .replace(/^-|-$/g, "")
      .slice(0, 24) || "player"
  );
}

const TICKET_TYPES: Array<{
  value: TicketType;
  label: string;
  description: string;
}> = [
  {
    value: "support",
    label: "Support",
    description: "Get help from the NexusTiers team",
  },
  {
    value: "report",
    label: "Report",
    description: "Report a player or incident",
  },
  {
    value: "staff_report",
    label: "Staff Report",
    description: "Privately report a staff member",
  },
];
const TICKET_CHANNEL_CATEGORIES: Record<TicketType, string> = {
  support: "Support",
  report: "Support",
  staff_report: "Support",
  high_tier: "High Tickets",
};
const HIGH_TIER_TIERS = ["HT3", "LT2", "HT2", "LT1", "HT1"] as const;
const HIGH_TIER_KITS = [
  "smp",
  "uhc",
  "crystal",
  "ogvanilla",
  "diacrystal",
  "diasmp",
  "elytra",
  "creeper",
  "trident",
  "speed",
  "bow",
  "manhunt",
  "sword",
  "nethpot",
  "diapot",
  "axe",
  "mace",
  "spearmace",
  "cart",
  "bed",
  "debuff",
] as const;
type HighTierKit = (typeof HIGH_TIER_KITS)[number];
const HIGH_TIER_KIT_LABELS: Record<HighTierKit, string> = {
  smp: "SMP",
  uhc: "UHC",
  crystal: "Crystal",
  ogvanilla: "OGVanilla",
  diacrystal: "DiaCrystal",
  diasmp: "DiaSMP",
  elytra: "Elytra",
  creeper: "Creeper",
  trident: "Trident",
  speed: "Speed",
  bow: "Bow",
  manhunt: "Manhunt",
  sword: "Sword",
  nethpot: "NethPot",
  diapot: "DiaPot",
  axe: "Axe",
  mace: "Mace",
  spearmace: "Spearmace",
  cart: "Cart",
  bed: "Bed",
  debuff: "debuff",
};
const TICKET_STAFF_ROLES = [
  { name: "Manager", envNames: ["MANAGER_ROLE_ID"] },
  { name: "Admin", envNames: ["ADMIN_ROLE_ID"] },
  { name: "Mod", envNames: ["MOD_ROLE_ID"] },
  { name: "Helper", envNames: ["HELPER_ROLE_ID"] },
];
const EVAL_REVIEW_ROLE_NAMES = new Set(["Manager", "Mod", "Helper"]);
const TICKET_VIEW_PERMISSIONS = "68608";
const TICKET_READ_ONLY_PERMISSIONS = "66560";
const TICKET_SEND_PERMISSION = "2048";

const ticketPanel = {
  embeds: [
    {
      title: "NexusTiers Support",
      description:
        "Need help? Select the type of ticket you want to create below.",
      color: 0x5865f2,
      footer: { text: "Please provide clear and complete information." },
    },
  ],
  components: [
    {
      type: 1,
      components: [
        {
          type: 3,
          custom_id: "ticket_type",
          placeholder: "Select a ticket type",
          options: TICKET_TYPES.map((ticket) => ({
            label: ticket.label,
            value: ticket.value,
            description: ticket.description,
          })),
        },
      ],
    },
  ],
};

const highTierPanel = {
  embeds: [
    {
      title: "NexusTiers High Tickets",
      description: "Need a high-tier test? Select the requested tier below.",
      color: 0x5865f2,
      footer: { text: "Please provide clear and complete information." },
    },
  ],
  components: [
    {
      type: 1,
      components: [
        {
          type: 3,
          custom_id: "high_tier_tier",
          placeholder: "Select a tier",
          options: HIGH_TIER_TIERS.map((tier) => ({
            label: tier,
            value: tier,
          })),
        },
      ],
    },
  ],
};

const testerInfoEmbed = {
  title: "NexusTiers – Verified-Tester-Befehle",
  description: "Diese Übersicht zeigt nur Befehle, die Verified Tester verwenden können.",
  color: 0x5865f2,
  fields: [
    {
      name: "🎯 Queue & Testing",
      value: [
        "**/open** – Waitlist für den aktuellen Kanal öffnen",
        "**/close** – Waitlist für den aktuellen Kanal schließen",
        "**/leave** – Eigene Waitlist verlassen",
        "**/testerjoin** – Nur der Tester-Waitlist beitreten",
        "**/testerleave** – Nur die Tester-Waitlist verlassen",
        "**/next** – Nächstes Ticket öffnen",
        "**/eval** – Testticket zur Auswertung an das Team übergeben",
        "**/skip** – Aktuelles Ticket überspringen",
        "**/result tier:<tier>** – Ergebnis des aktuellen Tickets speichern",
      ].join("\n"),
      inline: false,
    },
  ],
};
function ticketType(value: string | undefined): TicketType | undefined {
  return TICKET_TYPES.some((ticket) => ticket.value === value)
    ? (value as TicketType)
    : undefined;
}

function ticketModalComponents(type: TicketType) {
  const fields =
    type === "support"
      ? [
          {
            custom_id: "reason",
            label: "Why are you creating this ticket?",
            placeholder: "Please explain why you are creating this ticket...",
          },
        ]
      : [
          {
            custom_id: "reported_user",
            label:
              type === "report"
                ? "Who are you reporting?"
                : "Which staff member are you reporting?",
            placeholder:
              type === "report"
                ? "Enter the Discord or Minecraft username of the player..."
                : "Enter the staff member's Discord username...",
          },
          {
            custom_id: "reason",
            label:
              type === "report"
                ? "Why are you reporting this player?"
                : "Why are you reporting this staff member?",
            placeholder:
              type === "report"
                ? "Please explain the reason for this report..."
                : "Please explain the reason for this report...",
          },
          {
            custom_id: "evidence",
            label: "Evidence",
            placeholder:
              type === "report"
                ? "Please provide links or information about your evidence..."
                : "Please provide any relevant evidence...",
          },
        ];

  return fields.map((field) => ({
    type: 1,
    components: [
      {
        type: 4,
        custom_id: field.custom_id,
        label: field.label,
        style: 2,
        min_length: 1,
        max_length: 1000,
        required: true,
        placeholder: field.placeholder,
      },
    ],
  }));
}

function ticketControls(status: "open" | "closed") {
  return [
    {
      type: 1,
      components:
        status === "open"
          ? [
              {
                type: 2,
                style: 4,
                label: "Close Ticket",
                custom_id: "ticket_close",
              },
              {
                type: 2,
                style: 1,
                label: "Claim Ticket",
                custom_id: "ticket_claim",
              },
            ]
          : [
              {
                type: 2,
                style: 4,
                label: "Delete Ticket",
                custom_id: "ticket_delete",
              },
            ],
    },
  ];
}

function ticketDisplayName(type: TicketType) {
  if (type === "high_tier") return "High Tier";
  return (
    TICKET_TYPES.find((ticket) => ticket.value === type)?.label ?? "Ticket"
  );
}

function ticketCategoryEnvName(type: TicketType) {
  if (type === "high_tier") return "HIGH_TIER_CATEGORY_ID";
  return "SUPPORT_CATEGORY_ID";
}

async function findOrCreateTicketCategory(guildId: string, type: TicketType) {
  const response = await rest(`/guilds/${guildId}/channels`);
  if (!response.ok)
    throw new Error(`Could not read Discord channels: ${response.status}`);
  const channels = (await response.json()) as Array<{
    id: string;
    name?: string;
    type?: number;
  }>;
  const configuredId = process.env[ticketCategoryEnvName(type)]?.trim();
  const configured =
    configuredId &&
    channels.find(
      (channel) => channel.id === configuredId && channel.type === 4,
    );
  if (configured) return configured;

  const categoryName = TICKET_CHANNEL_CATEGORIES[type];
  const existing = channels.find(
    (channel) =>
      channel.type === 4 &&
      (channel.name?.toLowerCase() === categoryName.toLowerCase() ||
        channel.name
          ?.toLowerCase()
          .endsWith(`・${categoryName.toLowerCase()}`)),
  );
  if (existing) return existing;

  const createResponse = await rest(`/guilds/${guildId}/channels`, {
    method: "POST",
    body: JSON.stringify({ name: categoryName, type: 4 }),
  });
  if (!createResponse.ok) {
    throw new Error(
      `Could not create the ${categoryName} ticket category: ${createResponse.status}`,
    );
  }
  return (await createResponse.json()) as {
    id: string;
    name?: string;
    type?: number;
  };
}

async function ticketRoleOverwrites(
  guildId: string,
  knownRoles?: DiscordRole[],
) {
  const roles = knownRoles ?? (await getGuildRoles(guildId));
  const overwrites: Array<{
    id: string;
    type: number;
    allow: string;
    deny?: string;
  }> = [];
  for (const staffRole of TICKET_STAFF_ROLES) {
    const role = await findRoleWithConfig(
      guildId,
      staffRole.envNames,
      staffRole.name,
      roles,
    );
    if (role)
      overwrites.push({ id: role.id, type: 0, allow: TICKET_VIEW_PERMISSIONS });
  }
  return overwrites;
}

async function evalReviewRoleOverwrites(
  guildId: string,
  knownRoles: DiscordRole[],
) {
  const overwrites: Array<{
    id: string;
    type: number;
    allow: string;
    deny: string;
  }> = [];
  for (const staffRole of TICKET_STAFF_ROLES) {
    if (!EVAL_REVIEW_ROLE_NAMES.has(staffRole.name)) continue;
    const role = await findRoleWithConfig(
      guildId,
      staffRole.envNames,
      staffRole.name,
      knownRoles,
    );
    if (role)
      overwrites.push({
        id: role.id,
        type: 0,
        allow: TICKET_VIEW_PERMISSIONS,
        deny: "0",
      });
  }
  return overwrites;
}

async function createSupportTicketChannel(
  guildId: string,
  type: TicketType,
  ticketId: string,
  creatorId: string,
  creatorUsername: string,
  botUserId?: string,
  highTierDetails?: { tier: string; kit: HighTierKit },
) {
  const category = await findOrCreateTicketCategory(guildId, type);
  const roles = await getGuildRoles(guildId);
  const ownerId = await getGuildOwnerId(guildId);
  const safeUsername =
    creatorUsername
      .toLowerCase()
      .replace(/[^a-z0-9-]/g, "-")
      .slice(0, 18) || "user";
  const staffOverwrites =
    type === "staff_report" ? [] : await ticketRoleOverwrites(guildId, roles);
  const permissionOverwrites = [
    { id: guildId, type: 0, deny: "1024" },
    { id: creatorId, type: 1, allow: TICKET_VIEW_PERMISSIONS },
    ...((type === "staff_report" || type === "high_tier") &&
    ownerId !== creatorId
      ? [{ id: ownerId, type: 1, allow: TICKET_VIEW_PERMISSIONS }]
      : []),
    ...staffOverwrites,
    ...(botUserId
      ? [{ id: botUserId, type: 1, allow: TICKET_VIEW_PERMISSIONS }]
      : []),
  ];
  const channelName =
    type === "high_tier" && highTierDetails
      ? `${highTierDetails.tier.toLowerCase()}-${highTierDetails.kit}-${safeUsername}`
      : `ticket-${type}-${safeUsername}`;
  const topic =
    type === "high_tier" && highTierDetails
      ? `NexusTiers High Tier • ${highTierDetails.tier} ${HIGH_TIER_KIT_LABELS[highTierDetails.kit]} • ${ticketId}`
      : `NexusTiers ${ticketDisplayName(type)} • ${ticketId}`;
  const response = await rest(`/guilds/${guildId}/channels`, {
    method: "POST",
    body: JSON.stringify({
      name: channelName,
      type: 0,
      parent_id: category.id,
      topic,
      permission_overwrites: permissionOverwrites,
    }),
  });
  if (!response.ok) {
    throw new Error(`Could not create the ticket channel: ${response.status}`);
  }
  return (await response.json()) as { id: string; name: string };
}

function ticketFieldValue(value: string | undefined) {
  const trimmed = value?.trim();
  if (!trimmed) throw new Error("Please complete all required ticket fields.");
  return trimmed;
}

function ticketEmbed(ticket: NexusTicket) {
  const fields =
    ticket.type === "high_tier"
      ? [
          { name: "Player", value: `<@${ticket.creatorId}>`, inline: false },
          {
            name: "Requested Tier",
            value: ticket.requestedTier ?? "Not provided",
            inline: true,
          },
          {
            name: "Kit",
            value:
              HIGH_TIER_KIT_LABELS[ticket.kit as HighTierKit] ??
              ticket.kit ??
              "Not provided",
            inline: true,
          },
          ...(ticket.minecraftUser
            ? [
                {
                  name: "Minecraft User",
                  value: ticket.minecraftUser,
                  inline: true,
                },
              ]
            : []),
        ]
      : ticket.type === "support"
        ? [{ name: "Reason", value: ticket.reason, inline: false }]
        : [
            {
              name:
                ticket.type === "report"
                  ? "Reported Player"
                  : "Staff Member Reported",
              value: ticket.reportedUser ?? "Not provided",
              inline: false,
            },
            { name: "Reason", value: ticket.reason, inline: false },
            {
              name: "Evidence",
              value: ticket.evidence ?? "Not provided",
              inline: false,
            },
          ];
  return {
    embeds: [
      {
        title: ticketDisplayName(ticket.type),
        description:
          ticket.type === "high_tier"
            ? "This private high-tier ticket is visible only to the player and authorized staff."
            : ticket.type === "staff_report"
              ? "This report is private and can only be viewed by you and the Owner."
              : "A staff member will assist you shortly.",
        color: ticket.type === "staff_report" ? 0xed4245 : 0x5865f2,
        fields: [
          ...(ticket.type === "high_tier"
            ? fields
            : [
                {
                  name: "Created by",
                  value: `<@${ticket.creatorId}>`,
                  inline: false,
                },
                ...fields,
              ]),
        ],
        footer: { text: `Ticket ID: ${ticket.id}` },
      },
    ],
    components: ticketControls(ticket.status),
    allowed_mentions: { parse: [] },
  };
}

async function postTicketMessage(ticket: NexusTicket) {
  return postToChannel(ticket.channelId, "", ticketEmbed(ticket));
}

async function getTicket(ticketId: string) {
  const state = await getState();
  return state.tickets.find((ticket) => ticket.id === ticketId);
}

async function hasTicketStaffPermission(
  interaction: DiscordInteraction,
  ticket: NexusTicket,
  ownerOnly = false,
) {
  if (!interaction.guild_id) return false;
  const userId = actor(interaction).id;
  if ((await getGuildOwnerId(interaction.guild_id)) === userId) return true;
  if (ownerOnly) return false;
  const memberRoles = interaction.member?.roles ?? [];
  const roles = await getGuildRoles(interaction.guild_id);
  return TICKET_STAFF_ROLES.some((staffRole) => {
    const role = roles.find(
      (candidate) =>
        candidate.name.toLowerCase() === staffRole.name.toLowerCase() ||
        staffRole.envNames.some(
          (envName) => process.env[envName]?.trim() === candidate.id,
        ),
    );
    return Boolean(role && memberRoles.includes(role.id));
  });
}

async function hasTicketRoleAddPermission(interaction: DiscordInteraction) {
  if (!interaction.guild_id) return false;
  const userId = actor(interaction).id;
  if ((await getGuildOwnerId(interaction.guild_id)) === userId) return true;
  const memberRoles = interaction.member?.roles ?? [];
  const roles = await getGuildRoles(interaction.guild_id);
  return TICKET_STAFF_ROLES.some((staffRole) => {
    const role = roles.find(
      (candidate) =>
        candidate.name.toLowerCase() === staffRole.name.toLowerCase() ||
        staffRole.envNames.some(
          (envName) => process.env[envName]?.trim() === candidate.id,
        ),
    );
    return Boolean(role && memberRoles.includes(role.id));
  });
}

async function canManageTicket(
  interaction: DiscordInteraction,
  ticket: NexusTicket,
  action: "claim" | "close" | "delete",
) {
  const userId = actor(interaction).id;
  const isCreator = userId === ticket.creatorId;
  if (ticket.type === "staff_report") {
    if (action === "claim" || action === "delete") {
      return hasTicketStaffPermission(interaction, ticket, true);
    }
    return (
      isCreator || (await hasTicketStaffPermission(interaction, ticket, true))
    );
  }
  if (action === "claim" || action === "delete") {
    return hasTicketStaffPermission(interaction, ticket);
  }
  return isCreator || (await hasTicketStaffPermission(interaction, ticket));
}

async function closeTicketChannel(ticket: NexusTicket) {
  const response = await rest(
    `/channels/${ticket.channelId}/permissions/${ticket.creatorId}`,
    {
      method: "PUT",
      body: JSON.stringify({
        type: 1,
        allow: TICKET_READ_ONLY_PERMISSIONS,
        deny: TICKET_SEND_PERMISSION,
      }),
    },
  );
  if (!response.ok)
    throw new Error(`Could not close the ticket channel: ${response.status}`);
}

async function deleteQueueTicketChannel(channelId: string) {
  const response = await rest(`/channels/${channelId}`, { method: "DELETE" });
  if (!response.ok && response.status !== 404) {
    throw new Error(
      `Could not delete the queue ticket channel: ${response.status}`,
    );
  }
}

async function deleteTicketChannel(ticket: NexusTicket) {
  const response = await rest(`/channels/${ticket.channelId}`, {
    method: "DELETE",
  });
  if (!response.ok && response.status !== 404) {
    throw new Error(`Could not delete the ticket channel: ${response.status}`);
  }
}

type QueuePanelQueue = {
  entries: Array<{ discordUserId: string; username: string }>;
  activeTesters: Array<{ discordUserId: string; username: string }>;
};

type QueuePanelReference = {
  guildId: string;
  kit: string;
  channelId: string;
  messageId: string;
};

const queuePanels = new Map<string, QueuePanelReference>();
const ticketChannelKits = new Map<string, string>();
let queuePanelUpdaterStarted = false;

function queuePanelPayload(queue: QueuePanelQueue, kit: string) {
  const queueLines =
    queue.entries.length > 0
      ? queue.entries
          .slice(0, 20)
          .map((entry, index) => `${index + 1}. <@${entry.discordUserId}>`)
          .join("\n")
      : "No players currently in queue.";
  const testerLines =
    queue.activeTesters.length > 0
      ? queue.activeTesters
          .map((tester, index) => `${index + 1}. <@${tester.discordUserId}>`)
          .join("\n")
      : "No active testers.";

  return {
    embeds: [
      {
        title: "Tester(s) Available!",
        description: [
          "⏱️ The queue updates every 10 seconds.",
          "Use `/leave` if you wish to be removed from the waitlist or queue.",
          "",
          `**Queue (${queue.entries.length}/20):**`,
          queueLines,
          "",
          "**Active Testers:**",
          testerLines,
        ].join("\n"),
        color: 0x5865f2,
      },
    ],
    components: [
      {
        type: 1,
        components: [
          {
            type: 2,
            style: 1,
            label: "Join Queue",
            custom_id: `nexus_enter_waitlist:${kit}`,
          },
        ],
      },
    ],
  };
}

function closedQueuePanelPayload(queue: { lastUpdate: string }) {
  const timestamp = Math.floor(new Date(queue.lastUpdate).getTime() / 1000);
  const lastSession = Number.isFinite(timestamp)
    ? `<t:${timestamp}:F>\n<t:${timestamp}:t>`
    : "Not available";

  return {
    embeds: [
      {
        title: "No Testers Online",
        description: [
          "No testers for your region are available at this time.",
          "You will be pinged when a tester is available.",
          "Check back later!",
        ].join("\n\n"),
        color: 0xff0000,
        fields: [{ name: "Last testing session:", value: lastSession }],
      },
    ],
  };
}

function kitFromChannelName(channelName: string | undefined) {
  const normalized = (channelName ?? "").toLowerCase().replaceAll("・", "-");
  return [...KITS]
    .sort((a, b) => b.length - a.length)
    .find(
      (kit) =>
        normalized.includes(`${kit}-waitlist`) ||
        normalized.includes(`ticket-${kit}-`) ||
        normalized.startsWith(`ht3-${kit}-`),
    );
}

async function resolveKit(interaction: DiscordInteraction) {
  const guildId = requireNexusTestingGuild(interaction.guild_id);
  const channelId = interaction.channel_id?.trim();
  if (channelId) {
    const panel = [...queuePanels.values()].find(
      (candidate) => candidate.guildId === guildId && candidate.channelId === channelId,
    );
    if (panel) {
      assertKitAssignedToGuild(guildId, panel.kit);
      return panel.kit;
    }

    const trackedTicketKit = ticketChannelKits.get(channelId);
    if (trackedTicketKit) {
      assertKitAssignedToGuild(guildId, trackedTicketKit);
      return trackedTicketKit;
    }

    const channel = await getChannel(channelId);
    const channelKit = kitFromChannelName(channel.name);
    if (channelKit) {
      assertKitAssignedToGuild(guildId, channelKit);
      return channelKit;
    }
  }

  const state = await getState();
  const activeKits = getKitsForGuild(guildId).filter(
    (kit) => state.queues[kit].tickets.length > 0,
  );
  if (activeKits.length === 1) return activeKits[0];

  throw new Error(
    "Could not determine the kit. Run this command in the kit's waitlist or ticket channel.",
  );
}

async function updateQueuePanel(panel: QueuePanelReference) {
  const state = await getState();
  const queue = state.queues[panel.kit as keyof typeof state.queues];
  if (!queue) return;
  if (queue.status === "closed") return;
  const response = await rest(
    `/channels/${panel.channelId}/messages/${panel.messageId}`,
    {
      method: "PATCH",
      body: JSON.stringify(queuePanelPayload(queue, panel.kit)),
    },
  );
  if (response.status === 404) {
    queuePanels.delete(`${panel.guildId}:${panel.kit}`);
    return;
  }
  if (!response.ok)
    throw new Error(`Could not update queue panel: ${response.status}`);
}

function startQueuePanelUpdater() {
  if (queuePanelUpdaterStarted) return;
  queuePanelUpdaterStarted = true;
  setInterval(() => {
    void Promise.all(
      [...queuePanels.values()].map((panel) => updateQueuePanel(panel)),
    ).catch((error) => {
      logger.warn({ error }, "Could not refresh one or more queue panels");
    });
  }, 10_000);
}

async function getGuildRoles(guildId: string) {
  const response = await rest(`/guilds/${guildId}/roles`);
  if (!response.ok) {
    throw new Error(`Could not read Discord roles: ${response.status}`);
  }
  return (await response.json()) as DiscordRole[];
}

const TIER_ROLE_SORT_ORDER = [
  "ht1",
  "lt1",
  "ht2",
  "lt2",
  "ht3",
  "lt3",
  "ht4",
  "lt4",
  "ht5",
  "lt5",
] as const;

const ROLE_SORT_GROUP_ORDER = {
  tier: 0,
  member: 1,
  tester: 2,
  queue: 3,
  restricted: 4,
} as const;

type NexusRoleSortGroup = keyof typeof ROLE_SORT_GROUP_ORDER;
type SortableNexusRole = {
  role: DiscordRole;
  group: NexusRoleSortGroup;
  tierIndex: number;
};

function sortRoleIdsFromEnv(envNames: string[]) {
  return envNames
    .map((name) => process.env[name]?.trim())
    .filter((roleId): roleId is string => Boolean(roleId));
}

async function sortNexusRoles(guildId: string, botUserId: string) {
  const guildKits = getKitsForGuild(guildId);
  const [roles, botMemberResponse] = await Promise.all([
    getGuildRoles(guildId),
    rest(`/guilds/${guildId}/members/${botUserId}`),
  ]);
  if (!botMemberResponse.ok) {
    throw new Error(
      `Could not read the bot's role hierarchy: ${botMemberResponse.status}`,
    );
  }

  const botMember = (await botMemberResponse.json()) as DiscordGuildMember;
  const botRolePositions = roles
    .filter(
      (role) =>
        botMember.roles?.includes(role.id) && typeof role.position === "number",
    )
    .map((role) => role.position as number);
  if (botRolePositions.length === 0) {
    throw new Error("Could not determine the bot's highest server role.");
  }
  const botHighestRolePosition = Math.max(...botRolePositions);

  const memberRoleIds = new Set(sortRoleIdsFromEnv(["MEMBER_ROLE_ID"]));
  const restrictedRoleIds = new Set(sortRoleIdsFromEnv(["RESTRICTED_ROLE_ID"]));
  const testerRoleIds = new Set(
    sortRoleIdsFromEnv([
      "VERIFIED_TESTER_ROLE_ID",
      "DISCORD_TESTER_ROLE_ID",
      ...guildKits.flatMap((kit) => {
        const normalizedKit = kit.toUpperCase();
        return [
          `TESTER_${normalizedKit}_ROLE_ID`,
          `${normalizedKit}_TESTER_ROLE_ID`,
        ];
      }),
    ]),
  );
  const queueRoleIds = new Set(
    sortRoleIdsFromEnv(guildKits.flatMap(queueRoleEnvNames)),
  );
  const memberRoleNames = new Set(["member"]);
  const testerRoleNames = new Set([
    "verified tester",
    ...guildKits.map((kit) => `${KIT_LABELS[kit]} Tester`.toLowerCase()),
  ]);
  const queueRoleNames = new Set(
    guildKits.map((kit) => `${KIT_LABELS[kit]} Queue`.toLowerCase()),
  );

  const roleCandidates = roles.flatMap((role): SortableNexusRole[] => {
    const match = role.name.trim().match(/^\[?(ht[1-5]|lt[1-5])\]?(?=\s|$)/i);
    if (match) {
      const tier =
        match[1].toLowerCase() as (typeof TIER_ROLE_SORT_ORDER)[number];
      return [
        { role, group: "tier", tierIndex: TIER_ROLE_SORT_ORDER.indexOf(tier) },
      ];
    }

    const name = role.name.trim().toLowerCase();
    const group =
      name === "restricted" || restrictedRoleIds.has(role.id)
        ? "restricted"
        : memberRoleNames.has(name) || memberRoleIds.has(role.id)
          ? "member"
          : testerRoleNames.has(name) || testerRoleIds.has(role.id)
            ? "tester"
            : queueRoleNames.has(name) || queueRoleIds.has(role.id)
              ? "queue"
              : undefined;

    return group ? [{ role, group, tierIndex: 0 }] : [];
  });
  const sortableRoles = roleCandidates
    .filter(
      ({ role }) =>
        !role.managed &&
        role.id !== guildId &&
        typeof role.position === "number" &&
        role.position < botHighestRolePosition,
    )
    .sort(
      (a, b) =>
        ROLE_SORT_GROUP_ORDER[a.group] - ROLE_SORT_GROUP_ORDER[b.group] ||
        a.tierIndex - b.tierIndex ||
        a.role.name.toLowerCase().localeCompare(b.role.name.toLowerCase()) ||
        a.role.id.localeCompare(b.role.id),
    );

  const updates = sortableRoles.map(({ role }, index) => ({
    id: role.id,
    position: botHighestRolePosition - index - 1,
  }));
  const changedUpdates = updates.filter(
    (update) =>
      roles.find((role) => role.id === update.id)?.position !== update.position,
  );
  if (changedUpdates.length > 0) {
    const response = await rest(`/guilds/${guildId}/roles`, {
      method: "PATCH",
      body: JSON.stringify(changedUpdates),
    });
    if (!response.ok) {
      throw new Error(
        `Could not sort NexusTiers roles: ${response.status} ${await response.text()}`,
      );
    }
  }

  return {
    found: roleCandidates.length,
    sorted: sortableRoles.length,
    skipped: roleCandidates.length - sortableRoles.length,
  };
}

type NexusRoleSpec = {
  name: string;
  color: number;
  hoist: boolean;
};

const TIER_ROLE_COLORS: Record<string, number> = {
  lt5: 0x95a5a6,
  ht5: 0x7f8c8d,
  lt4: 0x3498db,
  ht4: 0x2980b9,
  lt3: 0x2ecc71,
  ht3: 0x27ae60,
  lt2: 0xf1c40f,
  ht2: 0xf39c12,
  lt1: 0xe67e22,
  ht1: 0xe74c3c,
};

type NexusRoleColorSpec = {
  name: string;
  color: number;
  category: "tier" | "kit" | "waitlist";
};

function nexusRoleColorSpecs(
  kitsToUpdate: readonly (typeof KITS)[number][] = KITS,
): NexusRoleColorSpec[] {
  const specs: NexusRoleColorSpec[] = [];
  for (const kit of kitsToUpdate) {
    const kitLabel = KIT_LABELS[kit];
    for (const tier of TIERS) {
      if (tier === "N/A") continue;
      specs.push({
        name: `${tier.toUpperCase()} ${kitLabel}`,
        color: TIER_ROLE_COLORS[tier] ?? 0x5865f2,
        category: "tier",
      });
    }
    specs.push({ name: kitLabel, color: 0x5865f2, category: "kit" });
    specs.push({
      name: `${kitLabel} Queue`,
      color: 0x9b59b6,
      category: "waitlist",
    });
  }
  return specs;
}

function nexusRoleSpecs(kitsToCreate: readonly (typeof KITS)[number][] = KITS): NexusRoleSpec[] {
  const specs: NexusRoleSpec[] = [];
  for (const kit of kitsToCreate) {
    const kitLabel = KIT_LABELS[kit];
    for (const tier of TIERS) {
      if (tier === "N/A") continue;
      specs.push({
        name: `${tier.toUpperCase()} ${kitLabel}`,
        color: TIER_ROLE_COLORS[tier] ?? 0x5865f2,
        hoist: true,
      });
    }
    specs.push({ name: kitLabel, color: 0x5865f2, hoist: true });
    specs.push({ name: `${kitLabel} Queue`, color: 0x9b59b6, hoist: true });
  }
  return specs;
}

async function changeNexusRoleColors(
  guildId: string,
  kitsToUpdate: readonly (typeof KITS)[number][] = getKitsForGuild(guildId),
) {
  const roles = await getGuildRoles(guildId);
  const summary = {
    tier: { changed: 0, unchanged: 0, missing: 0, skipped: 0 },
    kit: { changed: 0, unchanged: 0, missing: 0, skipped: 0 },
    waitlist: { changed: 0, unchanged: 0, missing: 0, skipped: 0 },
  };

  for (const spec of nexusRoleColorSpecs(kitsToUpdate)) {
    const role = roles.find(
      (candidate) => candidate.name.toLowerCase() === spec.name.toLowerCase(),
    );
    if (!role) {
      summary[spec.category].missing += 1;
      continue;
    }
    if (role.managed) {
      summary[spec.category].skipped += 1;
      continue;
    }
    if (role.color === spec.color) {
      summary[spec.category].unchanged += 1;
      continue;
    }

    let response: Response | undefined;
    for (let attempt = 0; attempt < 4; attempt += 1) {
      response = await rest(`/guilds/${guildId}/roles/${role.id}`, {
        method: "PATCH",
        body: JSON.stringify({ color: spec.color }),
      });
      if (response.status !== 429) break;
      const retryAfter = Number(response.headers.get("retry-after") ?? "1");
      await new Promise((resolve) =>
        setTimeout(resolve, Math.max(1000, Math.ceil(retryAfter * 1000))),
      );
    }

    if (!response?.ok) {
      throw new Error(
        `Could not change the color of the ${spec.name} role: ${response?.status ?? "unknown error"}`,
      );
    }
    summary[spec.category].changed += 1;
  }

  return summary;
}

async function createNexusRoles(
  guildId: string,
  kitsToCreate: readonly (typeof KITS)[number][] = KITS,
) {
  const roles = await getGuildRoles(guildId);
  const specs = nexusRoleSpecs(kitsToCreate);
  const missingSpecs = specs.filter(
    (spec) =>
      !roles.some((role) => role.name.toLowerCase() === spec.name.toLowerCase()),
  );
  const freeRoleSlots = Math.max(0, 250 - roles.length);
  if (missingSpecs.length > freeRoleSlots) {
    throw new Error(
      `Discord allows up to 250 roles per server. This setup needs ${missingSpecs.length} new roles, but only ${freeRoleSlots} slots are free. No roles were changed. Remove unused roles and run the setup again.`,
    );
  }

  let created = 0;
  let existing = 0;

  for (const spec of specs) {
    const alreadyExists = roles.some(
      (role) => role.name.toLowerCase() === spec.name.toLowerCase(),
    );
    if (alreadyExists) {
      existing += 1;
      continue;
    }

    let response: Response | undefined;
    for (let attempt = 0; attempt < 4; attempt += 1) {
      response = await rest(`/guilds/${guildId}/roles`, {
        method: "POST",
        body: JSON.stringify({
          name: spec.name,
          color: spec.color,
          hoist: spec.hoist,
          mentionable: false,
        }),
      });
      if (response.status !== 429) break;
      const retryAfter = Number(response.headers.get("retry-after") ?? "1");
      await new Promise((resolve) =>
        setTimeout(resolve, Math.max(1000, Math.ceil(retryAfter * 1000))),
      );
    }

    if (!response?.ok) {
      const details = response ? await response.text() : "";
      throw new Error(
        `Could not create the ${spec.name} role: ${response?.status ?? "unknown error"}${details ? ` — ${details}` : ""}`,
      );
    }
    roles.push((await response.json()) as DiscordRole);
    created += 1;
  }

  return { created, existing, total: created + existing };
}

async function findAutomaticRole(
  guildId: string,
  envName: string,
  fallbackName: string,
  knownRoles?: DiscordRole[],
) {
  const roles = knownRoles ?? (await getGuildRoles(guildId));
  const configuredRoleId = process.env[envName]?.trim();
  if (configuredRoleId) {
    const configuredRole = roles.find((role) => role.id === configuredRoleId);
    if (configuredRole) return configuredRole;
    logger.warn(
      { guildId, envName, configuredRoleId, fallbackName },
      "Configured automatic role ID was not found; trying the role name",
    );
  }
  return (
    roles.find(
      (role) => role.name.toLowerCase() === fallbackName.toLowerCase(),
    ) ?? null
  );
}

function hasRestrictedRole(
  memberRoles: string[] | undefined,
  roles: DiscordRole[],
) {
  const configuredRoleId = process.env.RESTRICTED_ROLE_ID?.trim();
  const restrictedRole =
    (configuredRoleId && roles.find((role) => role.id === configuredRoleId)) ||
    roles.find((role) => role.name.toLowerCase() === "restricted");
  return Boolean(restrictedRole && memberRoles?.includes(restrictedRole.id));
}

function restrictedRole(roles: DiscordRole[]) {
  const configuredRoleId = process.env.RESTRICTED_ROLE_ID?.trim();
  return (
    (configuredRoleId && roles.find((role) => role.id === configuredRoleId)) ||
    roles.find((role) => role.name.toLowerCase() === "restricted") ||
    null
  );
}

function isTierRole(role: DiscordRole) {
  const normalizedName = role.name.trim().toLowerCase();
  return KITS.some((kit) =>
    TIERS.some(
      (tier) =>
        tier !== "N/A" &&
        normalizedName ===
          `${tier.toUpperCase()} ${KIT_LABELS[kit]}`.toLowerCase(),
    ),
  );
}

function restrictionTierText(restriction: NexusRestriction) {
  return restriction.savedTiers.length > 0
    ? restriction.savedTiers
        .map(
          (tier) =>
            `${tier.tier.toUpperCase()} ${KIT_LABELS[tier.kit as keyof typeof KIT_LABELS] ?? tier.kit}`,
        )
        .join(" • ")
    : "None";
}

function linkedMinecraftAccountNames(
  state: Awaited<ReturnType<typeof getState>>,
  discordUserId: string,
  minecraftUser: string,
) {
  const accounts = new Map<string, string>();
  const addAccount = (value: string | undefined) => {
    const name = value?.trim();
    if (name) accounts.set(name.toLowerCase(), name);
  };

  addAccount(minecraftUser);
  state.verified
    .filter((account) => account.discordUserId === discordUserId)
    .forEach((account) => addAccount(account.ign));
  state.results
    .filter((result) => result.playerDiscordUserId === discordUserId)
    .forEach((result) => addAccount(result.ign));
  for (const queue of Object.values(state.queues)) {
    queue.entries
      .filter((entry) => entry.discordUserId === discordUserId)
      .forEach((entry) => addAccount(entry.ign));
    queue.tickets
      .filter((ticket) => ticket.player.discordUserId === discordUserId)
      .forEach((ticket) => addAccount(ticket.player.ign));
  }
  state.restrictions
    .filter((restriction) => restriction.discordUserId === discordUserId)
    .forEach((restriction) => {
      addAccount(restriction.minecraftUser);
      restriction.linkedMinecraftAccounts?.forEach(addAccount);
    });

  return [...accounts.values()].sort((a, b) => a.localeCompare(b));
}

function restrictionAccountFields(restriction: NexusRestriction) {
  const accounts = restriction.linkedMinecraftAccounts ?? [];
  const chunks: string[][] = [];
  let current: string[] = [];
  let currentLength = 0;

  for (const account of accounts) {
    const nextLength =
      currentLength + (current.length > 0 ? 2 : 0) + account.length;
    if (current.length > 0 && nextLength > 1000) {
      chunks.push(current);
      current = [];
      currentLength = 0;
    }
    current.push(account);
    currentLength += (current.length > 1 ? 2 : 0) + account.length;
  }
  if (current.length > 0) chunks.push(current);

  return chunks.map((chunk, index) => ({
    name:
      index === 0
        ? "Linked Minecraft accounts"
        : "Linked Minecraft accounts (continued)",
    value: chunk.join(", "),
    inline: false,
  }));
}

function restrictionPunishmentMessages(
  restriction: NexusRestriction,
  discordUsername: string,
) {
  const messages = [
    `<@${restriction.discordUserId}> - ${discordUsername} / ${restriction.minecraftUser} - has been Restricted (${restriction.duration} - ${restriction.reason})\n${restriction.discordUserId}`,
  ];
  const accounts = restriction.linkedMinecraftAccounts ?? [];
  for (let index = 0; index < accounts.length; index += 40) {
    const chunk = accounts.slice(index, index + 40);
    const label =
      index === 0
        ? "Linked Minecraft accounts"
        : "Linked Minecraft accounts (continued)";
    messages.push(`${label}: ${chunk.join(", ")}`);
  }
  return messages;
}

function parseCooldownDuration(value: string) {
  const duration = value.trim().toLowerCase();
  if (!duration)
    throw new Error("Duration is required. Use values such as `3d` or `24h`.");

  const pattern = /(\d+)([smhdw])/g;
  let totalMilliseconds = 0;
  let consumed = 0;
  let match: RegExpExecArray | null;
  const multipliers: Record<string, number> = {
    s: 1000,
    m: 60 * 1000,
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    w: 7 * 24 * 60 * 60 * 1000,
  };
  while ((match = pattern.exec(duration))) {
    consumed += match[0].length;
    totalMilliseconds += Number(match[1]) * multipliers[match[2]];
  }
  if (
    consumed !== duration.length ||
    totalMilliseconds <= 0 ||
    !Number.isSafeInteger(totalMilliseconds)
  ) {
    throw new Error("Invalid duration. Use values such as `3d` or `24h`.");
  }
  return totalMilliseconds;
}

function parseRestrictionDuration(value: string) {
  const duration = value.trim().toLowerCase();
  if (duration === "permanent") return undefined;
  if (!duration)
    throw new Error(
      "Duration is required. Use values such as `7d`, `12h`, `356d`, or `permanent`.",
    );

  const pattern = /(\d+)([smhdw])/g;
  let totalMilliseconds = 0;
  let consumed = 0;
  let match: RegExpExecArray | null;
  const multipliers: Record<string, number> = {
    s: 1000,
    m: 60 * 1000,
    h: 60 * 60 * 1000,
    d: 24 * 60 * 60 * 1000,
    w: 7 * 24 * 60 * 60 * 1000,
  };
  while ((match = pattern.exec(duration))) {
    consumed += match[0].length;
    totalMilliseconds += Number(match[1]) * multipliers[match[2]];
  }
  if (
    consumed !== duration.length ||
    totalMilliseconds <= 0 ||
    !Number.isSafeInteger(totalMilliseconds)
  ) {
    throw new Error(
      "Invalid duration. Use values such as `7d`, `12h`, `356d`, or `permanent`.",
    );
  }
  return new Date(Date.now() + totalMilliseconds).toISOString();
}

async function removeRoleForRestriction(
  guildId: string,
  userId: string,
  role: DiscordRole,
) {
  const response = await rest(
    `/guilds/${guildId}/members/${userId}/roles/${role.id}`,
    { method: "DELETE" },
  );
  if (!response.ok && response.status !== 404) {
    throw new Error(`Could not remove role ${role.name}: ${response.status}`);
  }
}

async function restoreRestrictionRoles(
  restriction: NexusRestriction,
  botUserId?: string,
) {
  const memberResponse = await rest(
    `/guilds/${restriction.guildId}/members/${restriction.discordUserId}`,
  );
  if (!memberResponse.ok) {
    throw new Error(
      `Could not find the restricted Discord member: ${memberResponse.status}`,
    );
  }
  const member = (await memberResponse.json()) as DiscordGuildMember;
  const roles = await getGuildRoles(restriction.guildId);
  const currentRestrictedRole = restrictedRole(roles);
  if (currentRestrictedRole) {
    await removeAutomaticRole(
      restriction.guildId,
      member,
      currentRestrictedRole,
    );
  }

  for (const roleId of restriction.previousRoleIds) {
    if (roleId === restriction.guildId) continue;
    const role = roles.find((candidate) => candidate.id === roleId);
    if (!role || role.managed) continue;
    await assignAutomaticRole(
      restriction.guildId,
      member,
      role,
      roles,
      botUserId,
    );
  }
}

async function processDueRestrictions(botUserId?: string) {
  const dueRestrictions = await getDueRestrictions();
  for (const restriction of dueRestrictions) {
    try {
      await restoreRestrictionRoles(restriction, botUserId);
      await completeRestriction(
        restriction.id,
        "expired",
        botUserId ?? "system",
      );
      logger.info(
        {
          restrictionId: restriction.id,
          discordUserId: restriction.discordUserId,
        },
        "Restriction expired and saved roles were restored",
      );
    } catch (error) {
      logger.error(
        {
          error,
          restrictionId: restriction.id,
          discordUserId: restriction.discordUserId,
        },
        "Could not process expired restriction; it will be retried",
      );
    }
  }
}

function automaticRoleFailure(
  guildId: string,
  userId: string,
  role: DiscordRole,
  action: "assign" | "remove",
  status: number,
) {
  logger.warn(
    { guildId, userId, roleId: role.id, roleName: role.name, action, status },
    `Could not ${action} automatic Discord role. Check Manage Roles permission and role hierarchy.`,
  );
}

async function assignAutomaticRole(
  guildId: string,
  member: DiscordGuildMember,
  role: DiscordRole,
  roles: DiscordRole[],
  botUserId?: string,
) {
  const userId = member.user?.id;
  if (!userId || member.roles?.includes(role.id)) return;
  if (role.managed) {
    logger.warn(
      { guildId, userId, roleId: role.id, roleName: role.name },
      "Automatic role is managed by Discord and cannot be assigned",
    );
    return;
  }
  if (botUserId) {
    const botMemberResponse = await rest(
      `/guilds/${guildId}/members/${botUserId}`,
    );
    if (botMemberResponse.ok) {
      const botMember = (await botMemberResponse.json()) as DiscordGuildMember;
      const botHighestRole = roles
        .filter((candidate) => botMember.roles?.includes(candidate.id))
        .sort((a, b) => (b.position ?? 0) - (a.position ?? 0))[0];
      if (
        botHighestRole &&
        (role.position ?? 0) >= (botHighestRole.position ?? 0)
      ) {
        logger.warn(
          {
            guildId,
            userId,
            roleId: role.id,
            roleName: role.name,
            rolePosition: role.position,
            botRolePosition: botHighestRole.position,
          },
          "Automatic role is not below the bot role in the Discord hierarchy",
        );
        return;
      }
    } else {
      logger.warn(
        { guildId, userId, botUserId, status: botMemberResponse.status },
        "Could not inspect the bot role hierarchy before assigning an automatic role",
      );
    }
  }
  const response = await rest(
    `/guilds/${guildId}/members/${userId}/roles/${role.id}`,
    { method: "PUT" },
  );
  if (!response.ok) {
    automaticRoleFailure(guildId, userId, role, "assign", response.status);
    return;
  }
  logger.info(
    { guildId, userId, roleId: role.id, roleName: role.name },
    "Automatic Discord role assigned",
  );
}

async function removeAutomaticRole(
  guildId: string,
  member: DiscordGuildMember,
  role: DiscordRole,
) {
  const userId = member.user?.id;
  if (!userId || !member.roles?.includes(role.id)) return;
  const response = await rest(
    `/guilds/${guildId}/members/${userId}/roles/${role.id}`,
    { method: "DELETE" },
  );
  if (!response.ok) {
    automaticRoleFailure(guildId, userId, role, "remove", response.status);
    return;
  }
  logger.info(
    { guildId, userId, roleId: role.id, roleName: role.name },
    "Automatic Discord role removed",
  );
}

async function syncTierResultRole(
  guildId: string,
  result: { playerDiscordUserId?: string; kit: string; tier: string },
  botUserId?: string,
) {
  const userId = result.playerDiscordUserId;
  if (!userId) return;

  const memberResponse = await rest(`/guilds/${guildId}/members/${userId}`);
  if (!memberResponse.ok) {
    logger.warn(
      { guildId, userId, status: memberResponse.status },
      "Could not find result player for tier role assignment",
    );
    return;
  }
  const member = (await memberResponse.json()) as DiscordGuildMember;
  const roles = await getGuildRoles(guildId);
  const kit = result.kit as (typeof KITS)[number];
  const kitLabel = KIT_LABELS[kit];
  if (!kitLabel) return;

  const kitTierRoles = roles.filter((role) =>
    TIERS.some(
      (tier) =>
        tier !== "N/A" &&
        role.name.toLowerCase() ===
          `${tier.toUpperCase()} ${kitLabel}`.toLowerCase(),
    ),
  );
  const targetRoleName =
    `${result.tier.toUpperCase()} ${kitLabel}`.toLowerCase();
  for (const role of kitTierRoles) {
    if (role.name.toLowerCase() !== targetRoleName) {
      await removeAutomaticRole(guildId, member, role);
    }
  }

  if (result.tier === "N/A") return;
  const targetRole = kitTierRoles.find(
    (role) => role.name.toLowerCase() === targetRoleName,
  );
  if (!targetRole) {
    logger.warn(
      { guildId, userId, kit, tier: result.tier },
      "Tier role was not found; configure the Discord tier roles before publishing results",
    );
    return;
  }
  await assignAutomaticRole(guildId, member, targetRole, roles, botUserId);
}

async function handleGuildMemberAdd(
  member: DiscordGuildMember,
  botUserId?: string,
) {
  const guildId = member.guild_id;
  const userId = member.user?.id;
  if (!guildId || !userId) return;
  try {
    const roles = await getGuildRoles(guildId);
    if (hasRestrictedRole(member.roles, roles)) {
      logger.info(
        { guildId, userId },
        "Skipped automatic member role because the member is Restricted",
      );
      return;
    }
    const memberRole = await findAutomaticRole(
      guildId,
      "MEMBER_ROLE_ID",
      "Member",
      roles,
    );
    if (!memberRole) {
      logger.warn({ guildId, userId }, 'Automatic "Member" role was not found');
      return;
    }
    await assignAutomaticRole(guildId, member, memberRole, roles, botUserId);
  } catch (error) {
    logger.error(
      { error, guildId, userId },
      "Automatic member role handling failed",
    );
  }
}

async function handleBoosterAlertUpdate(
  guildId: string,
  userId: string,
  premiumSince: string | null | undefined,
) {
  const state = await getState();
  state.boosterAlertChannels ??= {};
  state.boosterAlertBoosts ??= {};
  const guildBoosts = state.boosterAlertBoosts[guildId] ?? {};

  if (!premiumSince) {
    if (Object.prototype.hasOwnProperty.call(guildBoosts, userId)) {
      delete guildBoosts[userId];
      state.boosterAlertBoosts[guildId] = guildBoosts;
      await saveState(state);
    }
    return;
  }

  const previousPremiumSince = guildBoosts[userId];
  if (previousPremiumSince === premiumSince) return;

  guildBoosts[userId] = premiumSince;
  state.boosterAlertBoosts[guildId] = guildBoosts;
  await saveState(state);

  const channelId = state.boosterAlertChannels[guildId];
  if (!channelId) return;

  // On the first event after setup, ignore old boosts in case the member
  // snapshot could not be fetched; a newly started boost has a recent timestamp.
  if (previousPremiumSince === undefined) {
    const startedAt = Date.parse(premiumSince);
    const ageMs = Date.now() - startedAt;
    if (
      !Number.isFinite(startedAt) ||
      ageMs > 15 * 60_000 ||
      ageMs < -5 * 60_000
    )
      return;
  }

  try {
    await postToChannel(
      channelId,
      `🎉 <@${userId}> hat den Server geboostet! Danke für den Support!`,
      { allowed_mentions: { parse: [], users: [userId] } },
    );
    logger.info({ guildId, userId, channelId }, "Posted server boost alert");
  } catch (error) {
    logger.error(
      { error, guildId, userId, channelId },
      "Could not post server boost alert",
    );
  }
}

async function handleGuildMemberUpdate(
  member: DiscordGuildMember,
  botUserId?: string,
) {
  const guildId = member.guild_id;
  const userId = member.user?.id;
  if (
    !guildId ||
    !userId ||
    !Object.prototype.hasOwnProperty.call(member, "premium_since")
  )
    return;
  try {
    try {
      await handleBoosterAlertUpdate(guildId, userId, member.premium_since);
    } catch (error) {
      logger.error(
        { error, guildId, userId },
        "Server boost alert processing failed",
      );
    }

    const roles = await getGuildRoles(guildId);
    const boosterRole = await findAutomaticRole(
      guildId,
      "BOOSTER_ROLE_ID",
      "Booster",
      roles,
    );
    if (!boosterRole) {
      logger.warn(
        { guildId, userId },
        'Automatic "Booster" role was not found',
      );
      return;
    }
    if (member.premium_since) {
      if (hasRestrictedRole(member.roles, roles)) {
        logger.info(
          { guildId, userId },
          "Skipped automatic booster role because the member is Restricted",
        );
        return;
      }
      await assignAutomaticRole(guildId, member, boosterRole, roles, botUserId);
      return;
    }

    const latestMemberResponse = await rest(
      `/guilds/${guildId}/members/${userId}`,
    );
    if (!latestMemberResponse.ok) {
      logger.warn(
        { guildId, userId, status: latestMemberResponse.status },
        "Could not verify the member's current boost status",
      );
      return;
    }
    const latestMember =
      (await latestMemberResponse.json()) as DiscordGuildMember;
    if (!latestMember.premium_since) {
      await removeAutomaticRole(guildId, latestMember, boosterRole);
    }
  } catch (error) {
    logger.error(
      { error, guildId, userId },
      "Automatic booster role handling failed",
    );
  }
}

const APPLICATION_KITS = (
  [
    "uhc",
    "smp",
    "mace",
    "spearmace",
    "crystal",
    "diacrystal",
    "diasmp",
    "elytra",
    "creeper",
    "trident",
    "speed",
    "bow",
    "manhunt",
    "sword",
    "axe",
    "diapot",
    "nethpot",
    "cart",
    "bed",
    "debuff",
  ] as const
).map((kit) => ({
  label: KIT_LABELS[kit],
  value: kit,
}));

const applicationPanel = {
  embeds: [
    {
      title: "Applications",
      description:
        "Choose the application you would like to complete. All questions will be answered privately in your DMs.",
      color: 0x5865f2,
    },
  ],
  components: [
    {
      type: 1,
      components: [
        {
          type: 2,
          style: 1,
          label: "🧪 Tester Application",
          custom_id: "application_panel:tester",
        },
        {
          type: 2,
          style: 1,
          label: "🛡️ Staff Application",
          custom_id: "application_panel:staff",
        },
      ],
    },
  ],
};

function applicationStartComponents(applicationId: string) {
  return [
    {
      type: 1,
      components: [
        {
          type: 2,
          style: 3,
          label: "Start",
          custom_id: `application_start:${applicationId}`,
        },
        {
          type: 2,
          style: 4,
          label: "Cancel",
          custom_id: `application_cancel:${applicationId}`,
        },
      ],
    },
  ];
}

function applicationReviewComponents(applicationId: string, disabled = false) {
  return [
    {
      type: 1,
      components: [
        {
          type: 2,
          style: 3,
          label: "Accept Application",
          custom_id: `application_accept:${applicationId}`,
          disabled,
        },
        {
          type: 2,
          style: 4,
          label: "Reject Application",
          custom_id: `application_reject:${applicationId}`,
          disabled,
        },
      ],
    },
  ];
}

function applicationKitSelect(applicationId: string) {
  return [
    {
      type: 1,
      components: [
        {
          type: 3,
          custom_id: `application_kit:${applicationId}`,
          placeholder: "Select a kit",
          min_values: 1,
          max_values: 1,
          options: APPLICATION_KITS,
        },
      ],
    },
  ];
}

function applicationPositionSelect(applicationId: string) {
  return [
    {
      type: 1,
      components: [
        {
          type: 3,
          custom_id: `application_position:${applicationId}`,
          placeholder: "Select a position",
          min_values: 1,
          max_values: 1,
          options: [
            { label: "Manager", value: "Manager" },
            { label: "Admin", value: "Admin" },
            { label: "Mod", value: "Mod" },
            { label: "Helper", value: "Helper" },
          ],
        },
      ],
    },
  ];
}

async function openDirectMessage(userId: string) {
  const response = await rest("/users/@me/channels", {
    method: "POST",
    body: JSON.stringify({ recipient_id: userId }),
  });
  if (!response.ok)
    throw new Error(`Could not open a DM channel: ${response.status}`);
  return (await response.json()) as { id: string };
}

async function sendDirectMessage(
  userId: string,
  content: string,
  extra: Record<string, unknown> = {},
) {
  const channel = await openDirectMessage(userId);
  await postToChannel(channel.id, content, extra);
  return channel.id;
}

async function findApplicationChannel(
  guildId: string,
  envName: string,
  fallbackName: string,
  preferredChannelId?: string,
) {
  const configuredChannelId =
    preferredChannelId?.trim() || process.env[envName]?.trim();
  const response = await rest(`/guilds/${guildId}/channels`);
  if (!response.ok)
    throw new Error(`Could not read Discord channels: ${response.status}`);
  const channels = (await response.json()) as Array<{
    id: string;
    name: string;
    type?: number;
  }>;
  if (configuredChannelId) {
    const configuredChannel = channels.find(
      (channel) => channel.id === configuredChannelId,
    );
    if (configuredChannel) return configuredChannel;
    logger.warn(
      { guildId, envName, configuredChannelId, fallbackName },
      "Configured application channel ID was not found; trying the channel name",
    );
  }
  const normalizedName = fallbackName.toLowerCase();
  return (
    channels.find(
      (channel) =>
        channel.type === 0 && channel.name.toLowerCase() === normalizedName,
    ) ??
    channels.find(
      (channel) =>
        channel.type === 0 &&
        channel.name.toLowerCase().endsWith(`・${normalizedName}`),
    ) ??
    channels.find(
      (channel) =>
        channel.type === 0 &&
        channel.name.toLowerCase().endsWith(`-${normalizedName}`),
    ) ??
    null
  );
}

async function findRoleWithConfig(
  guildId: string,
  envNames: string[],
  fallbackName: string,
  knownRoles?: DiscordRole[],
) {
  const roles = knownRoles ?? (await getGuildRoles(guildId));
  for (const envName of envNames) {
    const configuredRoleId = process.env[envName]?.trim();
    if (!configuredRoleId) continue;
    const configuredRole = roles.find((role) => role.id === configuredRoleId);
    if (configuredRole) return configuredRole;
    logger.warn(
      { guildId, envName, configuredRoleId, fallbackName },
      "Configured application role ID was not found",
    );
  }
  return (
    roles.find(
      (role) => role.name.toLowerCase() === fallbackName.toLowerCase(),
    ) ?? null
  );
}

async function getGuildOwnerId(guildId: string) {
  const response = await rest(`/guilds/${guildId}`);
  if (!response.ok)
    throw new Error(
      `Could not verify the Discord server owner: ${response.status}`,
    );
  return ((await response.json()) as { owner_id: string }).owner_id;
}

async function hasApplicationReviewPermission(
  interaction: DiscordInteraction,
  type: ApplicationType,
) {
  const guildId = interaction.guild_id;
  const userId = actor(interaction).id;
  if (!guildId || !userId) return false;
  if ((await getGuildOwnerId(guildId)) === userId) return true;
  const memberRoles = interaction.member?.roles ?? [];
  const roles = await getGuildRoles(guildId);
  const allowedRoleNames =
    type === "tester" ? ["Manager", "Admin", "Mod"] : ["Manager"];
  const allowedRoleIds =
    type === "tester"
      ? ["MANAGER_ROLE_ID", "ADMIN_ROLE_ID", "MOD_ROLE_ID"]
      : ["MANAGER_ROLE_ID"];
  return roles.some(
    (role) =>
      memberRoles.includes(role.id) &&
      (allowedRoleNames.some(
        (name) => role.name.toLowerCase() === name.toLowerCase(),
      ) ||
        allowedRoleIds.some(
          (envName) => process.env[envName]?.trim() === role.id,
        )),
  );
}

const TESTER_QUESTION_KEYS = [
  "currentTier",
  "age",
  "reason",
  "previousTester",
  "testsPerWeek",
] as const;
const TESTER_QUESTIONS = [
  "Which tier are you currently?",
  "How old are you?",
  "Why should we choose you as a Tester?",
  "Have you ever been a Tester on another tier list? If yes, which one?",
  "How many tests can you complete per week?",
] as const;
const STAFF_QUESTION_KEYS = [
  "age",
  "reason",
  "previousStaff",
  "position",
] as const;
const STAFF_QUESTIONS = [
  "How old are you?",
  "Why should we choose you for the NexusTiers Staff Team?",
  "Do you have previous staff experience? If yes, explain.",
] as const;
const activeApplicationSteps = new Set<string>();

function applicationQuestion(type: ApplicationType, step: number) {
  const questions = type === "tester" ? TESTER_QUESTIONS : STAFF_QUESTIONS;
  const question = questions[step - 1];
  if (!question) throw new Error("This application question is not available.");
  return `Question ${step}/${questions.length}\n\n${question}`;
}

async function sendNextApplicationStep(application: NexusApplication) {
  if (application.type === "tester") {
    if (
      application.currentStep >= 1 &&
      application.currentStep <= TESTER_QUESTIONS.length
    ) {
      await sendDirectMessage(
        application.userId,
        applicationQuestion("tester", application.currentStep),
      );
    } else if (application.currentStep > TESTER_QUESTIONS.length) {
      await submitCompletedApplication(application);
    }
    return;
  }

  if (
    application.currentStep >= 1 &&
    application.currentStep <= STAFF_QUESTIONS.length
  ) {
    await sendDirectMessage(
      application.userId,
      applicationQuestion("staff", application.currentStep),
    );
  } else if (application.currentStep === STAFF_QUESTIONS.length + 1) {
    await sendDirectMessage(
      application.userId,
      `Question ${STAFF_QUESTIONS.length + 1}/${STAFF_QUESTIONS.length + 1}\n\nWhat position are you applying for?`,
      { components: applicationPositionSelect(application.id) },
    );
  }
}

async function applicationForUser(applicationId: string, userId: string) {
  const state = await getState();
  const application = state.applications.find(
    (item) => item.id === applicationId,
  );
  if (!application || application.userId !== userId)
    throw new Error("This application does not belong to you.");
  return application;
}

async function beginApplication(
  interaction: DiscordInteraction,
  type: ApplicationType,
) {
  const guildId = interaction.guild_id;
  const user = actor(interaction);
  if (!guildId)
    throw new Error("Applications can only be started from a Discord server.");
  const application = await createApplication({
    type,
    guildId,
    userId: user.id,
    username: user.username,
    applicationChannelId: interaction.channel_id,
  });
  try {
    const dmChannelId = await sendDirectMessage(
      user.id,
      "Would you like to start your application?",
      { components: applicationStartComponents(application.id) },
    );
    await updateApplication(application.id, { dmChannelId });
    await respond(
      interaction,
      "Check your DMs to start your application.",
      true,
    );
  } catch (error) {
    await updateApplication(application.id, { status: "cancelled" }).catch(
      () => undefined,
    );
    throw error;
  }
}

async function startApplication(
  interaction: DiscordInteraction,
  applicationId: string,
) {
  const application = await applicationForUser(
    applicationId,
    actor(interaction).id,
  );
  if (application.status !== "in_progress")
    throw new Error("This application is no longer open.");
  if (application.currentStep !== -1) {
    await respond(
      interaction,
      "This application has already started. Continue in your DMs.",
      true,
    );
    return;
  }
  if (application.type === "tester") {
    const dmChannelId = await sendDirectMessage(
      application.userId,
      "Which kit would you like to become a Tester for?",
      { components: applicationKitSelect(application.id) },
    );
    await updateApplication(application.id, { currentStep: 0, dmChannelId });
  } else {
    const dmChannelId = await sendDirectMessage(
      application.userId,
      applicationQuestion("staff", 1),
    );
    await updateApplication(application.id, { currentStep: 1, dmChannelId });
  }
  await respond(
    interaction,
    "Your application has started. Continue in your DMs.",
    true,
  );
}

async function cancelApplication(
  interaction: DiscordInteraction,
  applicationId: string,
) {
  const application = await applicationForUser(
    applicationId,
    actor(interaction).id,
  );
  if (
    application.status === "in_progress" ||
    application.status === "submitted"
  ) {
    await updateApplication(application.id, { status: "cancelled" });
  }
  await respond(interaction, "Your application has been cancelled.", true);
}

function applicationAnswerFields(application: NexusApplication) {
  const entries: Array<[string, string]> =
    application.type === "tester"
      ? [
          ["Kit", application.kit ?? "N/A"],
          ["Current Tier", application.answers.currentTier ?? "N/A"],
          ["Age", application.answers.age ?? "N/A"],
          [
            "Why should we choose you as a Tester?",
            application.answers.reason ?? "N/A",
          ],
          [
            "Previous Tester Experience",
            application.answers.previousTester ?? "N/A",
          ],
          ["Tests per Week", application.answers.testsPerWeek ?? "N/A"],
        ]
      : [
          ["Age", application.answers.age ?? "N/A"],
          [
            "Why should we choose you for the NexusTiers Staff Team?",
            application.answers.reason ?? "N/A",
          ],
          [
            "Previous Staff Experience",
            application.answers.previousStaff ?? "N/A",
          ],
          ["Position", application.answers.position ?? "N/A"],
        ];
  return entries.flatMap(([name, value]) => {
    const chunks = value.match(/[\s\S]{1,1024}/g) ?? ["N/A"];
    return chunks.map((chunk, index) => ({
      name: index === 0 ? name : `${name} (continued)`,
      value: chunk,
      inline: false,
    }));
  });
}

async function submitCompletedApplication(application: NexusApplication) {
  try {
    const state = await getState();
    const configuredChannelId =
      state.applicationChannels?.[application.guildId]?.[application.type] ??
      application.applicationChannelId;
    const channel = await findApplicationChannel(
      application.guildId,
      application.type === "tester"
        ? "TESTER_APPLICATIONS_CHANNEL_ID"
        : "STAFF_APPLICATIONS_CHANNEL_ID",
      application.type === "tester"
        ? "tester-applications"
        : "staff-applications",
      configuredChannelId,
    );
    if (!channel) {
      throw new Error(
        `The ${application.type} applications channel was not found. Use /application${application.type} set in the desired channel.`,
      );
    }
    const message = await postToChannel(channel.id, "", {
      embeds: [
        {
          title:
            application.type === "tester"
              ? "🧪 Tester Application"
              : "🛡️ Staff Application",
          description: `Applicant: <@${application.userId}> (${application.username})`,
          color: application.type === "tester" ? 0x57f287 : 0xfee75c,
          fields: applicationAnswerFields(application),
          footer: { text: "NexusTiers Application Review" },
        },
      ],
      components: applicationReviewComponents(application.id),
    });
    await updateApplication(application.id, {
      status: "submitted",
      reviewChannelId: channel.id,
      reviewMessageId: message.id,
    });
    await sendDirectMessage(
      application.userId,
      `Your ${application.type === "tester" ? "Tester" : "Staff"} Application has been submitted for review.`,
    );
  } catch (error) {
    logger.error(
      { error, applicationId: application.id },
      "Could not submit Discord application",
    );
    await sendDirectMessage(
      application.userId,
      `Your application could not be submitted yet. The server owner must use /application${application.type} set in the desired channel.`,
    ).catch(() => undefined);
  }
}

async function handleApplicationKitSelection(
  interaction: DiscordInteraction,
  applicationId: string,
) {
  const application = await applicationForUser(
    applicationId,
    actor(interaction).id,
  );
  if (
    application.status !== "in_progress" ||
    application.type !== "tester" ||
    application.currentStep !== 0
  ) {
    throw new Error("This application is not waiting for a kit selection.");
  }
  const kit = interaction.data?.values?.[0]?.toLowerCase();
  if (!kit || !KITS.includes(kit as (typeof KITS)[number]))
    throw new Error("Please select a valid kit.");
  const updated = await updateApplication(application.id, {
    kit,
    currentStep: 1,
  });
  await sendNextApplicationStep(updated);
  await respond(interaction, "Kit selected. Continue in your DMs.", true);
}

async function handleApplicationPositionSelection(
  interaction: DiscordInteraction,
  applicationId: string,
) {
  const application = await applicationForUser(
    applicationId,
    actor(interaction).id,
  );
  if (
    application.status !== "in_progress" ||
    application.type !== "staff" ||
    application.currentStep !== 4
  ) {
    throw new Error(
      "This application is not waiting for a position selection.",
    );
  }
  const position = interaction.data?.values?.[0];
  if (!position || !["Manager", "Admin", "Mod", "Helper"].includes(position)) {
    throw new Error("Please select a valid position.");
  }
  const updated = await updateApplication(application.id, {
    answers: { ...application.answers, position },
    currentStep: 5,
  });
  await submitCompletedApplication(updated);
  await respond(
    interaction,
    "Your application has been submitted for review.",
    true,
  );
}

async function handleDirectMessage(message: DiscordMessage) {
  if (
    message.guild_id ||
    (message.channel_type !== undefined && message.channel_type !== 1) ||
    message.author?.bot ||
    !message.author?.id ||
    !message.content?.trim()
  )
    return;
  try {
    const state = await getState();
    const application = state.applications.find(
      (item) =>
        item.status === "in_progress" &&
        item.userId === message.author?.id &&
        item.dmChannelId === message.channel_id,
    );
    if (!application) return;

    if (activeApplicationSteps.has(application.id)) {
      await sendDirectMessage(
        application.userId,
        "Please wait a moment while I save your previous answer and send the next question.",
      );
      return;
    }
    activeApplicationSteps.add(application.id);

    try {
      if (
        application.type === "tester" &&
        application.currentStep >= 1 &&
        application.currentStep <= 5
      ) {
        const key = TESTER_QUESTION_KEYS[application.currentStep - 1];
        const updated = await updateApplication(application.id, {
          answers: { ...application.answers, [key]: message.content.trim() },
          currentStep: application.currentStep + 1,
        });
        await sendNextApplicationStep(updated);
        return;
      }

      if (
        application.type === "staff" &&
        application.currentStep >= 1 &&
        application.currentStep <= 3
      ) {
        const key = STAFF_QUESTION_KEYS[application.currentStep - 1];
        const updated = await updateApplication(application.id, {
          answers: { ...application.answers, [key]: message.content.trim() },
          currentStep: application.currentStep + 1,
        });
        await sendNextApplicationStep(updated);
      }
    } finally {
      activeApplicationSteps.delete(application.id);
    }
  } catch (error) {
    logger.error(
      { error, userId: message.author?.id, channelId: message.channel_id },
      "Direct message application handling failed",
    );
  }
}

async function assignApplicationRoles(
  application: NexusApplication,
  botUserId?: string,
) {
  const memberResponse = await rest(
    `/guilds/${application.guildId}/members/${application.userId}`,
  );
  if (!memberResponse.ok) {
    logger.warn(
      {
        applicationId: application.id,
        userId: application.userId,
        status: memberResponse.status,
      },
      "Could not find the applicant in the Discord server while assigning roles",
    );
    return;
  }
  const member = (await memberResponse.json()) as DiscordGuildMember;
  const roles = await getGuildRoles(application.guildId);
  if (hasRestrictedRole(member.roles, roles)) {
    logger.info(
      { applicationId: application.id, userId: application.userId },
      "Skipped application roles because the applicant is Restricted",
    );
    return;
  }

  const requestedRoles =
    application.type === "tester"
      ? [
          {
            envNames: ["VERIFIED_TESTER_ROLE_ID", "DISCORD_TESTER_ROLE_ID"],
            name: "Verified Tester",
          },
          {
            envNames: [
              `TESTER_${(application.kit ?? "").toUpperCase()}_ROLE_ID`,
              `${(application.kit ?? "").toUpperCase()}_TESTER_ROLE_ID`,
            ],
            name: `${KIT_LABELS[application.kit as keyof typeof KIT_LABELS] ?? application.kit} Tester`,
          },
        ]
      : [
          {
            envNames: [
              `STAFF_${(application.answers.position ?? "").toUpperCase()}_ROLE_ID`,
              `${(application.answers.position ?? "").toUpperCase()}_ROLE_ID`,
            ],
            name: application.answers.position ?? "Staff",
          },
        ];

  for (const requestedRole of requestedRoles) {
    const role = await findRoleWithConfig(
      application.guildId,
      requestedRole.envNames,
      requestedRole.name,
      roles,
    );
    if (!role) {
      logger.warn(
        { applicationId: application.id, roleName: requestedRole.name },
        "Application role was not found; the application decision was still saved",
      );
      continue;
    }
    await assignAutomaticRole(
      application.guildId,
      member,
      role,
      roles,
      botUserId,
    );
  }
}

async function handleApplicationDecision(
  interaction: DiscordInteraction,
  action: "accept" | "reject",
  applicationId: string,
  botUserId?: string,
) {
  const guildId = interaction.guild_id;
  if (!guildId)
    throw new Error("Application reviews can only be handled in a server.");
  const state = await getState();
  const application = state.applications.find(
    (item) => item.id === applicationId,
  );
  if (!application || application.guildId !== guildId)
    throw new Error("Application not found.");
  if (application.status !== "submitted") {
    await respond(
      interaction,
      "This application has already been decided.",
      true,
    );
    return;
  }
  if (!(await hasApplicationReviewPermission(interaction, application.type))) {
    await respond(
      interaction,
      application.type === "tester"
        ? "You need the Owner, Manager, Admin, or Mod role to review Tester Applications."
        : "Only the Owner or Manager can review Staff Applications.",
      true,
    );
    return;
  }

  const nextStatus = action === "accept" ? "accepted" : "rejected";
  const updated = await updateApplication(application.id, {
    status: nextStatus,
    decisionBy: actor(interaction).id,
    decidedAt: new Date().toISOString(),
  });
  if (updated.reviewChannelId && updated.reviewMessageId) {
    await rest(
      `/channels/${updated.reviewChannelId}/messages/${updated.reviewMessageId}`,
      {
        method: "PATCH",
        body: JSON.stringify({
          components: applicationReviewComponents(updated.id, true),
        }),
      },
    ).catch((error) =>
      logger.warn(
        { error, applicationId },
        "Could not disable application review buttons",
      ),
    );
  }
  if (action === "accept") await assignApplicationRoles(updated, botUserId);
  await sendDirectMessage(
    updated.userId,
    updated.type === "tester"
      ? `Your Tester Application has been ${action === "accept" ? "accepted!" : "rejected."}`
      : action === "accept"
        ? "Your Staff Application has been accepted!"
        : "Your Staff Application has been rejected.",
  );
  await respond(
    interaction,
    `Application ${action === "accept" ? "accepted" : "rejected"}.`,
    true,
  );
}

async function handleApplicationComponent(
  interaction: DiscordInteraction,
  customId: string,
  botUserId?: string,
) {
  const [action, value] = customId.split(":");
  if (action === "application_panel") {
    if (value !== "tester" && value !== "staff")
      throw new Error("Unknown application type.");
    await beginApplication(interaction, value);
    return;
  }
  const applicationId = value;
  if (!applicationId) throw new Error("Invalid application component.");
  if (action === "application_start") {
    await startApplication(interaction, applicationId);
  } else if (action === "application_cancel") {
    await cancelApplication(interaction, applicationId);
  } else if (action === "application_kit") {
    await handleApplicationKitSelection(interaction, applicationId);
  } else if (action === "application_position") {
    await handleApplicationPositionSelection(interaction, applicationId);
  } else if (
    action === "application_accept" ||
    action === "application_reject"
  ) {
    await handleApplicationDecision(
      interaction,
      action === "application_accept" ? "accept" : "reject",
      applicationId,
      botUserId,
    );
  }
}

const verificationPanel = {
  embeds: [
    {
      title: "📝 Evaluation Testing Waitlist",
      description: [
        "Upon applying, you will be added to a waitlist channel.",
        "Here you will be pinged when a tester of your region is available.",
        "If you are HT3 or higher, a high ticket will be created.",
        "",
        "• Region should be the region of the server you wish to test on",
        "",
        "• Username should be the name of the account you will be testing on",
        "",
        "🛑 **Failure to provide authentic information will result in a denied test.**",
      ].join("\n"),
      color: 0xff0d63,
    },
  ],
  components: [
    {
      type: 1,
      components: [
        {
          type: 2,
          style: 1,
          label: "Verify Account",
          custom_id: "nexus_verify_account",
        },
        {
          type: 2,
          style: 1,
          label: "Enter Waitlist",
          custom_id: "nexus_enter_waitlist",
        },
      ],
    },
    {
      type: 1,
      components: [
        {
          type: 2,
          style: 1,
          label: "View Cooldown",
          custom_id: "nexus_view_cooldown",
        },
      ],
    },
  ],
};

async function postVerificationPanel(guildId: string) {
  const requestTestChannel = await findChannel(guildId, "request-test");
  if (!requestTestChannel) {
    throw new Error(
      "The 📩・request-test channel was not found. Ask a server administrator to configure the Discord channels.",
    );
  }
  await postToChannel(requestTestChannel.id, "", verificationPanel);
  return requestTestChannel;
}

function findOption(
  options: DiscordOption[] | undefined,
  name: string,
): DiscordOption | undefined {
  for (const item of options ?? []) {
    if (item.name === name && item.value !== undefined) return item;
    const nested = findOption(item.options, name);
    if (nested) return nested;
  }
  return undefined;
}

function option(interaction: DiscordInteraction, name: string) {
  return findOption(interaction.data?.options, name)?.value;
}

function requiredOption(interaction: DiscordInteraction, name: string) {
  const value = option(interaction, name);
  if (!value) throw new Error(`Please select an option for \`${name}\`.`);
  return value;
}

function actor(interaction: DiscordInteraction) {
  return (
    interaction.member?.user ??
    interaction.user ?? { id: "unknown", username: "Discord user" }
  );
}

function hasTesterPermission(interaction: DiscordInteraction) {
  const permissions = BigInt(interaction.member?.permissions ?? "0");
  const administrator = (permissions & 0x8n) === 0x8n;
  const configuredRole = process.env.DISCORD_TESTER_ROLE_ID;
  const hasRole = Boolean(
    configuredRole && interaction.member?.roles?.includes(configuredRole),
  );
  return administrator || hasRole;
}

async function hasRestrictionPermission(interaction: DiscordInteraction) {
  if (!interaction.guild_id) return false;
  const userId = actor(interaction).id;
  if ((await getGuildOwnerId(interaction.guild_id)) === userId) return true;
  const configuredRoleIds = [
    process.env.MANAGER_ROLE_ID?.trim(),
    process.env.ADMIN_ROLE_ID?.trim(),
  ].filter((roleId): roleId is string => Boolean(roleId));
  if (
    configuredRoleIds.some((roleId) =>
      interaction.member?.roles?.includes(roleId),
    )
  )
    return true;
  const roles = await getGuildRoles(interaction.guild_id);
  return roles.some(
    (role) =>
      interaction.member?.roles?.includes(role.id) &&
      (role.name.toLowerCase() === "manager" ||
        role.name.toLowerCase() === "admin"),
  );
}

async function hasQueueTesterPermission(interaction: DiscordInteraction) {
  const permissions = BigInt(interaction.member?.permissions ?? "0");
  const administrator = (permissions & 0x8n) === 0x8n;
  const configuredRoles = [
    process.env.DISCORD_TESTER_ROLE_ID?.trim(),
    process.env.VERIFIED_TESTER_ROLE_ID?.trim(),
  ].filter((roleId): roleId is string => Boolean(roleId));
  if (administrator || configuredRoles.some((roleId) => interaction.member?.roles?.includes(roleId))) {
    return true;
  }
  const guildId = interaction.guild_id;
  if (!guildId || !isNexusTestingGuild(guildId)) return false;
  const testerRoleNames = new Set(["tester", "verified tester"]);
  const roles = await getGuildRoles(guildId);
  return roles.some(
    (role) =>
      interaction.member?.roles?.includes(role.id) &&
      testerRoleNames.has(role.name.toLowerCase()),
  );
}

function hasManageRolesPermission(interaction: DiscordInteraction) {
  const permissions = BigInt(interaction.member?.permissions ?? "0");
  const administrator = (permissions & 0x8n) === 0x8n;
  const manageRoles = (permissions & 0x10000000n) === 0x10000000n;
  return administrator || manageRoles;
}

function hasManageChannelsPermission(interaction: DiscordInteraction) {
  const permissions = BigInt(interaction.member?.permissions ?? "0");
  const administrator = (permissions & 0x8n) === 0x8n;
  const manageChannels = (permissions & 0x10n) === 0x10n;
  return administrator || manageChannels;
}

async function hasApplicationPanelPermission(interaction: DiscordInteraction) {
  const permissions = BigInt(interaction.member?.permissions ?? "0");
  const administrator = (permissions & 0x8n) === 0x8n;
  const manageGuild = (permissions & 0x20n) === 0x20n;
  return (
    administrator ||
    manageGuild ||
    (interaction.guild_id
      ? (await getGuildOwnerId(interaction.guild_id)) === actor(interaction).id
      : false)
  );
}

async function setApplicationChannel(
  interaction: DiscordInteraction,
  type: ApplicationType,
) {
  if (!interaction.guild_id) {
    await respond(
      interaction,
      "This command can only be used in a server.",
      true,
    );
    return;
  }

  if ((await getGuildOwnerId(interaction.guild_id)) !== actor(interaction).id) {
    await respond(
      interaction,
      "Only the server owner can use this command.",
      true,
    );
    return;
  }

  const channelId = interaction.channel_id?.trim();
  if (!channelId)
    throw new Error("This command must be run in a text channel.");
  const channelResponse = await rest(`/channels/${channelId}`);
  if (!channelResponse.ok)
    throw new Error(
      `Could not inspect the Discord channel: ${channelResponse.status}`,
    );
  const channel = (await channelResponse.json()) as {
    id: string;
    name?: string;
    type?: number;
  };
  if (channel.type !== 0)
    throw new Error("Please run this command in a regular text channel.");

  const state = await getState();
  state.applicationChannels = state.applicationChannels ?? {};
  state.applicationChannels[interaction.guild_id] = {
    ...state.applicationChannels[interaction.guild_id],
    [type]: channel.id,
  };
  await saveState(state);

  const label = type === "tester" ? "Tester" : "Staff";
  const completedApplications = state.applications.filter(
    (application) =>
      application.guildId === interaction.guild_id &&
      application.type === type &&
      application.status === "in_progress" &&
      (type === "tester"
        ? application.currentStep > TESTER_QUESTIONS.length
        : application.currentStep > STAFF_QUESTIONS.length + 1),
  );
  let recovered = 0;
  for (const application of completedApplications) {
    await submitCompletedApplication(application);
    if (application.status === "submitted") recovered += 1;
  }
  const recoveredMessage =
    recovered > 0
      ? ` ${recovered} previously completed application(s) were also published.`
      : "";
  await respond(
    interaction,
    `${label} applications will now be collected in <#${channel.id}>.${recoveredMessage}`,
    true,
  );
}

async function getCurrentGuildBoosts(guildId: string) {
  const activeBoosts: Record<string, string> = {};
  let after: string | undefined;

  while (true) {
    const query = new URLSearchParams({ limit: "1000" });
    if (after) query.set("after", after);

    const response = await rest(
      `/guilds/${guildId}/members?${query.toString()}`,
    );
    if (!response.ok) {
      throw new Error(
        `Could not sync current server boosters: ${response.status}`,
      );
    }

    const members = (await response.json()) as DiscordGuildMember[];
    for (const member of members) {
      const userId = member.user?.id;
      if (userId && member.premium_since)
        activeBoosts[userId] = member.premium_since;
    }

    if (members.length < 1000) return activeBoosts;
    const nextAfter = members[members.length - 1]?.user?.id;
    if (!nextAfter || nextAfter === after) return activeBoosts;
    after = nextAfter;
  }
}

async function setBoosterAlertChannel(
  interaction: DiscordInteraction,
  botUserId?: string,
) {
  const guildId = interaction.guild_id;
  if (!guildId) {
    await respond(
      interaction,
      "Dieser Befehl kann nur in einem Server verwendet werden.",
      true,
    );
    return;
  }

  if ((await getGuildOwnerId(guildId)) !== actor(interaction).id) {
    await respond(
      interaction,
      "Nur der Serverinhaber darf `/boosteralert` verwenden.",
      true,
    );
    return;
  }

  const channelId = interaction.channel_id?.trim();
  if (!channelId)
    throw new Error(
      "Führe `/boosteralert` in einem Textkanal dieses Servers aus.",
    );
  const channel = await getChannel(channelId);
  if (channel.type !== 0 || channel.guild_id !== guildId) {
    throw new Error(
      "Führe `/boosteralert` in einem normalen Textkanal dieses Servers aus.",
    );
  }
  if (!botUserId)
    throw new Error(
      "Der Bot ist noch nicht bereit. Bitte versuche es gleich noch einmal.",
    );

  await deferResponse(interaction, true);
  const state = await getState();
  state.boosterAlertChannels ??= {};
  state.boosterAlertBoosts ??= {};
  state.boosterAlertChannels[guildId] = channelId;
  state.boosterAlertBoosts[guildId] ??= {};
  await saveState(state);

  let syncedExistingBoosts = false;
  try {
    const currentBoosts = await getCurrentGuildBoosts(guildId);
    state.boosterAlertBoosts[guildId] = {
      ...state.boosterAlertBoosts[guildId],
      ...currentBoosts,
    };
    await saveState(state);
    syncedExistingBoosts = true;
  } catch (error) {
    logger.warn(
      { error, guildId },
      "Could not prime active boosters for boost alerts",
    );
  }

  let canPostInChannel = true;
  try {
    await postToChannel(
      channelId,
      "✅ Boost-Benachrichtigungen sind ab jetzt in diesem Channel aktiv.",
    );
  } catch (error) {
    canPostInChannel = false;
    logger.warn(
      { error, guildId, channelId },
      "Could not post boost-alert setup confirmation",
    );
  }

  const status = canPostInChannel
    ? `Boost-Alert ist jetzt in <#${channelId}> aktiv.`
    : `Der Channel <#${channelId}> ist gespeichert, aber der Bot kann dort nicht schreiben. Gib ihm die Berechtigung „Nachrichten senden“.`;
  const syncStatus = syncedExistingBoosts
    ? " Bereits aktive Booster wurden übernommen und lösen keine nachträgliche Meldung aus."
    : " Aktive Booster konnten nicht abgeglichen werden; neue Boosts werden trotzdem gemeldet.";
  await editDeferredResponse(botUserId, interaction, `${status}${syncStatus}`);
}

async function setResultChannel(interaction: DiscordInteraction) {
  const guildId = interaction.guild_id;
  if (!guildId) {
    await respond(
      interaction,
      "Dieser Befehl kann nur in einem Server verwendet werden.",
      true,
    );
    return;
  }

  if ((await getGuildOwnerId(guildId)) !== actor(interaction).id) {
    await respond(
      interaction,
      "Nur der Serverinhaber darf `/setresult` verwenden.",
      true,
    );
    return;
  }

  const channelId = interaction.channel_id?.trim();
  if (!channelId) {
    throw new Error(
      "Führe `/setresult` in dem Textkanal aus, in dem Ergebnisse erscheinen sollen.",
    );
  }
  const channel = await getChannel(channelId);
  if (channel.type !== 0 || channel.guild_id !== guildId) {
    throw new Error(
      "Führe `/setresult` in einem normalen Textkanal dieses Servers aus.",
    );
  }

  const state = await getState();
  state.resultChannels ??= {};
  state.resultChannels[guildId] = channelId;
  await saveState(state);

  let canPostInChannel = true;
  try {
    await postToChannel(
      channelId,
      "✅ Dieser Channel ist jetzt für alle neuen Testergebnisse eingerichtet.",
    );
  } catch (error) {
    canPostInChannel = false;
    logger.warn(
      { error, guildId, channelId },
      "Could not post result-channel setup confirmation",
    );
  }

  const status = canPostInChannel
    ? `Alle neuen Testergebnisse werden ab jetzt in <#${channelId}> gepostet.`
    : `Der Results-Channel <#${channelId}> ist gespeichert, aber der Bot kann dort nicht schreiben. Gib ihm die Berechtigung „Nachrichten senden“.`;
  await respond(interaction, status, true);
}

function findSubcommand(
  options: DiscordOption[] | undefined,
): string | undefined {
  for (const item of options ?? []) {
    if (
      item.type === 1 ||
      String(item.type) === "1" ||
      item.name === "role" ||
      item.name === "all"
    ) {
      return item.name;
    }
    const nested = findSubcommand(item.options);
    if (nested) return nested;
  }
  return undefined;
}

function subcommand(interaction: DiscordInteraction) {
  return findSubcommand(interaction.data?.options);
}

function parseManualTierSpec(value: string) {
  const assignments = value
    .split(/[,;]+/)
    .map((part) => part.trim())
    .filter(Boolean)
    .map((part) => {
      const match = part.match(
        /^([a-z]+)\s*(?::|=|\s)\s*(n\/a|lt[1-5]|ht[1-5])$/i,
      );
      if (!match) {
        throw new Error("Use tiers like `sword:lt4,mace:ht5`.");
      }
      return { kit: match[1].toLowerCase(), tier: match[2].toLowerCase() };
    });

  if (assignments.length === 0)
    throw new Error("At least one kit and tier is required.");
  for (const assignment of assignments) {
    if (!KITS.includes(assignment.kit as (typeof KITS)[number])) {
      throw new Error(
        `Unknown kit \`${assignment.kit}\`. Allowed kits: ${KITS.join(", ")}.`,
      );
    }
    if (!TIERS.includes(assignment.tier as (typeof TIERS)[number])) {
      throw new Error(
        `Unknown tier \`${assignment.tier}\`. Allowed tiers: ${TIERS.join(", ")}.`,
      );
    }
    if (assignments.filter((item) => item.kit === assignment.kit).length > 1) {
      throw new Error(
        `Only one tier per kit can be set at a time: \`${assignment.kit}\`.`,
      );
    }
  }
  return assignments;
}

async function respond(
  interaction: DiscordInteraction,
  content: string,
  ephemeral = false,
  components?: DiscordComponent[],
) {
  await rest(`/interactions/${interaction.id}/${interaction.token}/callback`, {
    method: "POST",
    body: JSON.stringify({
      type: 4,
      data: {
        content,
        flags: ephemeral ? 64 : 0,
        ...(components ? { components } : {}),
      },
    }),
  });
}

async function deferResponse(
  interaction: DiscordInteraction,
  ephemeral = false,
) {
  const response = await rest(
    `/interactions/${interaction.id}/${interaction.token}/callback`,
    {
      method: "POST",
      body: JSON.stringify({
        type: 5,
        data: { flags: ephemeral ? 64 : 0 },
      }),
    },
  );
  if (!response.ok) {
    throw new Error(
      `Could not defer the Discord interaction: ${response.status}`,
    );
  }
  deferredInteractionIds.add(interaction.id);
}

async function editDeferredResponse(
  applicationId: string,
  interaction: DiscordInteraction,
  content: string,
  components?: DiscordComponent[],
) {
  const response = await rest(
    `/webhooks/${applicationId}/${interaction.token}/messages/@original`,
    {
      method: "PATCH",
      body: JSON.stringify({
        content,
        ...(components ? { components } : {}),
      }),
    },
  );
  if (!response.ok) {
    throw new Error(
      `Could not update the deferred Discord response: ${response.status}`,
    );
  }
  deferredInteractionIds.delete(interaction.id);
}

async function deferComponentUpdate(interaction: DiscordInteraction) {
  const response = await rest(
    `/interactions/${interaction.id}/${interaction.token}/callback`,
    {
      method: "POST",
      body: JSON.stringify({ type: 6 }),
    },
  );
  if (!response.ok) {
    throw new Error(
      `Could not defer the Discord selection: ${response.status}`,
    );
  }
  deferredInteractionIds.add(interaction.id);
}

async function respondWithEmbed(
  interaction: DiscordInteraction,
  embed: Record<string, unknown>,
  ephemeral = false,
) {
  await rest(`/interactions/${interaction.id}/${interaction.token}/callback`, {
    method: "POST",
    body: JSON.stringify({
      type: 4,
      data: {
        embeds: [embed],
        flags: ephemeral ? 64 : 0,
      },
    }),
  });
}

async function showModal(
  interaction: DiscordInteraction,
  customId: string,
  title: string,
  components: DiscordComponent[],
) {
  await rest(`/interactions/${interaction.id}/${interaction.token}/callback`, {
    method: "POST",
    body: JSON.stringify({
      type: 9,
      data: { custom_id: customId, title, components },
    }),
  });
}

function componentValue(
  components: DiscordComponent[] | undefined,
  customId: string,
): string | undefined {
  for (const component of components ?? []) {
    if (component.custom_id === customId) return component.value;
    const nested = componentValue(component.components, customId);
    if (nested !== undefined) return nested;
  }
  return undefined;
}

async function registerCommands(applicationId: string) {
  const commands = [
    {
      name: "tester",
      description: "Tester commands and help",
      options: [
        {
          name: "info",
          description: "Show all NexusTiers commands and usage",
          type: 1,
        },
      ],
    },
    {
      name: "open",
      description: "Open the queue for this waitlist channel",
    },
    {
      name: "close",
      description: "Close the queue for this waitlist channel",
    },
    {
      name: "leave",
      description: "Leave the current queue",
    },
    {
      name: "testerleave",
      description: "Leave only the tester queue for this waitlist",
    },
    {
      name: "testerjoin",
      description: "Join only the tester queue for this waitlist",
    },
    {
      name: "next",
      description: "Open the next tester ticket for this channel",
    },
    {
      name: "eval",
      description: "Send the active test ticket to staff for evaluation",
    },
    {
      name: "add",
      description: "Give a tier role access to the active test ticket",
      options: [
        {
          name: "tier",
          description: "Tier of the role to add",
          type: 3,
          required: true,
          choices: TIERS.filter((tier) => tier !== "N/A").map((tier) => ({
            name: tier.toUpperCase(),
            value: tier,
          })),
        },
        {
          name: "kit",
          description: "Kit of the role to add",
          type: 3,
          required: true,
          choices: KITS.map((kit) => ({ name: KIT_LABELS[kit], value: kit })),
        },
      ],
    },
    {
      name: "skip",
      description: "Skip the current ticket for this channel",
    },
    {
      name: "result",
      description: "Save the current ticket result",
      options: [
        {
          name: "tier",
          description: "New tier",
          type: 3,
          required: true,
          choices: TIERS.map((tier) => ({ name: tier, value: tier })),
        },
      ],
    },
    {
      name: "leaderboard",
      description:
        "Post or refresh the testing leaderboard (server owner only)",
    },
    {
      name: "adminresult",
      description: "Save a tier result without an active test ticket",
      options: [
        {
          name: "discord",
          description: "Discord member to mention",
          type: 6,
          required: true,
        },
        {
          name: "minecraft",
          description: "Minecraft username",
          type: 3,
          required: true,
        },
        {
          name: "tier",
          description: "Tier to assign",
          type: 3,
          required: true,
          choices: TIERS.map((tier) => ({ name: tier, value: tier })),
        },
        {
          name: "kit",
          description: "Kit for this result",
          type: 3,
          required: true,
          choices: KITS.map((kit) => ({ name: KIT_LABELS[kit], value: kit })),
        },
      ],
    },
    {
      name: "cooldown",
      description: "Manage per-kit player cooldowns",
      options: [
        {
          name: "remove",
          description: "Remove one player's cooldown for one kit",
          type: 1,
          options: [
            {
              name: "discord",
              description: "Discord user",
              type: 6,
              required: true,
            },
            {
              name: "minecraft",
              description: "Minecraft username",
              type: 3,
              required: true,
            },
            {
              name: "kit",
              description: "Kit whose cooldown should be removed",
              type: 3,
              required: true,
              choices: KITS.map((kit) => ({
                name: KIT_LABELS[kit],
                value: kit,
              })),
            },
          ],
        },
        {
          name: "set",
          description: "Set the default cooldown duration for one kit",
          type: 1,
          options: [
            {
              name: "kit",
              description: "Kit whose cooldown duration should be changed",
              type: 3,
              required: true,
              choices: KITS.map((kit) => ({
                name: KIT_LABELS[kit],
                value: kit,
              })),
            },
            {
              name: "duration",
              description: "For example 3d, 24h, or 30m",
              type: 3,
              required: true,
            },
          ],
        },
      ],
    },
    {
      name: "verify",
      description: "Postet das NexusTiers Verifizierungs- und Waitlist-Panel",
    },
    {
      name: "rules",
      description: "Post the NexusTiers server rules",
    },
    {
      name: "applications",
      description: "Post the Tester and Staff application panel",
    },
    {
      name: "tickets",
      description: "Post the NexusTiers support ticket panel",
    },
    {
      name: "hightickets",
      description: "Request a private High Tier ticket",
    },
    {
      name: "create",
      description: "Create missing NexusTiers roles",
      options: [
        {
          name: "new",
          description: "Create all tier, kit, and waitlist roles",
          type: 1,
        },
      ],
    },
    {
      name: "debuff",
      description: "Create Debuff tier, kit, and waitlist roles",
    },
    {
      name: "change",
      description: "Change the colors of NexusTiers roles",
    },
    {
      name: "sort",
      description: "Sort tiers, Member, tester, queue and Restricted roles",
    },
    {
      name: "channels",
      description:
        "Create the emoji channel layout shown in the setup screenshots",
    },
    {
      name: "waitlist",
      description: "Create private waitlist channels for every kit",
    },
    {
      name: "requesttest",
      description:
        "Post the Evaluation Testing Waitlist panel in the request-test channel",
    },
    {
      name: "applicationstaff",
      description: "Set the channel for completed Staff applications",
      options: [
        {
          name: "set",
          description: "Use this channel for completed Staff applications",
          type: 1,
        },
      ],
    },
    {
      name: "applicationtester",
      description: "Set the channel for completed Tester applications",
      options: [
        {
          name: "set",
          description: "Use this channel for completed Tester applications",
          type: 1,
        },
      ],
    },
    {
      name: "boosteralert",
      description:
        "Owner-only: set this channel for server boost notifications",
    },
    {
      name: "setresult",
      description: "Owner-only: post all test results in this channel",
    },
    {
      name: "clear",
      description: "Clear all website tiers for a Minecraft user",
      options: [
        {
          name: "minecraft",
          description: "Minecraft username whose tiers should be removed",
          type: 3,
          required: true,
        },
      ],
    },
    {
      name: "clearall",
      description: "Owner-only: clear all website tiers",
      options: [
        {
          name: "confirmation",
          description: "Type RESET ALL TIERS to confirm",
          type: 3,
          required: true,
        },
      ],
    },
    {
      name: "restrict",
      description: "Restrict a Discord and Minecraft user",
      options: [
        {
          name: "discord",
          description: "Discord user to restrict",
          type: 6,
          required: true,
        },
        {
          name: "minecraft",
          description: "Minecraft username",
          type: 3,
          required: true,
        },
        {
          name: "duration",
          description: "For example 7d, 12h, 356d, or permanent",
          type: 3,
          required: true,
        },
        {
          name: "reason",
          description: "Select the reason for the restriction",
          type: 3,
          required: true,
          choices: [
            { name: "Cheating", value: "Cheating" },
            { name: "Alting", value: "Alting" },
            { name: "Banned on VTS", value: "Banned on VTS" },
            { name: "Refusing SS", value: "Refusing SS" },
            { name: "Account Sharing", value: "Account Sharing" },
            { name: "Video Evidence", value: "Video Evidence" },
            { name: "Boosting", value: "Boosting" },
          ],
        },
      ],
    },
    {
      name: "unrestrict",
      description: "Remove an active restriction",
      options: [
        {
          name: "discord",
          description: "Restricted Discord user",
          type: 6,
          required: true,
        },
        {
          name: "minecraft",
          description: "Restricted Minecraft username",
          type: 3,
          required: true,
        },
      ],
    },
    {
      name: "user",
      description: "Owner-only manual user tier management",
      options: [
        {
          name: "set",
          description: "Assign tiers without a ticket",
          type: 1,
          options: [
            {
              name: "minecraft",
              description: "Minecraft username",
              type: 3,
              required: true,
            },
            {
              name: "discord",
              description: "Discord name",
              type: 3,
              required: true,
            },
            {
              name: "tiers",
              description: "Use kit:tier, e.g. sword:lt4,mace:ht5",
              type: 3,
              required: true,
            },
          ],
        },
      ],
    },
  ];
  type CommandNode = {
    name?: string;
    options?: CommandNode[];
    choices?: Array<{ name?: string; value: string }>;
    [key: string]: unknown;
  };
  const filterOptionsForGuild = (
    allowedKits: ReadonlySet<string>,
    options: CommandNode[] = [],
  ): CommandNode[] =>
    options.map((option) => ({
      ...option,
      ...(option.name === "kit" && option.choices
        ? { choices: option.choices.filter((choice) => allowedKits.has(choice.value)) }
        : {}),
      ...(option.options
        ? { options: filterOptionsForGuild(allowedKits, option.options) }
        : {}),
    }));

  const clearGlobalResponse = await rest(
    `/applications/${applicationId}/commands`,
    {
      method: "PUT",
      body: JSON.stringify([]),
    },
  );
  if (!clearGlobalResponse.ok) {
    throw new Error(
      `Could not remove old global commands: ${clearGlobalResponse.status} ${await clearGlobalResponse.text()}`,
    );
  }

  for (const guildId of [NEXUS_TIERS_GUILD_ID, NEXUS_SUBTIERS_GUILD_ID]) {
    const path = `/applications/${applicationId}/guilds/${guildId}/commands`;
    const allowedKits = new Set(getKitsForGuild(guildId));
    const guildCommands = (commands as unknown as CommandNode[]).map((command) => ({
      ...command,
      ...(command.options
        ? { options: filterOptionsForGuild(allowedKits, command.options) }
        : {}),
    }));
    logger.info(
      { path, commands: guildCommands.map((command) => command.name) },
      "Registering NexusTiers slash commands",
    );
    const response = await rest(path, {
      method: "PUT",
      body: JSON.stringify(guildCommands),
    });
    if (!response.ok)
      throw new Error(
        `Could not register commands for guild ${guildId}: ${response.status} ${await response.text()}`,
      );
    const registeredResponse = await rest(path);
    if (registeredResponse.ok) {
      const registered = (await registeredResponse.json()) as Array<{
        name?: string;
      }>;
      const counts = new Map<string, number>();
      for (const command of registered) {
        if (command.name)
          counts.set(command.name, (counts.get(command.name) ?? 0) + 1);
      }
      const duplicates = [...counts.entries()]
        .filter(([, count]) => count > 1)
        .map(([name, count]) => `${name} x${count}`);
      logger.info(
        { path, commandCount: registered.length, duplicates },
        "NexusTiers slash commands replaced",
      );
    }
  }
}

async function ensureQueueEntryFromButton(
  interaction: DiscordInteraction,
  kit: string,
) {
  const guildId = requireNexusTestingGuild(interaction.guild_id);
  assertKitAssignedToGuild(guildId, kit);
  const user = actor(interaction);
  const state = await getState();
  const verified = state.verified.find(
    (account) => account.discordUserId === user.id,
  );
  if (!verified) {
    throw new Error(
      "Please verify your Minecraft account using the Verify Account button first.",
    );
  }
  const existingEntry = state.queues[kit as (typeof KITS)[number]].entries.find(
    (entry) => entry.discordUserId === user.id,
  );
  if (existingEntry) return { entry: existingEntry, alreadyQueued: true };

  const latestKitResult = state.results
    .filter(
      (result) =>
        result.kit === kit &&
        (result.playerDiscordUserId === user.id ||
          result.ign.toLowerCase() === verified.ign.toLowerCase()),
    )
    .sort(
      (a, b) =>
        new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime(),
    )[0];
  const entry = await joinQueue(
    {
      discordUserId: user.id,
      username: user.username,
      ign: verified.ign,
      currentTier: latestKitResult?.tier ?? "N/A",
      region: "EU",
      server: "eu.practice.net",
      kit,
    },
    kit,
  );
  if (interaction.guild_id) {
    const panel = queuePanels.get(`${interaction.guild_id}:${kit}`);
    if (panel)
      await updateQueuePanel(panel).catch((error) =>
        logger.warn({ error }, "Could not refresh queue panel after join"),
      );
  }
  return { entry, alreadyQueued: false };
}

async function joinQueueFromButton(
  interaction: DiscordInteraction,
  kit: string,
) {
  const user = actor(interaction);
  const { entry } = await ensureQueueEntryFromButton(interaction, kit);
  await respond(
    interaction,
    `You are on the **${kit}** waitlist. Position: **#${entry.position}**.`,
    true,
  );
}

function queueRoleEnvNames(kit: string) {
  const normalizedKit = kit.toUpperCase();
  return [`${normalizedKit}_QUEUE_ROLE_ID`, `QUEUE_${normalizedKit}_ROLE_ID`];
}

async function findOrCreateQueueRole(
  guildId: string,
  kit: string,
  roles: DiscordRole[],
) {
  const fallbackName = `${KIT_LABELS[kit as keyof typeof KIT_LABELS] ?? kit} Queue`;
  const existing = await findRoleWithConfig(
    guildId,
    queueRoleEnvNames(kit),
    fallbackName,
    roles,
  );
  if (existing) return existing;

  const response = await rest(`/guilds/${guildId}/roles`, {
    method: "POST",
    body: JSON.stringify({
      name: fallbackName,
      color: 0x5865f2,
      hoist: true,
      mentionable: false,
    }),
  });
  if (!response.ok) {
    throw new Error(
      `Could not create the ${fallbackName} role: ${response.status}`,
    );
  }
  return (await response.json()) as DiscordRole;
}

async function assignQueueRole(
  guildId: string,
  userId: string,
  kit: string,
  botUserId?: string,
) {
  const memberResponse = await rest(`/guilds/${guildId}/members/${userId}`);
  if (!memberResponse.ok)
    throw new Error("You must be a member of this Discord server.");
  const member = (await memberResponse.json()) as DiscordGuildMember;
  const roles = await getGuildRoles(guildId);
  if (hasRestrictedRole(member.roles, roles)) {
    throw new Error("You cannot join the whitelist while you are restricted.");
  }
  const state = await getState();
  const verifiedAccount = state.verified.find(
    (account) => account.discordUserId === userId,
  );
  if (
    isDiscordUserRestricted(state, userId) ||
    isMinecraftUserRestricted(state, verifiedAccount?.ign)
  ) {
    throw new Error("You cannot join the whitelist while you are restricted.");
  }
  assertKitCooldownAvailable(
    state,
    kit as (typeof KITS)[number],
    userId,
    verifiedAccount?.ign,
  );

  const selectedRole = await findOrCreateQueueRole(guildId, kit, roles);
  const allRoles = [
    ...roles,
    ...(roles.some((role) => role.id === selectedRole.id)
      ? []
      : [selectedRole]),
  ];
  await assignAutomaticRole(guildId, member, selectedRole, allRoles, botUserId);
  return selectedRole;
}

async function postTicketPanel(guildId: string, channelId: string) {
  const targetChannelId =
    process.env.TICKET_PANEL_CHANNEL_ID?.trim() || channelId;
  const channel = await getChannel(targetChannelId);
  if (channel.type !== 0)
    throw new Error(
      "The ticket panel must be posted in a regular text channel.",
    );
  await postToChannel(targetChannelId, "", ticketPanel);
  return targetChannelId;
}

async function postHighTierPanel(guildId: string) {
  const category = await findOrCreateTicketCategory(guildId, "high_tier");
  const response = await rest(`/guilds/${guildId}/channels`);
  if (!response.ok)
    throw new Error(`Could not read Discord channels: ${response.status}`);
  const channels = (await response.json()) as Array<{
    id: string;
    name?: string;
    type?: number;
    parent_id?: string | null;
  }>;
  const configuredChannelId = process.env.HIGH_TIER_PANEL_CHANNEL_ID?.trim();
  const configuredChannel = configuredChannelId
    ? channels.find(
        (channel) =>
          channel.id === configuredChannelId &&
          channel.type === 0 &&
          channel.parent_id === category.id,
      )
    : undefined;
  const existingPanelChannel =
    configuredChannel ??
    channels.find(
      (channel) =>
        channel.type === 0 &&
        channel.parent_id === category.id &&
        (channel.name === "high-tickets" ||
          channel.name === "high-tier-tickets"),
    );
  let panelChannel = existingPanelChannel;
  if (!panelChannel) {
    const createChannelResponse = await rest(`/guilds/${guildId}/channels`, {
      method: "POST",
      body: JSON.stringify({
        name: "high-tickets",
        type: 0,
        parent_id: category.id,
      }),
    });
    if (!createChannelResponse.ok) {
      throw new Error(
        `Could not create the High Tickets panel channel: ${createChannelResponse.status}`,
      );
    }
    panelChannel = (await createChannelResponse.json()) as {
      id: string;
      name?: string;
      type?: number;
      parent_id?: string | null;
    };
  }
  await postToChannel(panelChannel.id, "", highTierPanel);
  return panelChannel.id;
}

function highTierSelectionRow(
  customId: string,
  placeholder: string,
  options: Array<{ label: string; value: string }>,
) {
  return [
    {
      type: 1,
      components: [
        {
          type: 3,
          custom_id: customId,
          placeholder,
          options,
        },
      ],
    },
  ];
}

function highTierValue(value: string | undefined) {
  return HIGH_TIER_TIERS.includes(value as (typeof HIGH_TIER_TIERS)[number])
    ? (value as (typeof HIGH_TIER_TIERS)[number])
    : undefined;
}

function highTierKitValue(value: string | undefined) {
  return HIGH_TIER_KITS.includes(value as HighTierKit)
    ? (value as HighTierKit)
    : undefined;
}

async function handleHighTierComponent(
  interaction: DiscordInteraction,
  customId: string,
  botUserId?: string,
) {
  const guildId = requireNexusTestingGuild(interaction.guild_id);

  if (customId === "high_tier_tier") {
    const tier = highTierValue(interaction.data?.values?.[0]);
    if (!tier) throw new Error("Please select a valid tier.");
    await respond(
      interaction,
      "Which kit is this ticket for?",
      true,
      highTierSelectionRow(
        `high_tier_kit:${tier}`,
        "Select a kit",
        HIGH_TIER_KITS.filter((kit) => isKitAllowedInGuild(guildId, kit)).map((kit) => ({
          label: HIGH_TIER_KIT_LABELS[kit],
          value: kit,
        })),
      ),
    );
    return;
  }

  if (!customId.startsWith("high_tier_kit:")) {
    throw new Error("Unknown high-tier ticket selection.");
  }
  const tier = highTierValue(customId.split(":")[1]);
  const kit = highTierKitValue(interaction.data?.values?.[0]);
  if (!tier || !kit) throw new Error("Please select a valid tier and kit.");
  assertKitAssignedToGuild(guildId, kit);

  const user = actor(interaction);
  const state = await getState();
  const verifiedAccount = state.verified.find(
    (account) => account.discordUserId === user.id,
  );
  const ticketId = `ticket_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  const channel = await createSupportTicketChannel(
    guildId,
    "high_tier",
    ticketId,
    user.id,
    user.username,
    botUserId,
    { tier, kit },
  );
  try {
    const ticket = await createTicket({
      id: ticketId,
      guildId,
      channelId: channel.id,
      creatorId: user.id,
      creatorUsername: user.username,
      type: "high_tier",
      requestedTier: tier,
      kit,
      ...(verifiedAccount?.ign ? { minecraftUser: verifiedAccount.ign } : {}),
      reason: `High Tier request for ${tier} ${HIGH_TIER_KIT_LABELS[kit]}.`,
      createdAt: new Date().toISOString(),
    });
    await postTicketMessage(ticket);
    await respond(
      interaction,
      `Your High Tier ticket has been created: <#${channel.id}>.`,
      true,
    );
  } catch (error) {
    await deleteTicketChannel({ channelId: channel.id } as NexusTicket).catch(
      (cleanupError) =>
        logger.warn(
          { cleanupError, channelId: channel.id },
          "Could not clean up an incomplete high-tier ticket channel",
        ),
    );
    throw error;
  }
}

async function handleTicketTypeSelection(interaction: DiscordInteraction) {
  const selected = ticketType(interaction.data?.values?.[0]);
  if (!selected) throw new Error("Please select a valid ticket type.");
  if (!interaction.guild_id)
    throw new Error("Tickets can only be created in a server.");

  await showModal(
    interaction,
    `ticket_modal:${selected}`,
    `${ticketDisplayName(selected)} Ticket`,
    ticketModalComponents(selected),
  );
}

async function handleTicketModalSubmit(
  interaction: DiscordInteraction,
  customId: string,
  botUserId?: string,
) {
  const selected = ticketType(customId.split(":")[1]);
  if (!selected) throw new Error("Please select a valid ticket type.");
  const guildId = interaction.guild_id;
  if (!guildId) throw new Error("Tickets can only be created in a server.");

  const user = actor(interaction);
  const reason = ticketFieldValue(
    componentValue(interaction.data?.components, "reason"),
  );
  const reportedUser =
    selected === "support"
      ? undefined
      : ticketFieldValue(
          componentValue(interaction.data?.components, "reported_user"),
        );
  const evidence =
    selected === "support"
      ? undefined
      : ticketFieldValue(
          componentValue(interaction.data?.components, "evidence"),
        );
  const ticketId = `ticket_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

  const channel = await createSupportTicketChannel(
    guildId,
    selected,
    ticketId,
    user.id,
    user.username,
    botUserId,
  );
  try {
    const ticket = await createTicket({
      id: ticketId,
      guildId,
      channelId: channel.id,
      creatorId: user.id,
      creatorUsername: user.username,
      type: selected,
      reportedUser,
      reason,
      evidence,
      createdAt: new Date().toISOString(),
    });
    await postTicketMessage(ticket);
    await respond(
      interaction,
      `Your ${ticketDisplayName(selected).toLowerCase()} ticket has been created: <#${channel.id}>.`,
      true,
    );
  } catch (error) {
    await deleteTicketChannel({ channelId: channel.id } as NexusTicket).catch(
      (cleanupError) =>
        logger.warn(
          { cleanupError, channelId: channel.id },
          "Could not clean up an incomplete ticket channel",
        ),
    );
    throw error;
  }
}

async function ticketFromInteraction(interaction: DiscordInteraction) {
  if (!interaction.channel_id)
    throw new Error("This ticket action must be used inside a ticket channel.");
  const state = await getState();
  const ticket = ticketForChannel(state, interaction.channel_id);
  if (!ticket)
    throw new Error("This channel is not an active NexusTiers ticket.");
  return ticket;
}

async function handleTicketButtonInteraction(
  interaction: DiscordInteraction,
  customId: string,
) {
  const ticket = await ticketFromInteraction(interaction);
  const action = customId.replace("ticket_", "");

  if (action === "close") {
    if (ticket.status !== "open") {
      await respond(interaction, "This ticket is already closed.", true);
      return;
    }
    if (!(await canManageTicket(interaction, ticket, "close"))) {
      await respond(
        interaction,
        "You do not have permission to close this ticket.",
        true,
      );
      return;
    }
    await respond(
      interaction,
      "Are you sure you want to close this ticket?",
      true,
      [
        {
          type: 1,
          components: [
            {
              type: 2,
              style: 4,
              label: "Confirm",
              custom_id: "ticket_close_confirm",
            },
            {
              type: 2,
              style: 2,
              label: "Cancel",
              custom_id: "ticket_close_cancel",
            },
          ],
        },
      ],
    );
    return;
  }

  if (action === "close_cancel") {
    await respond(interaction, "Ticket close cancelled.", true);
    return;
  }

  if (action === "close_confirm") {
    if (ticket.status !== "open") {
      await respond(interaction, "This ticket is already closed.", true);
      return;
    }
    if (!(await canManageTicket(interaction, ticket, "close"))) {
      await respond(
        interaction,
        "You do not have permission to close this ticket.",
        true,
      );
      return;
    }
    await closeTicketChannel(ticket);
    const closedTicket = await updateTicket(ticket.id, {
      status: "closed",
      closedAt: new Date().toISOString(),
    });
    await postToChannel(
      closedTicket.channelId,
      "This ticket has been closed. Authorized staff may delete it.",
      { components: ticketControls("closed") },
    );
    await respond(interaction, "Ticket closed.", true);
    return;
  }

  if (action === "claim") {
    if (ticket.status !== "open") {
      await respond(interaction, "Closed tickets cannot be claimed.", true);
      return;
    }
    if (!(await canManageTicket(interaction, ticket, "claim"))) {
      await respond(
        interaction,
        ticket.type === "staff_report"
          ? "Only the Owner can claim a Staff Report."
          : "Only authorized staff members can claim this ticket.",
        true,
      );
      return;
    }
    const claimedTicket = await updateTicket(ticket.id, {
      claimedBy: actor(interaction).id,
    });
    await postToChannel(
      claimedTicket.channelId,
      `Ticket claimed by <@${actor(interaction).id}>`,
      {
        allowed_mentions: { parse: [] },
      },
    );
    await respond(interaction, "Ticket claimed.", true);
    return;
  }

  if (action === "delete") {
    if (ticket.status !== "closed") {
      await respond(interaction, "Close the ticket before deleting it.", true);
      return;
    }
    if (!(await canManageTicket(interaction, ticket, "delete"))) {
      await respond(
        interaction,
        ticket.type === "staff_report"
          ? "Only the Owner can delete a Staff Report."
          : "Only authorized staff members can delete this ticket.",
        true,
      );
      return;
    }
    await deleteTicketChannel(ticket);
    await respond(interaction, "Ticket deleted.", true);
  }
}

async function handleTicketComponent(
  interaction: DiscordInteraction,
  customId: string,
  botUserId?: string,
) {
  if (customId === "ticket_type") {
    await handleTicketTypeSelection(interaction);
    return;
  }
  if (customId.startsWith("ticket_modal:")) {
    await handleTicketModalSubmit(interaction, customId, botUserId);
    return;
  }
  await handleTicketButtonInteraction(interaction, customId);
}

async function handleButtonInteraction(
  interaction: DiscordInteraction,
  customId: string,
) {
  if (customId.startsWith("nexus_")) {
    requireNexusTestingGuild(interaction.guild_id);
  }
  const user = actor(interaction);
  if (customId === "nexus_verify_account") {
    await showModal(
      interaction,
      "nexus_verify_account_modal",
      "Verify Account",
      [
        {
          type: 1,
          components: [
            {
              type: 4,
              custom_id: "ign",
              label: "Minecraft Username",
              style: 1,
              min_length: 1,
              max_length: 16,
              required: true,
              placeholder: "Dein Minecraft-Name",
            },
          ],
        },
      ],
    );
    return;
  }

  if (customId.startsWith("nexus_enter_waitlist:")) {
    const kit = customId.split(":")[1]?.toLowerCase();
    if (!kit || !KITS.includes(kit as (typeof KITS)[number]))
      throw new Error("Invalid queue.");
    await joinQueueFromButton(interaction, kit);
    return;
  }

  if (customId === "nexus_enter_waitlist") {
    const guildId = requireNexusTestingGuild(interaction.guild_id);
    if (interaction.guild_id && interaction.channel_id) {
      const channelResponse = await rest(`/channels/${interaction.channel_id}`);
      if (channelResponse.ok) {
        const channel = (await channelResponse.json()) as { name?: string };
        const channelName = channel.name ?? "";
        const kit = KITS.find(
          (candidate) =>
            channelName === `${candidate}-waitlist` ||
            channelName.endsWith(`・${candidate}-waitlist`) ||
            channelName.endsWith(`-${candidate}-waitlist`),
        );
        if (kit) {
          await joinQueueFromButton(interaction, kit);
          return;
        }
      }
    }
    const state = await getState();
    if (!state.verified.some((account) => account.discordUserId === user.id)) {
      await respond(
        interaction,
        "Please click **Verify Account** and verify your Minecraft account first.",
        true,
      );
      return;
    }

    const [memberResponse, roles] = await Promise.all([
      rest(`/guilds/${guildId}/members/${user.id}`),
      getGuildRoles(guildId),
    ]);
    if (!memberResponse.ok)
      throw new Error("You must be a member of this Discord server.");
    const member = (await memberResponse.json()) as DiscordGuildMember;
    const options = await Promise.all(
      getKitsForGuild(guildId).map(async (kit) => {
        const role = await findRoleWithConfig(
          guildId,
          queueRoleEnvNames(kit),
          `${KIT_LABELS[kit]} Queue`,
          roles,
        );
        return {
          label: KIT_LABELS[kit],
          value: kit,
          ...(role && member.roles?.includes(role.id) ? { default: true } : {}),
        };
      }),
    );
    await respond(interaction, "", true, [
      {
        type: 1,
        components: [
          {
            type: 3,
            custom_id: "nexus_waitlist_kits",
            placeholder: "Choose your kits",
            min_values: 1,
            max_values: getKitsForGuild(guildId).length,
            options,
          },
        ],
      },
    ]);
    return;
  }

  if (customId === "nexus_view_cooldown") {
    const guildId = requireNexusTestingGuild(interaction.guild_id);
    const user = actor(interaction);
    const state = await getState();
    const verifiedAccount = state.verified.find(
      (account) => account.discordUserId === user.id,
    );
    const activeCooldowns = getKitsForGuild(guildId).map((kit) =>
      findActiveKitCooldown(state, kit, user.id, verifiedAccount?.ign),
    ).filter((cooldown): cooldown is NonNullable<typeof cooldown> =>
      Boolean(cooldown),
    );
    if (activeCooldowns.length === 0) {
      await respond(
        interaction,
        "You do not have any active kit cooldowns.",
        true,
      );
      return;
    }
    const lines = activeCooldowns.map((cooldown) => {
      const discordTimestamp = Math.floor(
        new Date(cooldown.expiresAt).getTime() / 1000,
      );
      return `**${KIT_LABELS[cooldown.kit]}**: ends <t:${discordTimestamp}:R>`;
    });
    await respond(
      interaction,
      `Active kit cooldowns:\n${lines.join("\n")}`,
      true,
    );
  }
}

async function handleWaitlistKitSelection(
  interaction: DiscordInteraction,
  customId: string,
  botUserId?: string,
) {
  if (customId !== "nexus_waitlist_kits") return;
  const guildId = requireNexusTestingGuild(interaction.guild_id);
  const user = actor(interaction);
  const selectedKits = [...new Set(interaction.data?.values ?? [])];
  if (
    selectedKits.length === 0 ||
    selectedKits.some((kit) => !isKitAllowedInGuild(guildId, kit))
  ) {
    throw new Error("Please select one or more valid kits.");
  }
  if (!botUserId)
    throw new Error(
      "The bot is not ready to assign waitlist roles. Please try again shortly.",
    );
  await deferComponentUpdate(interaction);

  const state = await getState();
  if (!state.verified.some((account) => account.discordUserId === user.id)) {
    throw new Error(
      "Please click **Verify Account** and verify your Minecraft account first.",
    );
  }

  const results: string[] = [];
  for (const kit of selectedKits) {
    let queueRole: DiscordRole;
    try {
      queueRole = await assignQueueRole(
        guildId,
        user.id,
        kit,
        botUserId,
      );
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "Could not assign this kit role.";
      results.push(
        `⚠️ **${KIT_LABELS[kit as (typeof KITS)[number]]}** — ${message}`,
      );
      continue;
    }

    try {
      const { entry, alreadyQueued } = await ensureQueueEntryFromButton(
        interaction,
        kit,
      );
      results.push(
        `✅ **${KIT_LABELS[kit as (typeof KITS)[number]]}** — **${queueRole.name}** role assigned; #${entry.position}${alreadyQueued ? " (already on waitlist)" : ""}`,
      );
    } catch (error) {
      const message =
        error instanceof Error
          ? error.message
          : "Could not join this waitlist.";
      if (message === "This queue is closed.") {
        results.push(
          `✅ **${KIT_LABELS[kit as (typeof KITS)[number]]}** — **${queueRole.name}** role assigned; the queue remains closed.`,
        );
      } else {
        results.push(
          `✅ **${KIT_LABELS[kit as (typeof KITS)[number]]}** — **${queueRole.name}** role assigned; no waitlist entry: ${message}`,
        );
      }
    }
  }
  await editDeferredResponse(
    botUserId,
    interaction,
    `Waitlist results:\n${results.join("\n")}`,
    [],
  );
}

async function handleModalSubmit(
  interaction: DiscordInteraction,
  customId: string,
  botUserId?: string,
) {
  if (customId.startsWith("nexus_")) {
    requireNexusTestingGuild(interaction.guild_id);
  }
  const user = actor(interaction);
  if (customId === "nexus_verify_account_modal") {
    const ign = componentValue(interaction.data?.components, "ign")?.trim();
    if (!ign) throw new Error("Please enter your Minecraft username.");
    if (!botUserId)
      throw new Error(
        "The bot is not ready to verify accounts yet. Please try again shortly.",
      );
    await deferResponse(interaction, true);
    const verifiedIgn = await findMinecraftJavaProfile(ign);
    await verifyAccount({
      discordUserId: user.id,
      username: user.username,
      ign: verifiedIgn,
    });
    await editDeferredResponse(botUserId, interaction, "Account verified.");
    return;
  }

  if (customId === "nexus_enter_waitlist_modal") {
    const guildId = requireNexusTestingGuild(interaction.guild_id);
    const state = await getState();
    const verified = state.verified.find(
      (account) => account.discordUserId === user.id,
    );
    if (!verified) {
      throw new Error(
        "Please click **Verify Account** and verify your Minecraft account first.",
      );
    }
    const kit = componentValue(interaction.data?.components, "kit")
      ?.trim()
      .toLowerCase();
    if (!kit || !isKitAllowedInGuild(guildId, kit)) {
      throw new Error(
        `Invalid kit for this server. Allowed kits: ${getKitsForGuild(guildId).join(", ")}.`,
      );
    }
    const role = await assignQueueRole(
      guildId,
      user.id,
      kit,
      botUserId,
    );
    await respond(interaction, `You received the **${role.name}** role.`, true);
  }
}

async function handleInteraction(
  interaction: DiscordInteraction,
  botUserId?: string,
) {
  const name = interaction.data?.name;
  const user = actor(interaction);
  try {
    if (
      interaction.data?.component_type === 3 &&
      interaction.data.custom_id === "nexus_waitlist_kits"
    ) {
      await handleWaitlistKitSelection(
        interaction,
        interaction.data.custom_id,
        botUserId,
      );
      return;
    }
    if (
      interaction.data?.component_type === 3 &&
      interaction.data.custom_id?.startsWith("high_tier_")
    ) {
      await handleHighTierComponent(
        interaction,
        interaction.data.custom_id,
        botUserId,
      );
      return;
    }
    if (
      interaction.data?.component_type &&
      interaction.data.custom_id?.startsWith("application_")
    ) {
      await handleApplicationComponent(
        interaction,
        interaction.data.custom_id,
        botUserId,
      );
      return;
    }
    if (interaction.data?.custom_id?.startsWith("ticket_modal:")) {
      await handleTicketComponent(
        interaction,
        interaction.data.custom_id,
        botUserId,
      );
      return;
    }
    if (
      interaction.data?.component_type &&
      interaction.data.custom_id &&
      (interaction.data.custom_id === "ticket_type" ||
        interaction.data.custom_id.startsWith("ticket_"))
    ) {
      await handleTicketComponent(
        interaction,
        interaction.data.custom_id,
        botUserId,
      );
      return;
    }
    if (interaction.data?.component_type === 2 && interaction.data.custom_id) {
      await handleButtonInteraction(interaction, interaction.data.custom_id);
      return;
    }
    if (interaction.data?.custom_id?.endsWith("_modal")) {
      await handleModalSubmit(
        interaction,
        interaction.data.custom_id,
        botUserId,
      );
      return;
    }
    if (name === "tester") {
      if (subcommand(interaction) !== "info") {
        await respond(interaction, "Use this command as /tester info.", true);
        return;
      }
      await respondWithEmbed(interaction, testerInfoEmbed);
      return;
    }
    if (name === "verify") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "This command can only be used in a server.",
          true,
        );
        return;
      }
      const guildId = requireNexusTestingGuild(interaction.guild_id);
      const guildResponse = await rest(`/guilds/${interaction.guild_id}`);
      if (!guildResponse.ok)
        throw new Error(
          `Could not verify the server owner: ${guildResponse.status}`,
        );
      const guild = (await guildResponse.json()) as { owner_id: string };
      if (guild.owner_id !== user.id) {
        await respond(
          interaction,
          "Only the server owner can use this command.",
          true,
        );
        return;
      }
      const channel = await postVerificationPanel(guildId);
      await respond(
        interaction,
        `The verification panel was posted in <#${channel.id}>.`,
        true,
      );
      return;
    }
    if (name === "applicationstaff" || name === "applicationtester") {
      if (subcommand(interaction) !== "set") {
        await respond(
          interaction,
          `Use this command as \`/${name} set\` in the desired target channel.`,
          true,
        );
        return;
      }
      await setApplicationChannel(
        interaction,
        name === "applicationstaff" ? "staff" : "tester",
      );
      return;
    }
    if (name === "boosteralert") {
      await setBoosterAlertChannel(interaction, botUserId);
      return;
    }
    if (name === "setresult") {
      await setResultChannel(interaction);
      return;
    }
    if (name === "applications") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "This command can only be used in a server.",
          true,
        );
        return;
      }
      if (!(await hasApplicationPanelPermission(interaction))) {
        await respond(
          interaction,
          "You need the Manage Server permission to post the application panel.",
          true,
        );
        return;
      }
      const panelChannelId =
        process.env.APPLICATION_PANEL_CHANNEL_ID?.trim() ||
        interaction.channel_id;
      if (!panelChannelId)
        throw new Error("No application panel channel is configured.");
      await postToChannel(panelChannelId, "", applicationPanel);
      await respond(interaction, "Application panel posted.", true);
      return;
    }
    if (name === "tickets") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "This command can only be used in a server.",
          true,
        );
        return;
      }
      if (!(await hasApplicationPanelPermission(interaction))) {
        await respond(
          interaction,
          "You need the Manage Server permission to post the ticket panel.",
          true,
        );
        return;
      }
      const panelChannelId = await postTicketPanel(
        interaction.guild_id,
        interaction.channel_id ?? "",
      );
      await respond(
        interaction,
        `Ticket panel posted in <#${panelChannelId}>.`,
        true,
      );
      return;
    }
    if (name === "channels") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "Dieser Befehl kann nur in einem Server verwendet werden.",
          true,
        );
        return;
      }
      const guildOwnerId = await getGuildOwnerId(interaction.guild_id);
      if (
        !hasManageChannelsPermission(interaction) &&
        guildOwnerId !== user.id
      ) {
        await respond(
          interaction,
          "Du brauchst die Berechtigung **Kanäle verwalten**, um `/channels` auszuführen.",
          true,
        );
        return;
      }
      if (!botUserId) {
        throw new Error(
          "Der Bot ist noch nicht bereit, Kanäle zu erstellen. Bitte versuche es gleich noch einmal.",
        );
      }

      await deferResponse(interaction, true);
      const summary = await createNexusChannelLayout(interaction.guild_id);
      await editDeferredResponse(
        botUserId,
        interaction,
        [
          `Kanal-Setup fertig: **${summary.categoriesCreated}** Kategorien und **${summary.channelsCreated}** Kanäle neu erstellt.`,
          `**${summary.categoriesExisting}** Kategorien und **${summary.channelsExisting}** passende Kanäle waren bereits vorhanden und blieben unverändert.`,
        ].join("\n"),
      );
      return;
    }
    if (name === "waitlist") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "Dieser Befehl kann nur in einem Server verwendet werden.",
          true,
        );
        return;
      }
      const guildId = requireNexusTestingGuild(interaction.guild_id);
      const guildOwnerId = await getGuildOwnerId(interaction.guild_id);
      if (
        !hasManageChannelsPermission(interaction) &&
        guildOwnerId !== user.id
      ) {
        await respond(
          interaction,
          "Du brauchst die Berechtigung **Kanäle verwalten**, um `/waitlist` auszuführen.",
          true,
        );
        return;
      }
      if (!botUserId) {
        throw new Error(
          "Der Bot ist noch nicht bereit, Waitlist-Kanäle zu erstellen. Bitte versuche es gleich noch einmal.",
        );
      }

      await deferResponse(interaction, true);
      const summary = await createKitWaitlistChannels(
        guildId,
        botUserId,
        getKitsForGuild(guildId),
      );
      await editDeferredResponse(
        botUserId,
        interaction,
        [
          `Waitlist-Setup fertig: **${summary.channelsCreated}** Kit-Kanäle neu erstellt und **${summary.channelsUpdated}** vorhandene abgesichert.`,
          `Kategorie **Kit Waitlists** ${summary.categoryCreated ? "neu erstellt" : "aktualisiert"}.`,
          "Jeder Kanal ist nur für die passende Kit-Rolle und Kit-Queue-Rolle sichtbar. Schreiben kann nur der Bot.",
        ].join("\n"),
      );
      return;
    }
    if (name === "requesttest") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "Dieser Befehl kann nur in einem Server verwendet werden.",
          true,
        );
        return;
      }
      const guildId = requireNexusTestingGuild(interaction.guild_id);
      const guildOwnerId = await getGuildOwnerId(interaction.guild_id);
      if (
        !hasManageChannelsPermission(interaction) &&
        guildOwnerId !== user.id
      ) {
        await respond(
          interaction,
          "Du brauchst die Berechtigung **Kanäle verwalten**, um `/requesttest` auszuführen.",
          true,
        );
        return;
      }
      if (!botUserId) {
        throw new Error(
          "Der Bot ist noch nicht bereit, die Testanfrage-Vorlage zu senden.",
        );
      }

      const requestChannel = await findChannel(
        guildId,
        "request-test",
      );
      if (!requestChannel || requestChannel.type !== 0) {
        await respond(
          interaction,
          "Der Textkanal `request-test` wurde nicht gefunden. Führe zuerst `/channels` aus.",
          true,
        );
        return;
      }

      await deferResponse(interaction, true);
      await postToChannel(requestChannel.id, "", verificationPanel);
      await editDeferredResponse(
        botUserId,
        interaction,
        `Das Test-Waitlist-Panel wurde in <#${requestChannel.id}> gepostet.`,
      );
      return;
    }
    if (name === "hightickets") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "This command can only be used in a server.",
          true,
        );
        return;
      }
      const guildId = requireNexusTestingGuild(interaction.guild_id);
      if ((await getGuildOwnerId(guildId)) !== user.id) {
        await respond(
          interaction,
          "You do not have permission to use this command.",
          true,
        );
        return;
      }
      const panelChannelId = await postHighTierPanel(guildId);
      await respond(
        interaction,
        `High Tier panel posted in <#${panelChannelId}>.`,
        true,
      );
      return;
    }
    if (name === "debuff") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "This command can only be used in a server.",
          true,
        );
        return;
      }
      const guildId = requireNexusTestingGuild(interaction.guild_id);
      assertKitAssignedToGuild(guildId, "debuff");
      if ((await getGuildOwnerId(guildId)) !== user.id) {
        await respond(interaction, "Only the server owner can use `/debuff`.", true);
        return;
      }
      if (!botUserId) {
        throw new Error(
          "The bot is not ready to create Debuff roles yet. Please try again in a moment.",
        );
      }

      await deferResponse(interaction, true);
      const roleSummary = await createNexusRoles(guildId, ["debuff"]);
      const waitlistSummary = await createKitWaitlistChannels(
        guildId,
        botUserId,
        ["debuff"],
      );
      const waitlistStatus =
        waitlistSummary.channelsCreated > 0 ? "created" : "updated";
      await editDeferredResponse(
        botUserId,
        interaction,
        `Debuff setup complete: **${roleSummary.created}** roles created, **${roleSummary.existing}** already existed, and **#debuff-waitlist** ${waitlistStatus} with **debuff Queue** access.`,
      );
      return;
    }
    if (name === "create") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "This command can only be used in a server.",
          true,
        );
        return;
      }
      const guildId = requireNexusTestingGuild(interaction.guild_id);
      if (subcommand(interaction) !== "new") {
        await respond(interaction, "Use this command as `/create new`.", true);
        return;
      }
      const guildOwnerId = await getGuildOwnerId(interaction.guild_id);
      if (!hasManageRolesPermission(interaction) && guildOwnerId !== user.id) {
        await respond(
          interaction,
          "You need the Manage Roles permission to use `/create new`.",
          true,
        );
        return;
      }
      if (!botUserId) {
        throw new Error(
          "The bot is not ready to create roles yet. Please try again in a moment.",
        );
      }

      await deferResponse(interaction, true);
      const summary = await createNexusRoles(guildId, getKitsForGuild(guildId));
      await editDeferredResponse(
        botUserId,
        interaction,
        `Role setup complete. Created **${summary.created}** new roles and kept **${summary.existing}** existing roles (**${summary.total}** checked).`,
      );
      return;
    }
    if (name === "change") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "This command can only be used in a server.",
          true,
        );
        return;
      }
      const guildId = requireNexusTestingGuild(interaction.guild_id);
      const guildOwnerId = await getGuildOwnerId(interaction.guild_id);
      if (!hasManageRolesPermission(interaction) && guildOwnerId !== user.id) {
        await respond(
          interaction,
          "You need the Manage Roles permission to use `/change`.",
          true,
        );
        return;
      }
      if (!botUserId) {
        throw new Error(
          "The bot is not ready to change role colors yet. Please try again in a moment.",
        );
      }

      await deferResponse(interaction, true);
      const summary = await changeNexusRoleColors(guildId, getKitsForGuild(guildId));
      const line = (label: string, values: typeof summary.tier) =>
        `**${label}:** ${values.changed} changed, ${values.unchanged} already correct, ${values.missing} missing, ${values.skipped} skipped`;
      await editDeferredResponse(
        botUserId,
        interaction,
        [
          "Role colors updated separately:",
          line("Tier roles", summary.tier),
          line("Kit roles", summary.kit),
          line("Waitlist roles", summary.waitlist),
        ].join("\n"),
      );
      return;
    }
    if (name === "sort") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "Dieser Befehl kann nur in einem Server verwendet werden.",
          true,
        );
        return;
      }
      const guildId = requireNexusTestingGuild(interaction.guild_id);
      const guildOwnerId = await getGuildOwnerId(interaction.guild_id);
      if (!hasManageRolesPermission(interaction) && guildOwnerId !== user.id) {
        await respond(
          interaction,
          "Du brauchst die Berechtigung **Rollen verwalten**, um `/sort` zu verwenden.",
          true,
        );
        return;
      }
      if (!botUserId) {
        throw new Error(
          "Der Bot ist noch nicht bereit, Rollen zu sortieren. Bitte versuche es gleich noch einmal.",
        );
      }

      await deferResponse(interaction, true);
      const summary = await sortNexusRoles(guildId, botUserId);
      if (summary.found === 0) {
        await editDeferredResponse(
          botUserId,
          interaction,
          "Keine passenden NexusTiers-Rollen zum Sortieren gefunden.",
        );
        return;
      }
      const skippedNote =
        summary.skipped > 0
          ? `; **${summary.skipped}** wegen verwalteter Rollen oder der Discord-Rollenhierarchie übersprungen`
          : "";
      await editDeferredResponse(
        botUserId,
        interaction,
        `Rollen von oben nach unten sortiert: **HT1 → LT1 → HT2 → LT2 → HT3 → LT3 → HT4 → LT4 → HT5 → LT5 → Member → Tester → Queue → Restricted**. **${summary.sorted}** Rollen angeordnet${skippedNote}.`,
      );
      return;
    }
    if (name === "clearall") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "This command can only be used in a server.",
          true,
        );
        return;
      }
      const guildResponse = await rest(`/guilds/${interaction.guild_id}`);
      if (!guildResponse.ok)
        throw new Error(
          `Could not verify the server owner: ${guildResponse.status}`,
        );
      const guild = (await guildResponse.json()) as { owner_id: string };
      if (guild.owner_id !== user.id) {
        await respond(
          interaction,
          "Only the server owner can clear all website tiers.",
          true,
        );
        return;
      }
      const confirmation = String(
        requiredOption(interaction, "confirmation"),
      ).trim();
      if (confirmation !== "RESET ALL TIERS") {
        await respond(
          interaction,
          "Reset cancelled. Type exactly `RESET ALL TIERS` to confirm.",
          true,
        );
        return;
      }
      const cleared = await clearAllPlayerTiers();
      await respond(
        interaction,
        `All website tiers were cleared: **${cleared.removedCount}** results and **${cleared.cooldownsCleared}** cooldowns removed.`,
        true,
      );
      return;
    }
    if (name === "clear") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "This command can only be used in a server.",
          true,
        );
        return;
      }
      const guildResponse = await rest(`/guilds/${interaction.guild_id}`);
      if (!guildResponse.ok)
        throw new Error(
          `Could not verify the server owner: ${guildResponse.status}`,
        );
      const guild = (await guildResponse.json()) as { owner_id: string };
      if (guild.owner_id !== user.id) {
        await respond(
          interaction,
          "Only the server owner can clear website tiers.",
          true,
        );
        return;
      }
      const targetIgn = String(requiredOption(interaction, "minecraft")).trim();
      const cleared = await clearPlayerTiers(targetIgn);
      const resultLabel = cleared.removedCount === 1 ? "result" : "results";
      await respond(
        interaction,
        `Website tiers removed for **${targetIgn}**: ${cleared.removedCount} ${resultLabel}.`,
        true,
      );
      return;
    }
    if (name === "cooldown") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "This command can only be used in a server.",
          true,
        );
        return;
      }
      const guildId = requireNexusTestingGuild(interaction.guild_id);
      if ((await getGuildOwnerId(guildId)) !== user.id) {
        await respond(
          interaction,
          "Only the server owner can use `/cooldown`.",
          true,
        );
        return;
      }

      const mode = subcommand(interaction);
      if (mode === "set") {
        const kit = String(requiredOption(interaction, "kit"))
          .trim()
          .toLowerCase();
        assertKitAssignedToGuild(guildId, kit);
        const duration = String(requiredOption(interaction, "duration")).trim();
        const durationMs = parseCooldownDuration(duration);
        const updated = await setKitCooldownDuration(kit, durationMs);
        await respond(
          interaction,
          `Successfully set the ${KIT_LABELS[updated.kit]} cooldown to ${duration}.`,
          true,
        );
        return;
      }

      if (mode === "remove") {
        const discordUserId = String(requiredOption(interaction, "discord"));
        const minecraftUser = String(
          requiredOption(interaction, "minecraft"),
        ).trim();
        const kit = String(requiredOption(interaction, "kit"))
          .trim()
          .toLowerCase();
        assertKitAssignedToGuild(guildId, kit);
        const removed = await removeKitCooldown({
          discordUserId,
          minecraftUser,
          kit,
        });
        if (!removed) {
          await respond(
            interaction,
            "This player does not have an active cooldown for this kit.",
            true,
          );
          return;
        }
        await respond(
          interaction,
          `Successfully removed the ${KIT_LABELS[removed.kit]} cooldown for <@${discordUserId}>.`,
          true,
        );
        return;
      }

      await respond(
        interaction,
        "Use `/cooldown set` to configure a kit duration or `/cooldown remove` to remove a player cooldown.",
        true,
      );
      return;
    }
    if (name === "restrict" || name === "unrestrict") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "This command can only be used in a server.",
          true,
        );
        return;
      }
      if (!(await hasRestrictionPermission(interaction))) {
        await respond(
          interaction,
          "Only the Owner, Manager, or Admin can use this command.",
          true,
        );
        return;
      }

      const targetDiscordUserId = String(
        requiredOption(interaction, "discord"),
      );
      const minecraftUser = String(
        requiredOption(interaction, "minecraft"),
      ).trim();
      const state = await getState();

      if (name === "unrestrict") {
        const restriction = findActiveRestriction(
          state,
          interaction.guild_id,
          targetDiscordUserId,
          minecraftUser,
        );
        if (!restriction) {
          await respond(
            interaction,
            "This Discord user and Minecraft user do not have an active restriction.",
            true,
          );
          return;
        }
        await restoreRestrictionRoles(restriction, botUserId);
        const completed = await completeRestriction(
          restriction.id,
          "unrestricted",
          user.id,
        );
        await respondWithEmbed(interaction, {
          title: "Restriction Removed",
          color: 0x2ecc71,
          fields: [
            {
              name: "Discord User",
              value: `<@${completed.discordUserId}>`,
              inline: true,
            },
            {
              name: "Minecraft User",
              value: completed.minecraftUser,
              inline: true,
            },
            {
              name: "Previous Tiers",
              value: restrictionTierText(completed),
              inline: false,
            },
            { name: "Unrestricted by", value: `<@${user.id}>`, inline: false },
          ],
        });
        return;
      }

      const duration = String(requiredOption(interaction, "duration")).trim();
      const endTimestamp = parseRestrictionDuration(duration);
      const reason = String(requiredOption(interaction, "reason")).trim();
      if (!reason) throw new Error("A restriction reason is required.");
      const linkedMinecraftAccounts =
        reason.toLowerCase() === "alting"
          ? linkedMinecraftAccountNames(
              state,
              targetDiscordUserId,
              minecraftUser,
            )
          : undefined;
      const memberResponse = await rest(
        `/guilds/${interaction.guild_id}/members/${targetDiscordUserId}`,
      );
      if (!memberResponse.ok) {
        throw new Error(
          `Could not find that Discord member: ${memberResponse.status}`,
        );
      }
      const member = (await memberResponse.json()) as DiscordGuildMember;
      const roles = await getGuildRoles(interaction.guild_id);
      const restricted = restrictedRole(roles);
      if (!restricted) {
        throw new Error(
          'The "Restricted" role was not found. Ask a server administrator to configure the Discord roles.',
        );
      }
      const alreadyRestricted = state.restrictions.some(
        (restriction) =>
          (restriction.discordUserId === targetDiscordUserId ||
            restriction.minecraftUser.trim().toLowerCase() ===
              minecraftUser.toLowerCase()) &&
          (restriction.status === "active" ||
            restriction.status === "permanent"),
      );
      if (alreadyRestricted || hasRestrictedRole(member.roles, roles)) {
        await respond(interaction, "This user is already restricted.", true);
        return;
      }

      const previousRoleIds = [...(member.roles ?? [])];
      const savedTierRoleIds = previousRoleIds.filter((roleId) => {
        const role = roles.find((candidate) => candidate.id === roleId);
        return Boolean(role && isTierRole(role));
      });
      for (const roleId of previousRoleIds) {
        if (roleId === interaction.guild_id || roleId === restricted.id)
          continue;
        const role = roles.find((candidate) => candidate.id === roleId);
        if (!role || role.managed) continue;
        try {
          await removeRoleForRestriction(
            interaction.guild_id,
            targetDiscordUserId,
            role,
          );
        } catch (error) {
          logger.warn(
            {
              error,
              guildId: interaction.guild_id,
              userId: targetDiscordUserId,
              roleId,
            },
            "Could not remove a role while restricting a member",
          );
        }
      }
      await assignAutomaticRole(
        interaction.guild_id,
        member,
        restricted,
        roles,
        botUserId,
      );
      const restriction = await createRestriction({
        guildId: interaction.guild_id,
        discordUserId: targetDiscordUserId,
        minecraftUser,
        linkedMinecraftAccounts,
        previousRoleIds,
        savedTierRoleIds,
        duration,
        endTimestamp,
        reason,
        moderatorId: user.id,
      });
      let punishmentsLogWarning: string | undefined;
      const punishmentsChannel = await findChannel(
        interaction.guild_id,
        "punishments",
      );
      if (!punishmentsChannel || punishmentsChannel.type !== 0) {
        punishmentsLogWarning =
          "The #punishments channel was not found, so the restriction was not logged.";
        logger.warn(
          { guildId: interaction.guild_id, userId: targetDiscordUserId },
          "Could not find the punishments channel for a restriction log",
        );
      } else {
        try {
          for (const message of restrictionPunishmentMessages(
            restriction,
            member.user?.username ?? targetDiscordUserId,
          )) {
            await postToChannel(punishmentsChannel.id, message, {
              allowed_mentions: { parse: [] },
            });
          }
        } catch (error) {
          punishmentsLogWarning =
            "Could not post to #punishments; check the bot's channel permissions.";
          logger.error(
            {
              error,
              guildId: interaction.guild_id,
              channelId: punishmentsChannel.id,
              userId: targetDiscordUserId,
            },
            "Could not post a restriction to the punishments channel",
          );
        }
      }
      await respondWithEmbed(interaction, {
        title: "Restriction",
        color: 0xed4245,
        fields: [
          {
            name: "Discord User",
            value: `<@${restriction.discordUserId}>`,
            inline: true,
          },
          {
            name: "Minecraft User",
            value: restriction.minecraftUser,
            inline: true,
          },
          { name: "Duration", value: restriction.duration, inline: true },
          { name: "Reason", value: restriction.reason, inline: false },
          ...restrictionAccountFields(restriction),
          {
            name: "Saved Tiers",
            value: restrictionTierText(restriction),
            inline: false,
          },
          { name: "Restricted by", value: `<@${user.id}>`, inline: false },
          ...(punishmentsLogWarning
            ? [
                {
                  name: "Punishments log",
                  value: punishmentsLogWarning,
                  inline: false,
                },
              ]
            : []),
        ],
      });
      return;
    }
    if (name === "add") {
      if (!interaction.guild_id || !interaction.channel_id) {
        throw new Error(
          "Use `/add` inside an active test ticket in the server.",
        );
      }
      const guildId = requireNexusTestingGuild(interaction.guild_id);
      if (!(await hasTicketRoleAddPermission(interaction))) {
        await respond(
          interaction,
          "Only Helper, Mod, Manager, Admin, or the server owner can use `/add`.",
          true,
        );
        return;
      }
      const state = await getState();
      if (!queueTicketForChannel(state, interaction.channel_id)) {
        throw new Error(
          "There is no active `/next` test ticket in this channel.",
        );
      }
      const [channel, roles] = await Promise.all([
        getChannel(interaction.channel_id),
        getGuildRoles(guildId),
      ]);
      if (channel.guild_id && channel.guild_id !== guildId) {
        throw new Error("This test ticket belongs to a different server.");
      }
      if (channel.type !== 0) {
        throw new Error("Use `/add` in a text test-ticket channel.");
      }

      const tier = requiredOption(interaction, "tier").toLowerCase();
      const kit = requiredOption(interaction, "kit").toLowerCase();
      if (!TIERS.includes(tier as (typeof TIERS)[number]) || tier === "n/a") {
        throw new Error("Choose a valid tier other than N/A.");
      }
      if (!KITS.includes(kit as (typeof KITS)[number])) {
        throw new Error(`Unknown kit. Choose one of: ${KITS.join(", ")}.`);
      }
      assertKitAssignedToGuild(guildId, kit);
      const roleName = `${tier.toUpperCase()} ${KIT_LABELS[kit as (typeof KITS)[number]]}`;
      const role = roles.find(
        (candidate) => candidate.name.toLowerCase() === roleName.toLowerCase(),
      );
      if (!role) {
        throw new Error(
          `The **${roleName}** role does not exist. Ask an admin to run \`/create new\` first.`,
        );
      }
      const permissionResponse = await rest(
        `/channels/${interaction.channel_id}/permissions/${role.id}`,
        {
          method: "PUT",
          body: JSON.stringify({
            type: 0,
            allow: TICKET_VIEW_PERMISSIONS,
            deny: "0",
          }),
        },
      );
      if (!permissionResponse.ok) {
        throw new Error(
          `Could not add the **${roleName}** role to this ticket: ${permissionResponse.status}`,
        );
      }
      await respond(
        interaction,
        `The **${roleName}** role can now access this ticket.`,
        true,
      );
      return;
    }
    if (name === "rules") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "This command can only be used in a server.",
          true,
        );
        return;
      }
      const ownerId = await getGuildOwnerId(interaction.guild_id);
      if (ownerId !== user.id) {
        await respond(
          interaction,
          "Only the server owner can use `/rules`.",
          true,
        );
        return;
      }
      await respondWithEmbed(interaction, {
        title: "NexusTiers Rules",
        description: [
          "**No Doxing (Includes doxes that occur in other servers)**",
          "Do not disrespect staff",
          "No botting or destructive behavior",
          "Do not violate Discord TOS/Guidelines",
          "Do not excessively ping members",
          "No NSFW Media (Instant ban)",
          "Do not DM advertise your servers or websites/projects",
          "Discriminatory hate speech/phrases are not tolerated",
          "Be respectful - No harassment, hate speech, or toxic behavior.",
          "No spam - Avoid excessive messages, links, or self-promotion.",
          "",
          "**Breaking rules may result in warnings, mutes, or bans.**",
        ].join("\n"),
        color: 0xed4245,
      });
      return;
    }
    if (name === "leaderboard") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "Use /leaderboard inside the Discord server.",
          true,
        );
        return;
      }
      const guildId = requireNexusTestingGuild(interaction.guild_id);
      if (!botUserId)
        throw new Error("The bot is not ready to publish the leaderboard yet.");
      await deferResponse(interaction, true);
      const guildResponse = await rest("/guilds/" + guildId);
      if (!guildResponse.ok) {
        throw new Error(
          "Could not verify the server owner; /leaderboard was not published.",
        );
      }
      const guild = (await guildResponse.json()) as { owner_id?: string };
      if (guild.owner_id !== user.id) {
        await editDeferredResponse(
          botUserId,
          interaction,
          "Only the server owner can use /leaderboard.",
        );
        return;
      }
      await refreshTestingLeaderboard(guildId, true);
      await editDeferredResponse(
        botUserId,
        interaction,
        "The testing leaderboard was posted or updated in the designated leaderboard channel.",
      );
      return;
    }
    if (name === "adminresult") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "Use `/adminresult` inside the Discord server.",
          true,
        );
        return;
      }
      const guildId = requireNexusTestingGuild(interaction.guild_id);
      if (!(await hasRestrictionPermission(interaction))) {
        await respond(
          interaction,
          "Only Manager, Admin, or the server owner can use `/adminresult`.",
          true,
        );
        return;
      }
      const playerDiscordUserId = requiredOption(interaction, "discord");
      const minecraftNameInput = requiredOption(
        interaction,
        "minecraft",
      ).trim();
      const tier = requiredOption(interaction, "tier");
      const kit = requiredOption(interaction, "kit").toLowerCase();
      if (!TIERS.includes(tier as (typeof TIERS)[number])) {
        throw new Error("Choose a valid tier.");
      }
      if (!KITS.includes(kit as (typeof KITS)[number])) {
        throw new Error(`Unknown kit. Choose one of: ${KITS.join(", ")}.`);
      }
      assertKitAssignedToGuild(guildId, kit);
      if (!botUserId)
        throw new Error(
          "The bot is not ready to save admin results yet. Please try again shortly.",
        );

      await deferResponse(interaction, true);
      const [memberResponse, ign] = await Promise.all([
        rest(`/guilds/${guildId}/members/${playerDiscordUserId}`),
        findMinecraftJavaProfile(minecraftNameInput),
      ]);
      if (!memberResponse.ok) {
        throw new Error(
          memberResponse.status === 404
            ? "Choose a Discord member of this server."
            : `Could not load the selected Discord member: ${memberResponse.status}`,
        );
      }
      const member = (await memberResponse.json()) as DiscordGuildMember;
      const playerUsername = member.user?.username ?? ign;
      const state = await getState();
      const previousTier =
        state.results.find(
          (result) =>
            result.ign.trim().toLowerCase() === ign.toLowerCase() &&
            result.kit === kit,
        )?.tier ?? "N/A";
      const result = await submitResult(
        {
          playerDiscordUserId,
          playerUsername,
          ign,
          kit,
          tier,
          testerId: user.id,
          testerName: user.username,
          previousTier,
          region: "N/A",
        },
        { completeQueueTicket: false, actorLabel: "Staff" },
      );

      try {
        const resultsChannel = await findChannel(
          interaction.guild_id,
          "results",
        );
        if (resultsChannel) {
          await postToChannel(resultsChannel.id, "", {
            embeds: [
              {
                title: `${result.playerUsername} Admin Result 🏆`,
                description: `<@${result.playerDiscordUserId}>`,
                color: 0x9b59b6,
                thumbnail: {
                  url: `https://mc-heads.net/avatar/${encodeURIComponent(result.ign)}/128`,
                },
                fields: [
                  { name: "Recorded by", value: `<@${user.id}>`, inline: true },
                  {
                    name: "Minecraft Username",
                    value: result.ign,
                    inline: true,
                  },
                  {
                    name: "Previous Rank",
                    value: result.previousTier || "N/A",
                    inline: true,
                  },
                  {
                    name: "Rank Earned",
                    value: result.tier.toUpperCase(),
                    inline: true,
                  },
                  {
                    name: "Gamemode",
                    value: KIT_LABELS[kit as (typeof KITS)[number]],
                    inline: true,
                  },
                ],
                footer: { text: "NexusTiers Admin Result" },
              },
            ],
          });
        }
      } catch (error) {
        logger.warn(
          { error, guildId: interaction.guild_id },
          "Could not post admin result in the results channel",
        );
      }
      await syncTierResultRole(interaction.guild_id, result, botUserId).catch(
        (error) => {
          logger.warn(
            {
              error,
              guildId: interaction.guild_id,
              userId: playerDiscordUserId,
            },
            "Admin tier role synchronization failed",
          );
        },
      );
      await editDeferredResponse(
        botUserId,
        interaction,
        `Admin result saved: **${result.ign}** earned **${result.tier}** in **${KIT_LABELS[kit as (typeof KITS)[number]]}**.`,
      );
      return;
    }
    if (name === "user") {
      if (!interaction.guild_id) {
        await respond(
          interaction,
          "This command can only be used in a server.",
          true,
        );
        return;
      }
      const guildId = requireNexusTestingGuild(interaction.guild_id);
      if (subcommand(interaction) !== "set") {
        await respond(
          interaction,
          "Use this command as `/user set minecraft discord tiers` — for example `sword:lt4,mace:ht5`.",
          true,
        );
        return;
      }
      const guildResponse = await rest(`/guilds/${guildId}`);
      if (!guildResponse.ok)
        throw new Error(
          `Could not verify the server owner: ${guildResponse.status}`,
        );
      const guild = (await guildResponse.json()) as { owner_id: string };
      if (guild.owner_id !== user.id) {
        await respond(
          interaction,
          "Only the server owner can use `/user set`.",
          true,
        );
        return;
      }

      const minecraftName = String(
        requiredOption(interaction, "minecraft"),
      ).trim();
      const discordName = String(requiredOption(interaction, "discord")).trim();
      const tierAssignments = parseManualTierSpec(
        String(requiredOption(interaction, "tiers")),
      );
      for (const assignment of tierAssignments) {
        assertKitAssignedToGuild(guildId, assignment.kit);
      }
      const results = await setManualTiers({
        ign: minecraftName,
        playerUsername: discordName,
        tiers: tierAssignments,
        assignedBy: user.username,
      });
      await respond(
        interaction,
        `Manual tiers set for **${minecraftName}** (${discordName}): ${results
          .map((result) => `**${result.kit} ${result.tier}**`)
          .join(", ")}.`,
        true,
      );
      return;
    }
    if (
      [
        "open",
        "close",
        "next",
        "eval",
        "skip",
        "result",
        "testerleave",
        "testerjoin",
      ].includes(name ?? "") &&
      !(await hasQueueTesterPermission(interaction))
    ) {
      await respond(
        interaction,
        "Only the Verified Tester rank can use this command.",
        true,
      );
      return;
    }
    if (name === "open") {
      const kit = await resolveKit(interaction);
      if (!interaction.guild_id)
        throw new Error("This command can only be used in a server.");
      const waitlistChannel = await findChannel(
        interaction.guild_id,
        `${kit}-waitlist`,
      );
      if (!waitlistChannel) {
        throw new Error(
          `The #${kit}-waitlist channel was not found. Ask a server administrator to configure the Discord channels.`,
        );
      }
      const queue = await openQueue(
        { actorId: user.id, actorName: user.username },
        kit,
      );
      const panelKey = `${interaction.guild_id}:${kit}`;
      const existingPanel = queuePanels.get(panelKey);
      let panelMessageId = existingPanel?.messageId;
      if (existingPanel) {
        const updateResponse = await rest(
          `/channels/${existingPanel.channelId}/messages/${existingPanel.messageId}`,
          {
            method: "PATCH",
            body: JSON.stringify(queuePanelPayload(queue, kit)),
          },
        );
        if (!updateResponse.ok) {
          queuePanels.delete(panelKey);
          panelMessageId = undefined;
        }
      }
      if (!panelMessageId) {
        const message = await postToChannel(
          waitlistChannel.id,
          "",
          queuePanelPayload(queue, kit),
        );
        panelMessageId = message.id;
      }
      queuePanels.set(panelKey, {
        guildId: interaction.guild_id,
        kit,
        channelId: waitlistChannel.id,
        messageId: panelMessageId,
      });
      startQueuePanelUpdater();
      await respond(
        interaction,
        `The **${queue.label}** queue is open. The queue panel was updated in <#${waitlistChannel.id}>.`,
        true,
      );
      return;
    }
    if (name === "close") {
      const kit = await resolveKit(interaction);
      if (!interaction.guild_id)
        throw new Error("This command can only be used in a server.");
      const waitlistChannel = await findChannel(
        interaction.guild_id,
        `${kit}-waitlist`,
      );
      if (!waitlistChannel) {
        throw new Error(
          `The #${kit}-waitlist channel was not found. Ask a server administrator to configure the Discord channels.`,
        );
      }
      const queue = await closeQueue(
        { actorId: user.id, actorName: user.username },
        kit,
      );
      const panelKey = `${interaction.guild_id}:${kit}`;
      const existingPanel = queuePanels.get(panelKey);
      if (existingPanel) {
        await deleteMessage(existingPanel.channelId, existingPanel.messageId);
        queuePanels.delete(panelKey);
      }
      const closedMessage = await postToChannel(
        waitlistChannel.id,
        "",
        closedQueuePanelPayload(queue),
      );
      queuePanels.set(panelKey, {
        guildId: interaction.guild_id,
        kit,
        channelId: waitlistChannel.id,
        messageId: closedMessage.id,
      });
      startQueuePanelUpdater();
      await respond(
        interaction,
        `The **${queue.label}** queue is closed. The previous queue message was deleted and replaced.`,
        true,
      );
      return;
    }
    if (name === "leave") {
      const kit = await resolveKit(interaction);
      const result = await leaveQueue(
        { discordUserId: user.id, username: user.username },
        kit,
      );
      if (interaction.guild_id) {
        const panel = queuePanels.get(`${interaction.guild_id}:${kit}`);
        if (panel) {
          await updateQueuePanel(panel).catch((error) => {
            logger.warn({ error }, "Could not refresh queue panel after leave");
          });
        }
      }
      await respond(
        interaction,
        `You left the **${result.queue.label}** queue. Your previous position was **#${result.previousPosition}**.`,
        true,
      );
      return;
    }
    if (name === "testerleave") {
      const kit = await resolveKit(interaction);
      const result = await leaveTester(
        { actorId: user.id, actorName: user.username },
        kit,
      );
      if (interaction.guild_id) {
        const panel = queuePanels.get(`${interaction.guild_id}:${kit}`);
        if (panel) {
          await updateQueuePanel(panel).catch((error) => {
            logger.warn(
              { error },
              "Could not refresh queue panel after tester leave",
            );
          });
        }
      }
      await respond(
        interaction,
        `You left the tester queue for **${result.queue.label}**. Your player queue entry was not changed.`,
        true,
      );
      return;
    }
    if (name === "testerjoin") {
      const kit = await resolveKit(interaction);
      const result = await joinTester(
        { actorId: user.id, actorName: user.username },
        kit,
      );
      if (interaction.guild_id) {
        const panel = queuePanels.get(`${interaction.guild_id}:${kit}`);
        if (panel) {
          await updateQueuePanel(panel).catch((error) => {
            logger.warn(
              { error },
              "Could not refresh queue panel after tester join",
            );
          });
        }
      }
      await respond(
        interaction,
        `You joined the tester queue for **${result.label}**. Your player queue entry was not changed.`,
        true,
      );
      return;
    }
    if (name === "next") {
      const kit = await resolveKit(interaction);
      const ticket = await nextTicket(
        { actorId: user.id, actorName: user.username },
        kit,
      );
      const ticketChannel = interaction.guild_id
        ? await createTicketChannel(
            interaction.guild_id,
            kit,
            ticket.player.username,
            ticket.tester.username,
            ticket.player.discordUserId,
            ticket.tester.discordUserId,
            botUserId,
          )
        : null;
      if (ticketChannel) {
        ticketChannelKits.set(ticketChannel.id, kit);
        await setQueueTicketChannel(ticket.id, ticketChannel.id);
      }
      if (interaction.guild_id) {
        const panel = queuePanels.get(`${interaction.guild_id}:${kit}`);
        if (panel) {
          await updateQueuePanel(panel).catch((error) => {
            logger.warn(
              { error },
              "Could not refresh queue panel after opening ticket",
            );
          });
        }
      }
      if (ticketChannel) {
        await postToChannel(
          ticketChannel.id,
          `**NexusTiers Ticket**\nPlayer: <@${ticket.player.discordUserId}> (${ticket.player.ign})\nTester: <@${ticket.tester.discordUserId}>\nKit: **${kit}**\nCurrent Tier: **${ticket.player.currentTier || "N/A"}**\nWhen finished: \`/result\` • If the player does not show up: \`/skip\``,
        );
      }
      return;
    }
    if (name === "eval") {
      if (!interaction.guild_id || !interaction.channel_id) {
        throw new Error(
          "Use `/eval` inside an active test ticket in the server.",
        );
      }
      const state = await getState();
      const ticket = queueTicketForChannel(state, interaction.channel_id);
      if (!ticket) {
        throw new Error(
          "There is no active `/next` test ticket in this channel.",
        );
      }
      if (ticket.tester.discordUserId !== user.id) {
        await respond(
          interaction,
          "Only the tester assigned to this ticket can send it for evaluation.",
          true,
        );
        return;
      }

      const [channel, roles, ownerId] = await Promise.all([
        getChannel(interaction.channel_id),
        getGuildRoles(interaction.guild_id),
        getGuildOwnerId(interaction.guild_id),
      ]);
      if (channel.guild_id && channel.guild_id !== interaction.guild_id) {
        throw new Error("This test ticket belongs to a different server.");
      }

      const staffOverwrites = await evalReviewRoleOverwrites(
        interaction.guild_id,
        roles,
      );
      const permissionOverwrites = new Map(
        (channel.permission_overwrites ?? []).map((overwrite) => [
          `${overwrite.type}:${overwrite.id}`,
          overwrite,
        ]),
      );
      for (const overwrite of staffOverwrites) {
        permissionOverwrites.set(
          `${overwrite.type}:${overwrite.id}`,
          overwrite,
        );
      }
      permissionOverwrites.set(`1:${ownerId}`, {
        id: ownerId,
        type: 1,
        allow: TICKET_VIEW_PERMISSIONS,
        deny: "0",
      });
      if (ticket.tester.discordUserId !== ownerId) {
        permissionOverwrites.set(`1:${ticket.tester.discordUserId}`, {
          id: ticket.tester.discordUserId,
          type: 1,
          allow: "0",
          deny: "1024",
        });
      }

      const channelName = `ht3-${ticket.kit}-${safeChannelSegment(ticket.player.ign)}`;
      const updateResponse = await rest(`/channels/${interaction.channel_id}`, {
        method: "PATCH",
        body: JSON.stringify({
          name: channelName,
          permission_overwrites: [...permissionOverwrites.values()],
        }),
      });
      if (!updateResponse.ok) {
        throw new Error(
          `Could not send the test ticket for evaluation: ${updateResponse.status}`,
        );
      }
      ticketChannelKits.set(interaction.channel_id, ticket.kit);
      await respond(
        interaction,
        `Ticket **${channelName}** was sent for evaluation. The assigned tester no longer has access; the player, Helper, Mod, Manager, and server owner can view it.`,
        true,
      );
      return;
    }
    if (name === "skip") {
      const kit = await resolveKit(interaction);
      const state = await getState();
      const current = interaction.channel_id
        ? queueTicketForChannel(state, interaction.channel_id)
        : null;
      await skipTicket(
        { actorId: user.id, actorName: user.username, ticketId: current?.id },
        kit,
      );
      if (interaction.guild_id && current) {
        const channel =
          interaction.channel_id &&
          ticketChannelKits.get(interaction.channel_id) === kit
            ? { id: interaction.channel_id }
            : current.channelId
              ? { id: current.channelId }
              : await findChannel(
                  interaction.guild_id,
                  `ticket-${kit}-${current.player.username
                    .toLowerCase()
                    .replace(/[^a-z0-9-]/g, "-")
                    .slice(0, 24)}`,
                );
        if (channel) {
          await deleteQueueTicketChannel(channel.id).catch((error) => {
            logger.warn(
              { error, channelId: channel.id },
              "Could not delete skipped queue ticket channel",
            );
          });
          ticketChannelKits.delete(channel.id);
        }
      }
      if (interaction.guild_id) {
        const panel = queuePanels.get(`${interaction.guild_id}:${kit}`);
        if (panel)
          await updateQueuePanel(panel).catch((error) =>
            logger.warn(
              { error },
              "Could not refresh queue panel after skipping ticket",
            ),
          );
      }
      await respond(
        interaction,
        `Ticket in **${kit}** skipped. The queue has moved forward.`,
      );
      return;
    }
    if (name === "result") {
      const kit = await resolveKit(interaction);
      const tier = requiredOption(interaction, "tier");
      if (!interaction.channel_id)
        throw new Error("This command must be used inside the active ticket.");
      const state = await getState();
      const ticket = queueTicketForChannel(state, interaction.channel_id);
      if (!ticket) throw new Error("There is no open ticket for this kit.");
      const result = await submitResult({
        playerDiscordUserId: ticket.player.discordUserId,
        playerUsername: ticket.player.username,
        ign: ticket.player.ign,
        kit,
        tier,
        testerId: user.id,
        testerName: user.username,
        previousTier: ticket.player.currentTier || "N/A",
        region: ticket.player.region,
        ticketId: ticket.id,
      });
      await recordTesterRun({
        resultId: result.id,
        testerDiscordUserId: user.id,
        testerName: user.username,
        createdAt: result.createdAt,
      });
      if (interaction.guild_id) {
        await refreshTestingLeaderboard(interaction.guild_id).catch((error) => {
          logger.warn(
            { error, guildId: interaction.guild_id },
            "Could not refresh testing leaderboard after result",
          );
        });
      }
      let resultPostWarning: string | null = interaction.guild_id
        ? null
        : "No server results channel is available for this result.";
      if (interaction.guild_id) {
        const resultsChannelId =
          state.resultChannels[interaction.guild_id] ??
          (await findChannel(interaction.guild_id, "results"))?.id;
        if (!resultsChannelId) {
          resultPostWarning =
            "No results channel was found. The server owner can run `/setresult` in the desired text channel.";
          logger.warn(
            { guildId: interaction.guild_id },
            "No results channel was found",
          );
        } else {
          try {
            await postToChannel(resultsChannelId, "", {
              embeds: [
                {
                  title: `${result.playerUsername} Test Results 🏆`,
                  description: `<@${result.playerDiscordUserId}>`,
                  color: 0x9b59b6,
                  thumbnail: {
                    url: `https://mc-heads.net/avatar/${encodeURIComponent(result.ign)}/128`,
                  },
                  fields: [
                    { name: "Tester", value: `<@${user.id}>` },
                    { name: "Region", value: result.region ?? "N/A" },
                    { name: "Username", value: result.ign },
                    {
                      name: "Previous Rank",
                      value: result.previousTier || "N/A",
                    },
                    { name: "Rank Earned", value: result.tier.toUpperCase() },
                    {
                      name: "Gamemode",
                      value: KIT_LABELS[kit as keyof typeof KIT_LABELS],
                    },
                  ],
                  footer: { text: "NexusTiers Test Results" },
                },
              ],
            });
          } catch (error) {
            resultPostWarning = `The result was saved, but the bot could not post in <#${resultsChannelId}>. Check its channel permissions or run \`/setresult\` again.`;
            logger.warn(
              {
                error,
                guildId: interaction.guild_id,
                channelId: resultsChannelId,
              },
              "Could not post test result",
            );
          }
        }
      }
      if (interaction.guild_id) {
        await syncTierResultRole(interaction.guild_id, result, botUserId).catch(
          (error) => {
            logger.warn(
              {
                error,
                guildId: interaction.guild_id,
                userId: result.playerDiscordUserId,
              },
              "Tier role synchronization failed",
            );
          },
        );
        const channel = ticket.channelId
          ? { id: ticket.channelId }
          : await findChannel(
              interaction.guild_id,
              `ticket-${kit}-${ticket.player.username
                .toLowerCase()
                .replace(/[^a-z0-9-]/g, "-")
                .slice(0, 24)}`,
            );
        if (channel) {
          await deleteQueueTicketChannel(channel.id).catch((error) => {
            logger.warn(
              { error, channelId: channel.id },
              "Could not delete completed queue ticket channel",
            );
          });
          ticketChannelKits.delete(channel.id);
        }
      }
      if (interaction.guild_id) {
        const panel = queuePanels.get(`${interaction.guild_id}:${kit}`);
        if (panel)
          await updateQueuePanel(panel).catch((error) =>
            logger.warn(
              { error },
              "Could not refresh queue panel after result",
            ),
          );
      }
      const resultPostStatus = resultPostWarning
        ? ` ${resultPostWarning}`
        : " The player and tester were mentioned in the results channel.";
      await respond(
        interaction,
        `Result saved: **${result.ign}** earned **${result.tier}** in **${kit}**.${resultPostStatus}`,
      );
      return;
    }
    await respond(interaction, "Unknown NexusTiers command.", true);
  } catch (error) {
    const message = error instanceof Error ? error.message : "Command failed.";
    if (deferredInteractionIds.has(interaction.id) && botUserId) {
      await editDeferredResponse(botUserId, interaction, message);
    } else {
      await respond(interaction, message, true);
    }
  }
}

export function startDiscordBot() {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) {
    logger.warn(
      "DISCORD_BOT_TOKEN is missing; Discord bot gateway is disabled.",
    );
    return;
  }
  const WebSocketCtor = (
    globalThis as unknown as { WebSocket?: new (url: string) => GatewaySocket }
  ).WebSocket;
  if (!WebSocketCtor) {
    logger.warn("WebSocket is unavailable; Discord bot gateway is disabled.");
    return;
  }

  let botUserId: string | undefined;
  let socket: GatewaySocket | undefined;
  let heartbeatTimer: ReturnType<typeof setInterval> | undefined;
  let reconnectTimer: ReturnType<typeof setTimeout> | undefined;
  let restrictionExpiryTimer: ReturnType<typeof setInterval> | undefined;
  let reconnectAttempt = 0;

  const clearHeartbeat = () => {
    if (heartbeatTimer) {
      clearInterval(heartbeatTimer);
      heartbeatTimer = undefined;
    }
  };

  const scheduleReconnect = (reason: string) => {
    if (reconnectTimer) return;
    const delay = Math.min(30_000, 1_000 * 2 ** Math.min(reconnectAttempt, 5));
    reconnectAttempt += 1;
    logger.warn({ delay, reason }, "Scheduling Discord gateway reconnect");
    reconnectTimer = setTimeout(() => {
      reconnectTimer = undefined;
      connect();
    }, delay);
  };

  const connect = () => {
    let nextSocket: GatewaySocket;
    try {
      nextSocket = new WebSocketCtor(
        "wss://gateway.discord.gg/?v=10&encoding=json",
      );
    } catch (error) {
      logger.error({ error }, "Could not create Discord gateway socket");
      scheduleReconnect("socket creation failed");
      return;
    }

    socket = nextSocket;
    nextSocket.addEventListener("message", (event) => {
      if (typeof event.data !== "string") {
        logger.warn("Discord gateway sent a non-text payload; ignoring it");
        return;
      }

      let payload: {
        op: number;
        t?: string;
        d: {
          heartbeat_interval?: number;
          user?: { id: string };
        } & DiscordInteraction;
      };
      try {
        payload = JSON.parse(event.data) as typeof payload;
      } catch (error) {
        logger.warn({ error }, "Discord gateway sent invalid JSON");
        return;
      }

      if (payload.op === 1) {
        nextSocket.send(JSON.stringify({ op: 1, d: null }));
        return;
      }

      if (payload.op === 7) {
        logger.warn("Discord requested a gateway reconnect");
        nextSocket.close();
        return;
      }

      if (payload.op === 9) {
        logger.warn(
          "Discord invalidated the gateway session; reconnecting with a new session",
        );
        nextSocket.close();
        return;
      }

      if (payload.op === 10) {
        clearHeartbeat();
        const interval = payload.d.heartbeat_interval ?? 41250;
        heartbeatTimer = setInterval(() => {
          if (socket === nextSocket)
            nextSocket.send(JSON.stringify({ op: 1, d: null }));
        }, interval);
        nextSocket.send(
          JSON.stringify({
            op: 2,
            d: {
              token,
              intents: 36867,
              properties: {
                os: "linux",
                browser: "NexusTiers",
                device: "NexusTiers",
              },
            },
          }),
        );
      }

      if (payload.op === 0 && payload.t === "READY") {
        reconnectAttempt = 0;
        const applicationId = payload.d.user?.id;
        botUserId = applicationId;
        if (applicationId) {
          registerCommands(applicationId).then(
            () =>
              logger.info(
                { applicationId },
                "NexusTiers slash commands registered",
              ),
            (error) =>
              logger.error(
                { error },
                "Could not register NexusTiers slash commands",
              ),
          );
          void processDueRestrictions(applicationId);
          for (const guildId of [
            NEXUS_TIERS_GUILD_ID,
            NEXUS_SUBTIERS_GUILD_ID,
          ]) {
            void refreshTestingLeaderboard(guildId).catch((error) => {
              logger.warn(
                { error, guildId },
                "Could not initialize testing leaderboard",
              );
            });
            monitorTestingLeaderboardMonth(guildId);
          }
          if (!restrictionExpiryTimer) {
            // The database end timestamp is authoritative; this poll also catches
            // restrictions that expired while the bot was offline or restarting.
            restrictionExpiryTimer = setInterval(() => {
              void processDueRestrictions(applicationId);
            }, 60_000);
          }
        }
      }
      if (payload.op === 0 && payload.t === "INTERACTION_CREATE") {
        void handleInteraction(payload.d, botUserId);
      }
      if (payload.op === 0 && payload.t === "MESSAGE_CREATE") {
        void handleDirectMessage(payload.d as DiscordMessage);
      }
      if (payload.op === 0 && payload.t === "GUILD_MEMBER_ADD") {
        void handleGuildMemberAdd(payload.d as DiscordGuildMember, botUserId);
      }
      if (payload.op === 0 && payload.t === "GUILD_MEMBER_UPDATE") {
        void handleGuildMemberUpdate(
          payload.d as DiscordGuildMember,
          botUserId,
        );
      }
    });
    nextSocket.addEventListener("error", (event) => {
      logger.error({ error: event.error }, "Discord gateway socket error");
    });
    nextSocket.addEventListener("close", (event) => {
      if (socket !== nextSocket) return;
      clearHeartbeat();
      socket = undefined;
      if (event.code === 4014) {
        logger.error(
          { code: event.code, reason: event.reason },
          "Discord rejected the gateway intents. Enable the Server Members Intent and Message Content Intent in the Discord Developer Portal.",
        );
        return;
      }
      logger.warn(
        { code: event.code, reason: event.reason },
        "Discord gateway socket closed",
      );
      scheduleReconnect(`gateway closed with code ${event.code}`);
    });
    logger.info("NexusTiers Discord gateway connection started");
  };

  connect();
}
