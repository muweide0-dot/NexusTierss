import { useMemo, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import {
  useGetKitRanking,
  useGetLeaderboard,
  useGetPlayerTiers,
  useHealthCheck,
} from '@workspace/api-client-react';
import { Link, Route, Switch, Router as WouterRouter, useLocation, useParams } from 'wouter';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';

const queryClient = new QueryClient();

type PixelIconName = 'trophy' | 'swords' | 'cube' | 'heart' | 'pot' | 'helmet' | 'pearl' | 'sword' | 'axe' | 'mace' | 'search' | 'crosshair' | 'users';
type KitSlug = 'overall' | 'uhc' | 'sword' | 'mace' | 'diapot' | 'nethpot' | 'smp' | 'crystal' | 'axe';
type KitDefinition = {
  label: string;
  slug: KitSlug;
  icon?: PixelIconName;
  image?: string;
  accent: string;
};

function PixelIcon({ name, size = 18 }: { name: PixelIconName; size?: number }) {
  const common = { width: size, height: size, viewBox: '0 0 16 16', fill: 'currentColor', 'aria-hidden': true, className: 'pixel-icon', shapeRendering: 'crispEdges' as const };
  const paths: Record<PixelIconName, string> = {
    search: 'M6 1h4v1h2v2h1v4h-1v2h-2v1H6v-1H4V9H3V5h1V3h2V1Zm0 2H5v1H4v4h1v1h5V9h1V5h-1V4H6V3Zm6 8h2v2h1v2h-2v-1h-1v-1H9v-2h3Z',
    trophy: 'M4 1h8v2h2v5h-2v2h-2v2h2v2H4v-2h2v-2H4V8H2V3h2V1ZM3 4v3h1V4H3Zm9 0v3h1V4h-1ZM6 3v5h4V3H6Zm1 10h2v-1H7v1Z',
    swords: 'M2 1h3v2h1v2H4v2h2v2H4v2H2V9h1V7H2V5h1V3H2V1Zm9 0h3v2h-1v2h1v2h-1v2h1v2h-2V9H10V7h2V5h-1V3h-1V1h1Zm-4 7h2v2H7v2h2v2H7v1H5v-2h1v-2H5V9h2V8Z',
    cube: 'M4 1h8v2h2v10h-2v2H4v-2H2V3h2V1Zm1 2H4v10h1v1h6v-1h1V3h-1v1H5V3Zm1 3h5v6H6V6Z',
    heart: 'M3 2h3v1h2v1h2V3h3V2h1v1h1v5h-1v2h-1v1h-1v1H9v2H7v-2H5v-1H4v-1H3V8H2V3h1V2Z',
    pot: 'M5 1h6v2h1v2h1v7h-1v2H4v-2H3V5h1V3h1V1Zm2 2H6v2h4V3H7Zm-2 4v5h6V7H5Zm-2-1h2v2H3V6Zm10 0h-2v2h2V6Z',
    helmet: 'M5 1h6v1h2v2h1v7h-2v2H9v2H4v-2H2V7h1V4h2V1Zm1 2v2h5V3H6ZM5 7H4v4h2v2h2v-2h3V7H5Z',
    pearl: 'M5 1h6v1h2v2h1v6h-1v2h-2v2H5v-1H3v-2H2V4h1V2h2V1Zm1 2H5v1H4v6h1v2h1v1h4v-1h1v-2h1V5h-1V4h-1V3H6Zm1 2h3v3H7V5Z',
    sword: 'M11 1h4v4h-2v2h-2v2H9v2H7v2H5v-2H3v-2h2V7h2V5h2V3h2V1Zm2 2h-1v2h-2v2H8v2H6v1h2V9h2V7h2V5h1V3ZM2 12h4v2H2v-2Z',
    axe: 'M2 1h7v2h2v2h2v2h2v3h-2V8h-2v2H8v2H6v2H4v1H2v-2h2v-2h2V9h2V7H6V5H4v2H2V1Zm2 2v1h2V3H4Z',
    mace: 'M6 1h5v2h2v2h2v4h-2v2h-2v2H6v-2H4v-2H2V5h2V3h2V1Zm2 2H7v2H5v2H4v1h2v2h2v2h1v-2h2V8h2V7h-2V5H9V3H8Z',
    crosshair: 'M6 1h4v2h2v2h2v6h-2v2h-2v2H6v-2H4v-2H2V5h2V3h2V1Zm1 2v2H5v2H4v4h2v2h4v-2h2V7h-2V5H7V3Z',
    users: 'M2 3h4v2H2V3Zm8 0h4v2h-4V3ZM1 7h6v2H1V7Zm8 0h6v2H9V7ZM3 11h4v2H3v-2Zm6 0h4v2H9v-2Z',
  };
  return <svg {...common}><path d={paths[name]} /></svg>;
}

const kits: readonly KitDefinition[] = [
  { label: 'Overall', slug: 'overall', icon: 'trophy', accent: 'gold' },
  { label: 'Vanilla', slug: 'crystal', image: '/minecraft-icons/end-crystal.png', accent: 'rose' },
  { label: 'UHC', slug: 'uhc', image: '/minecraft-icons/golden-apple.png', accent: 'coral' },
  { label: 'Pot', slug: 'diapot', image: '/minecraft-icons/healing-potion.png', accent: 'red' },
  { label: 'NethPot', slug: 'nethpot', image: '/minecraft-icons/netherite-helmet.png', accent: 'purple' },
  { label: 'SMP', slug: 'smp', image: '/minecraft-icons/ender-pearl.png', accent: 'green' },
  { label: 'Sword', slug: 'sword', image: '/minecraft-icons/diamond-sword.png', accent: 'blue' },
  { label: 'Axe', slug: 'axe', image: '/minecraft-icons/diamond-axe.png', accent: 'cyan' },
  { label: 'Mace', slug: 'mace', image: '/minecraft-icons/mace.png', accent: 'silver' },
];

function ItemIcon({ kit, size = 16 }: { kit: typeof kits[number]; size?: number }) {
  return <span className={`kit-icon kit-icon-${kit.accent}`} aria-hidden="true">{kit.image ? <img className="minecraft-item-icon" src={kit.image} alt="" width={size} height={size} /> : <PixelIcon name={kit.icon ?? 'cube'} size={size} />}</span>;
}

function SkinAvatar({ ign, size = 56, className = '' }: { ign: string; size?: number; className?: string }) {
  const [failed, setFailed] = useState(false);
  return failed ? <span className={`skin-avatar-fallback ${className}`} style={{ width: size, height: size }}>{ign.slice(0, 1).toUpperCase()}</span> : <img className={`skin-avatar ${className}`} style={{ width: size, height: size }} src={`https://mc-heads.net/avatar/${encodeURIComponent(ign)}/${size}`} alt={`${ign} Minecraft skin`} onError={() => setFailed(true)} />;
}

function TierBadge({ tier }: { tier?: string }) {
  return <span className={`tier-badge tier-${(tier ?? 'N/A').toLowerCase()}`}>{tier ?? 'N/A'}</span>;
}

function Header() {
  return <header className="topbar">
    <Link href="/" className="brand" data-testid="link-home"><span className="brand-mark"><PixelIcon name="crosshair" size={18} /></span><span><b className="text-sky">Nexus</b>Tiers</span></Link>
    <nav className="topnav" aria-label="Primary navigation">
      <Link href="/" className="topnav-link" data-testid="link-leaderboard">Leaderboard</Link>
      <Link href="/queue/Sword" className="topnav-link" data-testid="link-queue">Queues</Link>
      <Link href="/admin" className="topnav-link topnav-muted" data-testid="link-admin">Tester ops</Link>
    </nav>
    <div className="server-state" data-testid="status-server"><span className="status-dot" /> LIVE <span className="server-ip">nexustiers.gg</span></div>
  </header>;
}

function SiteFrame({ children, mode = '' }: { children: ReactNode; mode?: string }) {
  const { data, isLoading } = useHealthCheck({ query: { queryKey: ['/api/healthz'], staleTime: 30000 } });
  return <div className={`noise site-shell min-h-[100dvh] ${mode}`}><div className="hero-grid pointer-events-none absolute inset-x-0 top-0 h-[460px]" /><Header /><div className="relative z-10 mx-auto max-w-[1240px] px-5 pb-16 sm:px-8">{children}<footer className="site-footer"><span>NEXUSTIERS // COMPETITIVE LADDER</span><span data-testid="status-api">{isLoading ? 'CONNECTING TO API' : data?.status === 'ok' ? 'API ONLINE' : 'QUEUE NETWORK READY'}</span></footer></div></div>;
}

function PlayerRow({ ign, username, tier, rank, points, region, results, kits: playerKits }: { ign: string; username: string; tier?: string; rank?: number; points?: number; region?: string | null; results?: number; kits?: string[] }) {
  return <Link href={`/profile/${encodeURIComponent(ign)}`} className="player-row" data-testid={`link-player-${ign}`}>
    <span className="player-rank">{rank ? `${rank}.` : '—'}</span>
    <SkinAvatar ign={ign} size={42} />
    <span className="player-identity"><b>{username || ign}</b><small>{ign}{region ? ` · ${region}` : ''}</small></span>
    <span className="player-kits">{playerKits?.slice(0, 4).map((kit) => <span key={kit} className="kit-chip">{kit}</span>)}</span>
    <span className="player-tier"><TierBadge tier={tier} /><small>{points !== undefined ? `${points} points` : `${results ?? 0} result${results === 1 ? '' : 's'}`}</small></span>
  </Link>;
}

function tierOrder(tier: string) {
  const match = tier.toLowerCase().match(/^(?:ht|lt)([1-5])$/);
  if (!match) return 999;
  return Number(match[1]) * 2 + (tier.toLowerCase().startsWith('lt') ? 1 : 0);
}

function KitRankingBoard({ columns }: { columns: Array<{ tier: number; players: Array<{ ign: string; username: string; tier: string }> }> }) {
  return <div className="kit-ranking-board" data-testid="kit-ranking-board">
    {columns.map((column) => <section className={`kit-tier-column kit-tier-column-${column.tier}`} key={column.tier} data-testid={`kit-tier-column-${column.tier}`}>
      <header className={`kit-tier-heading kit-tier-heading-${column.tier}`}><span className="kit-tier-heading-icon"><PixelIcon name={column.tier === 1 ? 'trophy' : 'swords'} size={22} /></span><h2>Tier {column.tier}</h2></header>
      <div className="kit-tier-players">
        {column.players.length ? column.players.slice().sort((a, b) => tierOrder(a.tier) - tierOrder(b.tier) || a.ign.localeCompare(b.ign)).map((player) => <Link href={`/profile/${encodeURIComponent(player.ign)}`} className={`kit-player-row ${player.tier.toLowerCase().startsWith('ht') ? 'is-ht' : 'is-lt'}`} key={`${column.tier}-${player.ign}`} title={`${player.username || player.ign} · ${player.tier.toUpperCase()}`} data-testid={`link-kit-player-${player.ign}`}>
          <SkinAvatar ign={player.ign} size={36} />
          <span className="kit-player-name">{player.username || player.ign}</span>
          <span className="kit-player-chevron" aria-hidden="true">⌃</span>
        </Link>) : <div className="kit-tier-empty">No ranked players</div>}
      </div>
    </section>)}
  </div>;
}

function Leaderboard() {
  const [search, setSearch] = useState('');
  const [activeTab, setActiveTab] = useState('Overall');
  const activeKit = kits.find((kit) => kit.label === activeTab) ?? kits[0];
  const { data: leaderboard, isLoading: leaderboardLoading } = useGetLeaderboard({ query: { queryKey: ['/api/leaderboard'], refetchInterval: 5000 } });
  const rankingKit = activeKit.slug === 'overall' ? 'sword' : activeKit.slug;
  const { data: kitRanking, isLoading: kitRankingLoading } = useGetKitRanking(rankingKit, { query: { queryKey: ['/api/rankings', rankingKit], enabled: activeKit.slug !== 'overall', refetchInterval: 5000 } });
  const overallPlayers = useMemo(() => (leaderboard ?? []).filter((player) => `${player.ign} ${player.username}`.toLowerCase().includes(search.toLowerCase())), [leaderboard, search]);
  const kitColumns = useMemo(() => (kitRanking?.tiers ?? []).map((column) => ({
    ...column,
    players: column.players.filter((player) => `${player.ign} ${player.username}`.toLowerCase().includes(search.toLowerCase())),
  })), [kitRanking, search]);
  const count = activeTab === 'Overall' ? overallPlayers.length : kitColumns.reduce((total, column) => total + column.players.length, 0);
  const loading = activeTab === 'Overall' ? leaderboardLoading : kitRankingLoading;
  return <div className="reference-leaderboard noise site-shell min-h-[100dvh]">
    <div className="hero-grid pointer-events-none absolute inset-x-0 top-0 h-[420px]" />
    <main className="relative z-10 mx-auto max-w-[1240px] px-5 pb-16 pt-8 sm:px-8 sm:pt-12">
      <section className="animate-rise-in reference-leaderboard-intro">
        <div className="reference-brand"><span>Nexus</span><b>Tiers</b></div>
        <div className="reference-search-wrap">
          <span className="reference-search-icon"><PixelIcon name="search" size={16} /></span>
          <input data-testid="input-player-search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search players" aria-label="Search players" className="reference-search" />
        </div>
      </section>
      <nav className="leaderboard-tabs reference-tabs" aria-label="Leaderboard categories">
        {kits.map((kit) => <button key={kit.label} type="button" data-testid={`tab-leaderboard-${kit.label.toLowerCase()}`} aria-pressed={activeTab === kit.label} onClick={() => setActiveTab(kit.label)} className={`leaderboard-tab ${activeTab === kit.label ? 'is-active' : ''}`}><ItemIcon kit={kit} /><span>{kit.label}</span></button>)}
      </nav>
      <section className="leaderboard-panel reference-panel" data-testid="leaderboard-panel">
        <div className="leaderboard-panel-heading"><div><p className="eyebrow">NEXUSTIERS RANKING</p><h1>{activeTab} leaderboard</h1></div><span className="ranking-status">{loading ? 'SYNCING' : count ? `${count} RANKED` : 'EMPTY RANKING'}</span></div>
        {loading ? <div className="leaderboard-empty"><div className="loading-scan" /><h2>Reading the live ladder</h2><p>Pulling the latest verified results from NexusTiers.</p></div> : count === 0 ? <div className="leaderboard-empty" data-testid="leaderboard-empty-state"><div className="empty-trophy" aria-hidden="true"><PixelIcon name={(activeKit.icon ?? 'trophy') as PixelIconName} size={30} /></div><h2>No players ranked yet</h2><p>{search ? `No ${activeTab} players match “${search}”.` : `The ${activeTab} leaderboard is waiting for its first result.`}</p></div> : activeTab === 'Overall' ? <div className="player-list reference-player-list">{overallPlayers.map((player) => <PlayerRow key={player.ign} ign={player.ign} username={player.username} tier={player.bestTier} rank={player.rank} points={player.points} region={player.region} results={player.results} kits={player.kits} />)}</div> : <KitRankingBoard columns={kitColumns} />}
      </section>
    </main>
  </div>;
}

function QueuePage() {
  const { kit: routeKit } = useParams<{ kit: string }>();
  const kit = kits.find((entry) => entry.label.toLowerCase() === routeKit?.toLowerCase()) ?? kits.find((entry) => entry.label === 'Sword')!;
  const [ign, setIgn] = useState('');
  const [queued, setQueued] = useState(false);
  const [region, setRegion] = useState('North America');
  return <SiteFrame><main className="page-stack animate-rise-in"><div className="breadcrumb"><Link href="/" data-testid="link-breadcrumb-home">LEADERBOARD</Link><span>/</span><span>QUEUE</span><span>/</span><b>{kit.label.toUpperCase()}</b></div><section className="queue-layout"><div className="queue-primary"><div className="page-heading"><div className="heading-icon"><ItemIcon kit={kit} size={27} /></div><div><p className="eyebrow">QUEUE ROOM / KIT 0{kits.indexOf(kit) + 1}</p><h1>{kit.label} queue</h1><p>Enter your IGN and join the next open testing block.</p></div></div><div className="surface queue-card">{queued ? <div className="queued-state"><span className="queue-pulse" /><p className="eyebrow">YOU ARE IN THE QUEUE</p><h2>Position <span>#04</span></h2><p>Keep this tab open. A tester will pull the next matchup from the {kit.label} room.</p><button type="button" className="button-outline" onClick={() => setQueued(false)} data-testid="button-leave-queue">LEAVE QUEUE</button></div> : <form onSubmit={(event) => { event.preventDefault(); if (ign.trim()) setQueued(true); }}><label htmlFor="queue-ign">Minecraft username</label><input id="queue-ign" data-testid="input-queue-ign" value={ign} onChange={(event) => setIgn(event.target.value)} placeholder="e.g. coldfront" autoComplete="off" /><label htmlFor="queue-region">Region</label><select id="queue-region" data-testid="select-queue-region" value={region} onChange={(event) => setRegion(event.target.value)}><option>North America</option><option>Europe</option><option>Asia Pacific</option><option>South America</option></select><button type="submit" className="button-primary" data-testid="button-join-queue" disabled={!ign.trim()}><PixelIcon name="swords" size={16} /> JOIN {kit.label.toUpperCase()} QUEUE</button><p className="form-footnote">By joining, you agree to be available for a verified 1v1 test.</p></form>}</div></div><aside className="queue-aside"><div className="surface queue-stats"><p className="eyebrow">ROOM STATUS</p><div className="big-stat"><strong>{queued ? '04' : '00'}</strong><span>players waiting</span></div><div className="stat-row"><span>EST. WAIT</span><b>{queued ? '04:30' : '—'}</b></div><div className="stat-row"><span>REGION</span><b>{region === 'North America' ? 'NA' : region.slice(0, 2).toUpperCase()}</b></div><div className="stat-row"><span>TESTERS</span><b>ONLINE</b></div></div><div className="surface rules-card"><p className="eyebrow">QUEUE NOTES</p><p>Use your exact in-game name. Testers may ask for a replay or screen share before assigning a tier.</p><Link href="/admin" data-testid="link-tester-ops">VIEW TESTER OPS →</Link></div></aside></section></main></SiteFrame>;
}

function ProfilePage() {
  const { ign: routeIgn } = useParams<{ ign: string }>();
  const [, navigate] = useLocation();
  const [search, setSearch] = useState(routeIgn ?? '');
  const { data: profile, isLoading, isError } = useGetPlayerTiers(routeIgn ?? '', { query: { queryKey: ['/api/players', routeIgn, 'tiers'], enabled: Boolean(routeIgn), refetchInterval: 5000 } });
  const displayIgn = profile?.ign ?? routeIgn ?? '';
  const displayName = profile?.username ?? displayIgn;
  const region = profile?.region === 'EU' ? 'Europe' : profile?.region === 'NA' ? 'North America' : profile?.region === 'AS' ? 'Asia Pacific' : profile?.region ?? 'North America';
  return <SiteFrame mode="profile-shell"><main className="profile-route animate-rise-in">
    <div className="profile-backdrop" aria-hidden="true" />
    <section className="profile-card surface" role="dialog" aria-modal="true" aria-label={`${displayName || 'Player'} profile`}>
      <Link href="/" className="profile-close" aria-label="Close player profile">×</Link>
      <div className="profile-identity"><SkinAvatar ign={displayIgn || '?'} size={128} className="profile-skin" /><h1>{displayName || 'Find a player'}</h1><span className="profile-rank-badge"><span className="rank-emblem">✦</span>Combat Master</span><p className="profile-region">{region}</p><a className="namemc-link" href={`https://namemc.com/profile/${encodeURIComponent(displayIgn)}`} target="_blank" rel="noreferrer"><span className="namemc-mark">N</span><span>NameMC ↗</span></a></div>
      {isLoading ? <div className="profile-loading"><div className="loading-scan" /><p>Loading verified tiers…</p></div> : isError ? <div className="profile-loading"><h2>Profile not found</h2><p>There is no verified result for this Minecraft name yet.</p></div> : <><div className="profile-position"><p className="profile-section-label">POSITION</p><div className="position-box"><strong>{profile?.position ?? '—'}.</strong><span className="position-label"><PixelIcon name="trophy" size={24} /> OVERALL</span><small>({profile?.points ?? 0}<br />points)</small></div></div><div className="profile-tiers"><p className="profile-section-label">TIERS</p>{profile?.tiers.length ? <div className="tier-strip">{profile.tiers.map((tier) => { const kit = kits.find((entry) => entry.slug === tier.kit) ?? kits[0]; return <Link key={tier.kit} href="/" className="tier-card" title={`${tier.kit} ${tier.tier}`} data-testid={`profile-tier-${tier.kit}`}><span className="tier-card-icon"><ItemIcon kit={kit} size={24} /></span><TierBadge tier={tier.tier} /></Link>; })}</div> : <div className="profile-empty">No verified tiers have been recorded for this player yet.</div>}</div></>}
    </section>
    <form className="profile-search surface" onSubmit={(event) => { event.preventDefault(); if (search.trim()) navigate(`/profile/${encodeURIComponent(search.trim())}`); }}><PixelIcon name="search" size={16} /><input data-testid="input-profile-search" value={search} onChange={(event) => setSearch(event.target.value)} placeholder="Search by Minecraft username" /><button type="submit" className="button-primary" data-testid="button-search-profile">LOOK UP</button></form>
  </main></SiteFrame>;
}

function AdminPage() {
  const [notice, setNotice] = useState('');
  const [filter, setFilter] = useState('');
  const pending = [{ ign: 'coldfront', kit: 'Sword', age: '02:14' }, { ign: 'lunarset', kit: 'UHC', age: '07:48' }, { ign: 'orebound', kit: 'Vanilla', age: '12:09' }];
  return <SiteFrame><main className="page-stack animate-rise-in"><div className="breadcrumb"><Link href="/" data-testid="link-admin-home">LEADERBOARD</Link><span>/</span><b>TESTER OPS</b></div><section className="admin-heading"><div><p className="eyebrow">PRIVATE OPERATIONS / TESTER ACCESS</p><h1>Tester operations</h1><p>Review queue entries and publish verified results to the live ladder.</p></div><span className="ops-badge"><span className="status-dot" /> OPS ONLINE</span></section>{notice && <div className="notice" data-testid="status-admin-notice">{notice}</div>}<section className="surface admin-table"><div className="admin-toolbar"><div><p className="eyebrow">WAITLIST</p><h2>Open test requests</h2></div><input data-testid="input-admin-filter" value={filter} onChange={(event) => setFilter(event.target.value)} placeholder="Filter IGN" aria-label="Filter queue requests" /></div><div className="request-list">{pending.filter((entry) => entry.ign.includes(filter.toLowerCase())).map((entry) => <div className="request-row" key={entry.ign}><div className="request-player"><span className="mini-avatar">{entry.ign.slice(0, 1).toUpperCase()}</span><div><b>{entry.ign}</b><small>{entry.kit} queue / {entry.age} ago</small></div></div><div className="request-actions"><button type="button" className="button-outline" data-testid={`button-skip-${entry.ign}`} onClick={() => setNotice(`${entry.ign} was skipped for this testing block.`)}>SKIP</button><button type="button" className="button-primary compact" data-testid={`button-review-${entry.ign}`} onClick={() => setNotice(`Review opened for ${entry.ign}. Result publishing is ready.`)}>REVIEW</button></div></div>)}</div></section><section className="admin-panels"><div className="surface admin-info"><p className="eyebrow">PUBLISHING GUIDE</p><h2>Make the ladder trustworthy.</h2><p>Only publish results after a direct matchup has been observed. A tier is a record of proof, not a claim.</p><Link href="/" data-testid="link-admin-leaderboard">VIEW LIVE LADDER →</Link></div><div className="surface admin-info"><p className="eyebrow">CURRENT BLOCK</p><div className="big-stat"><strong>03</strong><span>requests waiting</span></div><div className="stat-row"><span>ACTIVE TESTERS</span><b>02</b></div></div></section></main></SiteFrame>;
}

function Router() {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}><Switch><Route path="/" component={Leaderboard} /><Route path="/queue/:kit" component={QueuePage} /><Route path="/profile/:ign" component={ProfilePage} /><Route path="/admin" component={AdminPage} /><Route component={NotFound} /></Switch></ErrorBoundary>;
}

function App() {
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router /></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>;
}

export default App;