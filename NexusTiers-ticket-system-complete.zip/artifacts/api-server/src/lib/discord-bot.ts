import {
  closeQueue,
  clearPlayerTiers,
  createTicket,
  createApplication,
  getState,
  joinTester,
  joinQueue,
  leaveQueue,
  leaveTester,
  nextTicket,
  openQueue,
  saveState,
  setManualTiers,
  setupServer,
  skipTicket,
  submitResult,
  ticketForChannel,
  updateTicket,
  updateApplication,
  verifyAccount,
  ApplicationType,
  NexusApplication,
  NexusTicket,
  KITS,
  KIT_LABELS,
  TIERS,
  TicketType,
} from "./nexus";
import { logger } from "./logger";

type GatewaySocket = {
  addEventListener: (
    type: string,
    listener: (event: {
      data?: string;
      code?: number;
      reason?: string;
      error?: unknown;
    }) => void,
  ) => void;
  send: (data: string) => void;
  close: () => void;
};
type DiscordOption = { name: string; value?: string; type?: number; options?: DiscordOption[] };
type DiscordComponent = {
  type?: number;
  custom_id?: string;
  value?: string;
  label?: string;
  style?: number;
  min_length?: number;
  max_length?: number;
  required?: boolean;
  placeholder?: string;
  components?: DiscordComponent[];
  options?: Array<{ label: string; value: string; description?: string }>;
  disabled?: boolean;
};
type DiscordInteraction = {
  id: string;
  token: string;
  guild_id?: string;
  channel_id?: string;
  member?: { user?: { id: string; username: string }; roles?: string[]; permissions?: string };
  user?: { id: string; username: string };
  data?: {
    name?: string;
    options?: DiscordOption[];
    custom_id?: string;
    component_type?: number;
    components?: DiscordComponent[];
    values?: string[];
  };
};
type DiscordGuildMember = {
  guild_id?: string;
  user?: { id: string; username?: string };
  roles?: string[];
  premium_since?: string | null;
};
type DiscordRole = {
  id: string;
  name: string;
  managed?: boolean;
  position?: number;
};
type DiscordMessage = {
  id: string;
  channel_id: string;
  channel_type?: number;
  guild_id?: string;
  content?: string;
  author?: { id: string; bot?: boolean; username?: string };
};
type DiscordChannel = {
  id: string;
  name?: string;
  type?: number;
};

const rest = (path: string, init: RequestInit = {}) => {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) throw new Error("DISCORD_BOT_TOKEN is not configured.");
  return fetch(`https://discord.com/api/v10${path}`, {
    ...init,
    headers: {
      Authorization: `Bot ${token}`,
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
};

async function createTicketChannel(
  guildId: string,
  kit: string,
  playerUsername: string,
  testerUsername: string,
  playerUserId: string,
  testerUserId: string,
  botUserId?: string,
) {
  const safePlayer = playerUsername.toLowerCase().replace(/[^a-z0-9-]/g, "-").slice(0, 24);
  const categoryResponse = await rest(`/guilds/${guildId}/channels`);
  const guildChannels = categoryResponse.ok
    ? (await categoryResponse.json()) as Array<{ id: string; name: string; type?: number }>
    : [];
  const ticketsCategory = guildChannels.find(
    (channel) => channel.type === 4 && (channel.name === "Tickets" || channel.name === "🎫・Tickets"),
  );
  const response = await rest(`/guilds/${guildId}/channels`, {
    method: "POST",
    body: JSON.stringify({
      name: `🎫・ticket-${kit}-${safePlayer}`,
      type: 0,
      ...(ticketsCategory ? { parent_id: ticketsCategory.id } : {}),
      topic: `NexusTiers ${kit} ticket • player ${playerUsername} • tester ${testerUsername}`,
      permission_overwrites: [
        { id: guildId, type: 0, deny: "1024" },
        { id: playerUserId, type: 1, allow: "68608" },
        { id: testerUserId, type: 1, allow: "68608" },
        ...(botUserId ? [{ id: botUserId, type: 1, allow: "68608" }] : []),
      ],
    }),
  });
  if (!response.ok) throw new Error(`Could not create ticket channel: ${response.status}`);
  return (await response.json()) as { id: string; name: string };
}

async function deleteAllRoles(guildId: string) {
  const response = await rest(`/guilds/${guildId}/roles`);
  if (!response.ok) throw new Error(`Could not read Discord roles: ${response.status}`);
  const roles = (await response.json()) as Array<{ id: string; name: string; managed?: boolean }>;
  const deleted: string[] = [];
  const skipped: string[] = [];
  for (const role of roles) {
    if (role.id === guildId || role.managed) continue;
    const deleteResponse = await rest(`/guilds/${guildId}/roles/${role.id}`, { method: "DELETE" });
    if (deleteResponse.ok) deleted.push(role.name);
    else skipped.push(role.name);
  }
  return { deleted, skipped };
}

async function deleteAllChannels(guildId: string) {
  const response = await rest(`/guilds/${guildId}/channels`);
  if (!response.ok) throw new Error(`Could not read Discord channels: ${response.status}`);
  const channels = (await response.json()) as Array<{ id: string; name: string }>;
  const deleted: string[] = [];
  const skipped: string[] = [];

  for (const channel of channels) {
    const deleteResponse = await rest(`/channels/${channel.id}`, { method: "DELETE" });
    if (deleteResponse.ok) deleted.push(channel.name);
    else skipped.push(channel.name);
  }

  return { deleted, skipped };
}

const TIER_ROLE_COLORS: Record<string, number> = {
  lt5: 0x95a5a6,
  ht5: 0x7f8c8d,
  lt4: 0x2ecc71,
  ht4: 0x27ae60,
  lt3: 0x3498db,
  ht3: 0x2980b9,
  lt2: 0x9b59b6,
  ht2: 0x8e44ad,
  lt1: 0xf1c40f,
  ht1: 0xe74c3c,
};

async function createTierRoles(guildId: string) {
  const response = await rest("/guilds/" + guildId + "/roles");
  if (!response.ok) throw new Error("Could not read Discord roles: " + response.status);
  const roles = (await response.json()) as Array<{
    id: string;
    name: string;
    managed?: boolean;
    color?: number;
    hoist?: boolean;
  }> ;
  const desiredRoles = KITS.flatMap((kit) =>
    TIERS.filter((tier) => tier !== "N/A").map((tier) => ({
      name: tier.toUpperCase() + " " + KIT_LABELS[kit],
      color: TIER_ROLE_COLORS[tier],
    })),
  );
  const created: string[] = [];
  const updated: string[] = [];
  const skipped: string[] = [];

  for (const desired of desiredRoles) {
    const existing = roles.find((role) => role.name.toLowerCase() === desired.name.toLowerCase());
    if (existing) {
      if (existing.managed) {
        skipped.push(desired.name);
        continue;
      }
      if (existing.name !== desired.name || existing.color !== desired.color || existing.hoist !== true) {
        const updateResponse = await rest("/guilds/" + guildId + "/roles/" + existing.id, {
          method: "PATCH",
          body: JSON.stringify({ name: desired.name, color: desired.color, hoist: true, mentionable: false }),
        });
        if (!updateResponse.ok) throw new Error("Could not update role \"" + desired.name + "\": " + updateResponse.status);
        updated.push(desired.name);
      }
      continue;
    }

    const createResponse = await rest("/guilds/" + guildId + "/roles", {
      method: "POST",
      body: JSON.stringify({ name: desired.name, color: desired.color, hoist: true, mentionable: false }),
    });
      if (!createResponse.ok) throw new Error("Could not create role \"" + desired.name + "\": " + createResponse.status);
    created.push(desired.name);
  }

  return { created, updated, skipped, total: desiredRoles.length };
}

async function findChannel(guildId: string, name: string) {
  const response = await rest(`/guilds/${guildId}/channels`);
  if (!response.ok) return null;
  const channels = (await response.json()) as Array<{ id: string; name: string; type?: number }>;
  return (
    channels.find((channel) => channel.name === name) ??
    channels.find((channel) => channel.type === 0 && channel.name.endsWith(`・${name}`)) ??
    channels.find((channel) => channel.type === 0 && channel.name.endsWith(`-${name}`)) ??
    null
  );
}

async function postToChannel(channelId: string, content: string, extra: Record<string, unknown> = {}) {
  const response = await rest(`/channels/${channelId}/messages`, {
    method: "POST",
    body: JSON.stringify({
      ...(content ? { content } : {}),
      ...extra,
    }),
  });
  if (!response.ok) {
    throw new Error(`Could not send a Discord message: ${response.status}`);
  }
  return (await response.json()) as { id: string; channel_id?: string };
}

async function deleteMessage(channelId: string, messageId: string) {
  const response = await rest(`/channels/${channelId}/messages/${messageId}`, { method: "DELETE" });
  if (!response.ok && response.status !== 404) {
    throw new Error(`Could not delete the Discord message: ${response.status}`);
  }
}

async function getChannel(channelId: string) {
  const response = await rest(`/channels/${channelId}`);
  if (!response.ok) throw new Error(`Could not inspect the Discord channel: ${response.status}`);
  return (await response.json()) as DiscordChannel;
}

const TICKET_TYPES: Array<{ value: TicketType; label: string; description: string }> = [
  { value: "support", label: "Support", description: "Get help from the NexusTiers team" },
  { value: "report", label: "Report", description: "Report a player or incident" },
  { value: "staff_report", label: "Staff Report", description: "Privately report a staff member" },
];
const TICKET_CHANNEL_CATEGORIES: Record<TicketType, string> = {
  support: "Support",
  report: "Reports",
  staff_report: "Staff Reports",
};
const TICKET_STAFF_ROLES = [
  { name: "Manager", envNames: ["MANAGER_ROLE_ID"] },
  { name: "Admin", envNames: ["ADMIN_ROLE_ID"] },
  { name: "Mod", envNames: ["MOD_ROLE_ID"] },
  { name: "Helper", envNames: ["HELPER_ROLE_ID"] },
];
const TICKET_VIEW_PERMISSIONS = "68608";
const TICKET_READ_ONLY_PERMISSIONS = "66560";
const TICKET_SEND_PERMISSION = "2048";

const ticketPanel = {
  embeds: [
    {
      title: "NexusTiers Support",
      description: "Need help? Select the type of ticket you want to create below.",
      color: 0x5865f2,
      footer: { text: "Please provide clear and complete information." },
    },
  ],
  components: [
    {
      type: 1,
      components: [
        {
          type: 3,
          custom_id: "ticket_type",
          placeholder: "Select a ticket type",
          options: TICKET_TYPES.map((ticket) => ({
            label: ticket.label,
            value: ticket.value,
            description: ticket.description,
          })),
        },
      ],
    },
  ],
};

function ticketType(value: string | undefined): TicketType | undefined {
  return TICKET_TYPES.some((ticket) => ticket.value === value) ? value as TicketType : undefined;
}

function ticketModalComponents(type: TicketType) {
  const fields =
    type === "support"
      ? [
          {
            custom_id: "reason",
            label: "Why are you creating this ticket?",
            placeholder: "Please explain why you are creating this ticket...",
          },
        ]
      : [
          {
            custom_id: "reported_user",
            label: type === "report" ? "Who are you reporting?" : "Which staff member are you reporting?",
            placeholder:
              type === "report"
                ? "Enter the Discord or Minecraft username of the player..."
                : "Enter the staff member's Discord username...",
          },
          {
            custom_id: "reason",
            label: type === "report" ? "Why are you reporting this player?" : "Why are you reporting this staff member?",
            placeholder:
              type === "report"
                ? "Please explain the reason for this report..."
                : "Please explain the reason for this report...",
          },
          {
            custom_id: "evidence",
            label: "Evidence",
            placeholder:
              type === "report"
                ? "Please provide links or information about your evidence..."
                : "Please provide any relevant evidence...",
          },
        ];

  return fields.map((field) => ({
    type: 1,
    components: [
      {
        type: 4,
        custom_id: field.custom_id,
        label: field.label,
        style: 2,
        min_length: 1,
        max_length: 1000,
        required: true,
        placeholder: field.placeholder,
      },
    ],
  }));
}

function ticketControls(status: "open" | "closed") {
  return [
    {
      type: 1,
      components:
        status === "open"
          ? [
              { type: 2, style: 4, label: "Close Ticket", custom_id: "ticket_close" },
              { type: 2, style: 1, label: "Claim Ticket", custom_id: "ticket_claim" },
            ]
          : [{ type: 2, style: 4, label: "Delete Ticket", custom_id: "ticket_delete" }],
    },
  ];
}

function ticketDisplayName(type: TicketType) {
  return TICKET_TYPES.find((ticket) => ticket.value === type)?.label ?? "Ticket";
}

function ticketCategoryEnvName(type: TicketType) {
  return `${type === "support" ? "SUPPORT" : type === "report" ? "REPORTS" : "STAFF_REPORTS"}_CATEGORY_ID`;
}

async function findOrCreateTicketCategory(guildId: string, type: TicketType) {
  const response = await rest(`/guilds/${guildId}/channels`);
  if (!response.ok) throw new Error(`Could not read Discord channels: ${response.status}`);
  const channels = (await response.json()) as Array<{ id: string; name?: string; type?: number }>;
  const configuredId = process.env[ticketCategoryEnvName(type)]?.trim();
  const configured = configuredId && channels.find((channel) => channel.id === configuredId && channel.type === 4);
  if (configured) return configured;

  const categoryName = TICKET_CHANNEL_CATEGORIES[type];
  const existing = channels.find(
    (channel) =>
      channel.type === 4 &&
      (channel.name?.toLowerCase() === categoryName.toLowerCase() ||
        channel.name?.toLowerCase().endsWith(`・${categoryName.toLowerCase()}`)),
  );
  if (existing) return existing;

  const createResponse = await rest(`/guilds/${guildId}/channels`, {
    method: "POST",
    body: JSON.stringify({ name: categoryName, type: 4 }),
  });
  if (!createResponse.ok) {
    throw new Error(`Could not create the ${categoryName} ticket category: ${createResponse.status}`);
  }
  return (await createResponse.json()) as { id: string; name?: string; type?: number };
}

async function ticketRoleOverwrites(guildId: string, knownRoles?: DiscordRole[]) {
  const roles = knownRoles ?? (await getGuildRoles(guildId));
  const overwrites: Array<{ id: string; type: number; allow: string; deny?: string }> = [];
  for (const staffRole of TICKET_STAFF_ROLES) {
    const role = await findRoleWithConfig(guildId, staffRole.envNames, staffRole.name, roles);
    if (role) overwrites.push({ id: role.id, type: 0, allow: TICKET_VIEW_PERMISSIONS });
  }
  return overwrites;
}

async function createSupportTicketChannel(
  guildId: string,
  type: TicketType,
  ticketId: string,
  creatorId: string,
  creatorUsername: string,
  botUserId?: string,
) {
  const category = await findOrCreateTicketCategory(guildId, type);
  const roles = await getGuildRoles(guildId);
  const ownerId = await getGuildOwnerId(guildId);
  const safeUsername = creatorUsername.toLowerCase().replace(/[^a-z0-9-]/g, "-").slice(0, 18) || "user";
  const staffOverwrites = type === "staff_report" ? [] : await ticketRoleOverwrites(guildId, roles);
  const permissionOverwrites = [
    { id: guildId, type: 0, deny: "1024" },
    { id: creatorId, type: 1, allow: TICKET_VIEW_PERMISSIONS },
    ...(type === "staff_report" && ownerId !== creatorId
      ? [{ id: ownerId, type: 1, allow: TICKET_VIEW_PERMISSIONS }]
      : []),
    ...staffOverwrites,
    ...(botUserId ? [{ id: botUserId, type: 1, allow: TICKET_VIEW_PERMISSIONS }] : []),
  ];
  const response = await rest(`/guilds/${guildId}/channels`, {
    method: "POST",
    body: JSON.stringify({
      name: `ticket-${type}-${safeUsername}`,
      type: 0,
      parent_id: category.id,
      topic: `NexusTiers ${ticketDisplayName(type)} • ${ticketId}`,
      permission_overwrites: permissionOverwrites,
    }),
  });
  if (!response.ok) {
    throw new Error(`Could not create the ticket channel: ${response.status}`);
  }
  return (await response.json()) as { id: string; name: string };
}

function ticketFieldValue(value: string | undefined) {
  const trimmed = value?.trim();
  if (!trimmed) throw new Error("Please complete all required ticket fields.");
  return trimmed;
}

function ticketEmbed(ticket: NexusTicket) {
  const fields =
    ticket.type === "support"
      ? [{ name: "Reason", value: ticket.reason, inline: false }]
      : [
          {
            name: ticket.type === "report" ? "Reported Player" : "Staff Member Reported",
            value: ticket.reportedUser ?? "Not provided",
            inline: false,
          },
          { name: "Reason", value: ticket.reason, inline: false },
          { name: "Evidence", value: ticket.evidence ?? "Not provided", inline: false },
        ];
  return {
    embeds: [
      {
        title: ticketDisplayName(ticket.type),
        description:
          ticket.type === "staff_report"
            ? "This report is private and can only be viewed by you and the Owner."
            : "A staff member will assist you shortly.",
        color: ticket.type === "staff_report" ? 0xed4245 : 0x5865f2,
        fields: [
          { name: "Created by", value: `<@${ticket.creatorId}>`, inline: false },
          ...fields,
        ],
        footer: { text: `Ticket ID: ${ticket.id}` },
      },
    ],
    components: ticketControls(ticket.status),
    allowed_mentions: { parse: [] },
  };
}

async function postTicketMessage(ticket: NexusTicket) {
  return postToChannel(ticket.channelId, "", ticketEmbed(ticket));
}

async function getTicket(ticketId: string) {
  const state = await getState();
  return state.tickets.find((ticket) => ticket.id === ticketId);
}

async function hasTicketStaffPermission(interaction: DiscordInteraction, ticket: NexusTicket, ownerOnly = false) {
  if (!interaction.guild_id) return false;
  const userId = actor(interaction).id;
  if ((await getGuildOwnerId(interaction.guild_id)) === userId) return true;
  if (ownerOnly) return false;
  const memberRoles = interaction.member?.roles ?? [];
  const roles = await getGuildRoles(interaction.guild_id);
  return TICKET_STAFF_ROLES.some((staffRole) => {
    const role = roles.find(
      (candidate) =>
        candidate.name.toLowerCase() === staffRole.name.toLowerCase() ||
        staffRole.envNames.some((envName) => process.env[envName]?.trim() === candidate.id),
    );
    return Boolean(role && memberRoles.includes(role.id));
  });
}

async function canManageTicket(interaction: DiscordInteraction, ticket: NexusTicket, action: "claim" | "close" | "delete") {
  const userId = actor(interaction).id;
  const isCreator = userId === ticket.creatorId;
  if (ticket.type === "staff_report") {
    if (action === "claim" || action === "delete") {
      return hasTicketStaffPermission(interaction, ticket, true);
    }
    return isCreator || (await hasTicketStaffPermission(interaction, ticket, true));
  }
  if (action === "claim" || action === "delete") {
    return hasTicketStaffPermission(interaction, ticket);
  }
  return isCreator || (await hasTicketStaffPermission(interaction, ticket));
}

async function closeTicketChannel(ticket: NexusTicket) {
  const response = await rest(`/channels/${ticket.channelId}/permissions/${ticket.creatorId}`, {
    method: "PUT",
    body: JSON.stringify({
      type: 1,
      allow: TICKET_READ_ONLY_PERMISSIONS,
      deny: TICKET_SEND_PERMISSION,
    }),
  });
  if (!response.ok) throw new Error(`Could not close the ticket channel: ${response.status}`);
}

async function deleteQueueTicketChannel(channelId: string) {
  const response = await rest(`/channels/${channelId}`, { method: "DELETE" });
  if (!response.ok && response.status !== 404) {
    throw new Error(`Could not delete the queue ticket channel: ${response.status}`);
  }
}

async function deleteTicketChannel(ticket: NexusTicket) {
  const response = await rest(`/channels/${ticket.channelId}`, { method: "DELETE" });
  if (!response.ok && response.status !== 404) {
    throw new Error(`Could not delete the ticket channel: ${response.status}`);
  }
}

type QueuePanelQueue = {
  entries: Array<{ discordUserId: string; username: string }>;
  activeTesters: Array<{ discordUserId: string; username: string }>;
};

type QueuePanelReference = {
  guildId: string;
  kit: string;
  channelId: string;
  messageId: string;
};

const queuePanels = new Map<string, QueuePanelReference>();
const ticketChannelKits = new Map<string, string>();
let queuePanelUpdaterStarted = false;

function queuePanelPayload(queue: QueuePanelQueue, kit: string) {
  const queueLines = queue.entries.length > 0
    ? queue.entries
        .slice(0, 20)
        .map((entry, index) => `${index + 1}. <@${entry.discordUserId}>`)
        .join("\n")
    : "No players currently in queue.";
  const testerLines = queue.activeTesters.length > 0
    ? queue.activeTesters
        .map((tester, index) => `${index + 1}. <@${tester.discordUserId}>`)
        .join("\n")
    : "No active testers.";

  return {
    embeds: [
      {
        title: "Tester(s) Available!",
        description: [
          "⏱️ The queue updates every 10 seconds.",
          "Use `/leave` if you wish to be removed from the waitlist or queue.",
          "",
          `**Queue (${queue.entries.length}/20):**`,
          queueLines,
          "",
          "**Active Testers:**",
          testerLines,
        ].join("\n"),
        color: 0x5865f2,
      },
    ],
    components: [
      {
        type: 1,
        components: [{ type: 2, style: 1, label: "Join Queue", custom_id: `nexus_enter_waitlist:${kit}` }],
      },
    ],
  };
}

function closedQueuePanelPayload(queue: { lastUpdate: string }) {
  const timestamp = Math.floor(new Date(queue.lastUpdate).getTime() / 1000);
  const lastSession = Number.isFinite(timestamp)
    ? `<t:${timestamp}:F>\n<t:${timestamp}:t>`
    : "Not available";

  return {
    embeds: [
      {
        title: "No Testers Online",
        description: [
          "No testers for your region are available at this time.",
          "You will be pinged when a tester is available.",
          "Check back later!",
        ].join("\n\n"),
        color: 0xff0000,
        fields: [{ name: "Last testing session:", value: lastSession }],
      },
    ],
  };
}

function kitFromChannelName(channelName: string | undefined) {
  const normalized = (channelName ?? "").toLowerCase().replaceAll("・", "-");
  return KITS.find((kit) =>
    normalized.includes(`${kit}-waitlist`) ||
    normalized.includes(`ticket-${kit}-`),
  );
}

async function resolveKit(interaction: DiscordInteraction) {
  const channelId = interaction.channel_id?.trim();
  if (channelId) {
    const panel = [...queuePanels.values()].find((candidate) => candidate.channelId === channelId);
    if (panel) return panel.kit;

    const trackedTicketKit = ticketChannelKits.get(channelId);
    if (trackedTicketKit) return trackedTicketKit;

    const channel = await getChannel(channelId);
    const channelKit = kitFromChannelName(channel.name);
    if (channelKit) return channelKit;
  }

  const state = await getState();
  const activeKits = KITS.filter((kit) => state.queues[kit].currentTicket);
  if (activeKits.length === 1) return activeKits[0];

  throw new Error("Could not determine the kit. Run this command in the kit's waitlist or ticket channel.");
}

async function updateQueuePanel(panel: QueuePanelReference) {
  const state = await getState();
  const queue = state.queues[panel.kit as keyof typeof state.queues];
  if (!queue) return;
  if (queue.status === "closed") return;
  const response = await rest(`/channels/${panel.channelId}/messages/${panel.messageId}`, {
    method: "PATCH",
    body: JSON.stringify(queuePanelPayload(queue, panel.kit)),
  });
  if (response.status === 404) {
    queuePanels.delete(`${panel.guildId}:${panel.kit}`);
    return;
  }
  if (!response.ok) throw new Error(`Could not update queue panel: ${response.status}`);
}

function startQueuePanelUpdater() {
  if (queuePanelUpdaterStarted) return;
  queuePanelUpdaterStarted = true;
  setInterval(() => {
    void Promise.all([...queuePanels.values()].map((panel) => updateQueuePanel(panel))).catch((error) => {
      logger.warn({ error }, "Could not refresh one or more queue panels");
    });
  }, 10_000);
}

async function getGuildRoles(guildId: string) {
  const response = await rest(`/guilds/${guildId}/roles`);
  if (!response.ok) {
    throw new Error(`Could not read Discord roles: ${response.status}`);
  }
  return (await response.json()) as DiscordRole[];
}

async function findAutomaticRole(
  guildId: string,
  envName: string,
  fallbackName: string,
  knownRoles?: DiscordRole[],
) {
  const roles = knownRoles ?? (await getGuildRoles(guildId));
  const configuredRoleId = process.env[envName]?.trim();
  if (configuredRoleId) {
    const configuredRole = roles.find((role) => role.id === configuredRoleId);
    if (configuredRole) return configuredRole;
    logger.warn(
      { guildId, envName, configuredRoleId, fallbackName },
      "Configured automatic role ID was not found; trying the role name",
    );
  }
  return roles.find((role) => role.name.toLowerCase() === fallbackName.toLowerCase()) ?? null;
}

function hasRestrictedRole(memberRoles: string[] | undefined, roles: DiscordRole[]) {
  const configuredRoleId = process.env.RESTRICTED_ROLE_ID?.trim();
  const restrictedRole =
    (configuredRoleId && roles.find((role) => role.id === configuredRoleId)) ||
    roles.find((role) => role.name.toLowerCase() === "restricted");
  return Boolean(restrictedRole && memberRoles?.includes(restrictedRole.id));
}

function automaticRoleFailure(
  guildId: string,
  userId: string,
  role: DiscordRole,
  action: "assign" | "remove",
  status: number,
) {
  logger.warn(
    { guildId, userId, roleId: role.id, roleName: role.name, action, status },
    `Could not ${action} automatic Discord role. Check Manage Roles permission and role hierarchy.`,
  );
}

async function assignAutomaticRole(
  guildId: string,
  member: DiscordGuildMember,
  role: DiscordRole,
  roles: DiscordRole[],
  botUserId?: string,
) {
  const userId = member.user?.id;
  if (!userId || member.roles?.includes(role.id)) return;
  if (role.managed) {
    logger.warn({ guildId, userId, roleId: role.id, roleName: role.name }, "Automatic role is managed by Discord and cannot be assigned");
    return;
  }
  if (botUserId) {
    const botMemberResponse = await rest(`/guilds/${guildId}/members/${botUserId}`);
    if (botMemberResponse.ok) {
      const botMember = (await botMemberResponse.json()) as DiscordGuildMember;
      const botHighestRole = roles
        .filter((candidate) => botMember.roles?.includes(candidate.id))
        .sort((a, b) => (b.position ?? 0) - (a.position ?? 0))[0];
      if (botHighestRole && (role.position ?? 0) >= (botHighestRole.position ?? 0)) {
        logger.warn(
          {
            guildId,
            userId,
            roleId: role.id,
            roleName: role.name,
            rolePosition: role.position,
            botRolePosition: botHighestRole.position,
          },
          "Automatic role is not below the bot role in the Discord hierarchy",
        );
        return;
      }
    } else {
      logger.warn(
        { guildId, userId, botUserId, status: botMemberResponse.status },
        "Could not inspect the bot role hierarchy before assigning an automatic role",
      );
    }
  }
  const response = await rest(`/guilds/${guildId}/members/${userId}/roles/${role.id}`, { method: "PUT" });
  if (!response.ok) {
    automaticRoleFailure(guildId, userId, role, "assign", response.status);
    return;
  }
  logger.info({ guildId, userId, roleId: role.id, roleName: role.name }, "Automatic Discord role assigned");
}

async function removeAutomaticRole(
  guildId: string,
  member: DiscordGuildMember,
  role: DiscordRole,
) {
  const userId = member.user?.id;
  if (!userId || !member.roles?.includes(role.id)) return;
  const response = await rest(`/guilds/${guildId}/members/${userId}/roles/${role.id}`, { method: "DELETE" });
  if (!response.ok) {
    automaticRoleFailure(guildId, userId, role, "remove", response.status);
    return;
  }
  logger.info({ guildId, userId, roleId: role.id, roleName: role.name }, "Automatic Discord role removed");
}

async function syncTierResultRole(guildId: string, result: { playerDiscordUserId?: string; kit: string; tier: string }, botUserId?: string) {
  const userId = result.playerDiscordUserId;
  if (!userId) return;

  const memberResponse = await rest(`/guilds/${guildId}/members/${userId}`);
  if (!memberResponse.ok) {
    logger.warn({ guildId, userId, status: memberResponse.status }, "Could not find result player for tier role assignment");
    return;
  }
  const member = (await memberResponse.json()) as DiscordGuildMember;
  const roles = await getGuildRoles(guildId);
  const kit = result.kit as (typeof KITS)[number];
  const kitLabel = KIT_LABELS[kit];
  if (!kitLabel) return;

  const kitTierRoles = roles.filter((role) =>
    TIERS.some((tier) => tier !== "N/A" && role.name.toLowerCase() === `${tier.toUpperCase()} ${kitLabel}`.toLowerCase()),
  );
  const targetRoleName = `${result.tier.toUpperCase()} ${kitLabel}`.toLowerCase();
  for (const role of kitTierRoles) {
    if (role.name.toLowerCase() !== targetRoleName) {
      await removeAutomaticRole(guildId, member, role);
    }
  }

  if (result.tier === "N/A") return;
  const targetRole = kitTierRoles.find((role) => role.name.toLowerCase() === targetRoleName);
  if (!targetRole) {
    logger.warn({ guildId, userId, kit, tier: result.tier }, "Tier role was not found; run /create role first");
    return;
  }
  await assignAutomaticRole(guildId, member, targetRole, roles, botUserId);
}

async function handleGuildMemberAdd(member: DiscordGuildMember, botUserId?: string) {
  const guildId = member.guild_id;
  const userId = member.user?.id;
  if (!guildId || !userId) return;
  try {
    const roles = await getGuildRoles(guildId);
    if (hasRestrictedRole(member.roles, roles)) {
      logger.info({ guildId, userId }, "Skipped automatic member role because the member is Restricted");
      return;
    }
    const memberRole = await findAutomaticRole(guildId, "MEMBER_ROLE_ID", "Member", roles);
    if (!memberRole) {
      logger.warn({ guildId, userId }, 'Automatic "Member" role was not found');
      return;
    }
    await assignAutomaticRole(guildId, member, memberRole, roles, botUserId);
  } catch (error) {
    logger.error({ error, guildId, userId }, "Automatic member role handling failed");
  }
}

async function handleGuildMemberUpdate(member: DiscordGuildMember, botUserId?: string) {
  const guildId = member.guild_id;
  const userId = member.user?.id;
  if (!guildId || !userId || !Object.prototype.hasOwnProperty.call(member, "premium_since")) return;
  try {
    const roles = await getGuildRoles(guildId);
    const boosterRole = await findAutomaticRole(guildId, "BOOSTER_ROLE_ID", "Booster", roles);
    if (!boosterRole) {
      logger.warn({ guildId, userId }, 'Automatic "Booster" role was not found');
      return;
    }
    if (member.premium_since) {
      if (hasRestrictedRole(member.roles, roles)) {
        logger.info({ guildId, userId }, "Skipped automatic booster role because the member is Restricted");
        return;
      }
      await assignAutomaticRole(guildId, member, boosterRole, roles, botUserId);
      return;
    }

    const latestMemberResponse = await rest(`/guilds/${guildId}/members/${userId}`);
    if (!latestMemberResponse.ok) {
      logger.warn({ guildId, userId, status: latestMemberResponse.status }, "Could not verify the member's current boost status");
      return;
    }
    const latestMember = (await latestMemberResponse.json()) as DiscordGuildMember;
    if (!latestMember.premium_since) {
      await removeAutomaticRole(guildId, latestMember, boosterRole);
    }
  } catch (error) {
    logger.error({ error, guildId, userId }, "Automatic booster role handling failed");
  }
}

const APPLICATION_KITS = (["uhc", "smp", "mace", "crystal", "sword", "axe", "diapot", "nethpot"] as const).map((kit) => ({
  label: KIT_LABELS[kit],
  value: kit,
}));

const applicationPanel = {
  embeds: [
    {
      title: "Applications",
      description: "Choose the application you would like to complete. All questions will be answered privately in your DMs.",
      color: 0x5865f2,
    },
  ],
  components: [
    {
      type: 1,
      components: [
        { type: 2, style: 1, label: "🧪 Tester Application", custom_id: "application_panel:tester" },
        { type: 2, style: 1, label: "🛡️ Staff Application", custom_id: "application_panel:staff" },
      ],
    },
  ],
};

function applicationStartComponents(applicationId: string) {
  return [
    {
      type: 1,
      components: [
        { type: 2, style: 3, label: "Start", custom_id: `application_start:${applicationId}` },
        { type: 2, style: 4, label: "Cancel", custom_id: `application_cancel:${applicationId}` },
      ],
    },
  ];
}

function applicationReviewComponents(applicationId: string, disabled = false) {
  return [
    {
      type: 1,
      components: [
        {
          type: 2,
          style: 3,
          label: "Accept Application",
          custom_id: `application_accept:${applicationId}`,
          disabled,
        },
        {
          type: 2,
          style: 4,
          label: "Reject Application",
          custom_id: `application_reject:${applicationId}`,
          disabled,
        },
      ],
    },
  ];
}

function applicationKitSelect(applicationId: string) {
  return [
    {
      type: 1,
      components: [
        {
          type: 3,
          custom_id: `application_kit:${applicationId}`,
          placeholder: "Select a kit",
          min_values: 1,
          max_values: 1,
          options: APPLICATION_KITS,
        },
      ],
    },
  ];
}

function applicationPositionSelect(applicationId: string) {
  return [
    {
      type: 1,
      components: [
        {
          type: 3,
          custom_id: `application_position:${applicationId}`,
          placeholder: "Select a position",
          min_values: 1,
          max_values: 1,
          options: [
            { label: "Manager", value: "Manager" },
            { label: "Admin", value: "Admin" },
            { label: "Mod", value: "Mod" },
            { label: "Helper", value: "Helper" },
          ],
        },
      ],
    },
  ];
}

async function openDirectMessage(userId: string) {
  const response = await rest("/users/@me/channels", {
    method: "POST",
    body: JSON.stringify({ recipient_id: userId }),
  });
  if (!response.ok) throw new Error(`Could not open a DM channel: ${response.status}`);
  return (await response.json()) as { id: string };
}

async function sendDirectMessage(
  userId: string,
  content: string,
  extra: Record<string, unknown> = {},
) {
  const channel = await openDirectMessage(userId);
  await postToChannel(channel.id, content, extra);
  return channel.id;
}

async function findApplicationChannel(
  guildId: string,
  envName: string,
  fallbackName: string,
  preferredChannelId?: string,
) {
  const configuredChannelId = preferredChannelId?.trim() || process.env[envName]?.trim();
  const response = await rest(`/guilds/${guildId}/channels`);
  if (!response.ok) throw new Error(`Could not read Discord channels: ${response.status}`);
  const channels = (await response.json()) as Array<{ id: string; name: string; type?: number }>;
  if (configuredChannelId) {
    const configuredChannel = channels.find((channel) => channel.id === configuredChannelId);
    if (configuredChannel) return configuredChannel;
    logger.warn(
      { guildId, envName, configuredChannelId, fallbackName },
      "Configured application channel ID was not found; trying the channel name",
    );
  }
  const normalizedName = fallbackName.toLowerCase();
  return (
    channels.find((channel) => channel.type === 0 && channel.name.toLowerCase() === normalizedName) ??
    channels.find((channel) => channel.type === 0 && channel.name.toLowerCase().endsWith(`・${normalizedName}`)) ??
    channels.find((channel) => channel.type === 0 && channel.name.toLowerCase().endsWith(`-${normalizedName}`)) ??
    null
  );
}

async function findRoleWithConfig(
  guildId: string,
  envNames: string[],
  fallbackName: string,
  knownRoles?: DiscordRole[],
) {
  const roles = knownRoles ?? (await getGuildRoles(guildId));
  for (const envName of envNames) {
    const configuredRoleId = process.env[envName]?.trim();
    if (!configuredRoleId) continue;
    const configuredRole = roles.find((role) => role.id === configuredRoleId);
    if (configuredRole) return configuredRole;
    logger.warn({ guildId, envName, configuredRoleId, fallbackName }, "Configured application role ID was not found");
  }
  return roles.find((role) => role.name.toLowerCase() === fallbackName.toLowerCase()) ?? null;
}

async function getGuildOwnerId(guildId: string) {
  const response = await rest(`/guilds/${guildId}`);
  if (!response.ok) throw new Error(`Could not verify the Discord server owner: ${response.status}`);
  return ((await response.json()) as { owner_id: string }).owner_id;
}

async function hasApplicationReviewPermission(
  interaction: DiscordInteraction,
  type: ApplicationType,
) {
  const guildId = interaction.guild_id;
  const userId = actor(interaction).id;
  if (!guildId || !userId) return false;
  if ((await getGuildOwnerId(guildId)) === userId) return true;
  const memberRoles = interaction.member?.roles ?? [];
  const roles = await getGuildRoles(guildId);
  const allowedRoleNames = type === "tester" ? ["Manager", "Admin", "Mod"] : ["Manager"];
  const allowedRoleIds = type === "tester"
    ? ["MANAGER_ROLE_ID", "ADMIN_ROLE_ID", "MOD_ROLE_ID"]
    : ["MANAGER_ROLE_ID"];
  return roles.some(
    (role) =>
      memberRoles.includes(role.id) &&
      (allowedRoleNames.some((name) => role.name.toLowerCase() === name.toLowerCase()) ||
        allowedRoleIds.some((envName) => process.env[envName]?.trim() === role.id)),
  );
}

const TESTER_QUESTION_KEYS = ["currentTier", "age", "reason", "previousTester", "testsPerWeek"] as const;
const TESTER_QUESTIONS = [
  "Which tier are you currently?",
  "How old are you?",
  "Why should we choose you as a Tester?",
  "Have you ever been a Tester on another tier list? If yes, which one?",
  "How many tests can you complete per week?",
] as const;
const STAFF_QUESTION_KEYS = ["age", "reason", "previousStaff", "position"] as const;
const STAFF_QUESTIONS = [
  "How old are you?",
  "Why should we choose you for the NexusTiers Staff Team?",
  "Do you have previous staff experience? If yes, explain.",
] as const;
const activeApplicationSteps = new Set<string>();

function applicationQuestion(type: ApplicationType, step: number) {
  const questions = type === "tester" ? TESTER_QUESTIONS : STAFF_QUESTIONS;
  const question = questions[step - 1];
  if (!question) throw new Error("This application question is not available.");
  return `Question ${step}/${questions.length}\n\n${question}`;
}

async function sendNextApplicationStep(application: NexusApplication) {
  if (application.type === "tester") {
    if (application.currentStep >= 1 && application.currentStep <= TESTER_QUESTIONS.length) {
      await sendDirectMessage(application.userId, applicationQuestion("tester", application.currentStep));
    } else if (application.currentStep > TESTER_QUESTIONS.length) {
      await submitCompletedApplication(application);
    }
    return;
  }

  if (application.currentStep >= 1 && application.currentStep <= STAFF_QUESTIONS.length) {
    await sendDirectMessage(application.userId, applicationQuestion("staff", application.currentStep));
  } else if (application.currentStep === STAFF_QUESTIONS.length + 1) {
    await sendDirectMessage(
      application.userId,
      `Question ${STAFF_QUESTIONS.length + 1}/${STAFF_QUESTIONS.length + 1}\n\nWhat position are you applying for?`,
      { components: applicationPositionSelect(application.id) },
    );
  }
}

async function applicationForUser(applicationId: string, userId: string) {
  const state = await getState();
  const application = state.applications.find((item) => item.id === applicationId);
  if (!application || application.userId !== userId) throw new Error("This application does not belong to you.");
  return application;
}

async function beginApplication(interaction: DiscordInteraction, type: ApplicationType) {
  const guildId = interaction.guild_id;
  const user = actor(interaction);
  if (!guildId) throw new Error("Applications can only be started from a Discord server.");
  const application = await createApplication({
    type,
    guildId,
    userId: user.id,
    username: user.username,
    applicationChannelId: interaction.channel_id,
  });
  try {
    const dmChannelId = await sendDirectMessage(
      user.id,
      "Would you like to start your application?",
      { components: applicationStartComponents(application.id) },
    );
    await updateApplication(application.id, { dmChannelId });
    await respond(interaction, "Check your DMs to start your application.", true);
  } catch (error) {
    await updateApplication(application.id, { status: "cancelled" }).catch(() => undefined);
    throw error;
  }
}

async function startApplication(interaction: DiscordInteraction, applicationId: string) {
  const application = await applicationForUser(applicationId, actor(interaction).id);
  if (application.status !== "in_progress") throw new Error("This application is no longer open.");
  if (application.currentStep !== -1) {
    await respond(interaction, "This application has already started. Continue in your DMs.", true);
    return;
  }
  if (application.type === "tester") {
    const dmChannelId = await sendDirectMessage(
      application.userId,
      "Which kit would you like to become a Tester for?",
      { components: applicationKitSelect(application.id) },
    );
    await updateApplication(application.id, { currentStep: 0, dmChannelId });
  } else {
    const dmChannelId = await sendDirectMessage(
      application.userId,
      applicationQuestion("staff", 1),
    );
    await updateApplication(application.id, { currentStep: 1, dmChannelId });
  }
  await respond(interaction, "Your application has started. Continue in your DMs.", true);
}

async function cancelApplication(interaction: DiscordInteraction, applicationId: string) {
  const application = await applicationForUser(applicationId, actor(interaction).id);
  if (application.status === "in_progress" || application.status === "submitted") {
    await updateApplication(application.id, { status: "cancelled" });
  }
  await respond(interaction, "Your application has been cancelled.", true);
}

function applicationAnswerFields(application: NexusApplication) {
  const entries: Array<[string, string]> = application.type === "tester"
    ? [
        ["Kit", application.kit ?? "N/A"],
        ["Current Tier", application.answers.currentTier ?? "N/A"],
        ["Age", application.answers.age ?? "N/A"],
        ["Why should we choose you as a Tester?", application.answers.reason ?? "N/A"],
        ["Previous Tester Experience", application.answers.previousTester ?? "N/A"],
        ["Tests per Week", application.answers.testsPerWeek ?? "N/A"],
      ]
    : [
        ["Age", application.answers.age ?? "N/A"],
        ["Why should we choose you for the NexusTiers Staff Team?", application.answers.reason ?? "N/A"],
        ["Previous Staff Experience", application.answers.previousStaff ?? "N/A"],
        ["Position", application.answers.position ?? "N/A"],
      ];
  return entries.flatMap(([name, value]) => {
    const chunks = value.match(/[\s\S]{1,1024}/g) ?? ["N/A"];
    return chunks.map((chunk, index) => ({
      name: index === 0 ? name : `${name} (continued)`,
      value: chunk,
      inline: false,
    }));
  });
}

async function submitCompletedApplication(application: NexusApplication) {
  try {
    const state = await getState();
    const configuredChannelId =
      state.applicationChannels?.[application.guildId]?.[application.type] ??
      application.applicationChannelId;
    const channel = await findApplicationChannel(
      application.guildId,
      application.type === "tester" ? "TESTER_APPLICATIONS_CHANNEL_ID" : "STAFF_APPLICATIONS_CHANNEL_ID",
      application.type === "tester" ? "tester-applications" : "staff-applications",
      configuredChannelId,
    );
    if (!channel) {
      throw new Error(
        `The ${application.type} applications channel was not found. Use /application${application.type} set in the desired channel.`,
      );
    }
    const message = await postToChannel(channel.id, "", {
      embeds: [
        {
          title: application.type === "tester" ? "🧪 Tester Application" : "🛡️ Staff Application",
          description: `Applicant: <@${application.userId}> (${application.username})`,
          color: application.type === "tester" ? 0x57f287 : 0xfee75c,
          fields: applicationAnswerFields(application),
          footer: { text: "NexusTiers Application Review" },
        },
      ],
      components: applicationReviewComponents(application.id),
    });
    await updateApplication(application.id, {
      status: "submitted",
      reviewChannelId: channel.id,
      reviewMessageId: message.id,
    });
    await sendDirectMessage(
      application.userId,
      `Your ${application.type === "tester" ? "Tester" : "Staff"} Application has been submitted for review.`,
    );
  } catch (error) {
    logger.error({ error, applicationId: application.id }, "Could not submit Discord application");
    await sendDirectMessage(
      application.userId,
      `Your application could not be submitted yet. The server owner must use /application${application.type} set in the desired channel.`,
    ).catch(() => undefined);
  }
}

async function handleApplicationKitSelection(interaction: DiscordInteraction, applicationId: string) {
  const application = await applicationForUser(applicationId, actor(interaction).id);
  if (application.status !== "in_progress" || application.type !== "tester" || application.currentStep !== 0) {
    throw new Error("This application is not waiting for a kit selection.");
  }
  const kit = interaction.data?.values?.[0]?.toLowerCase();
  if (!kit || !KITS.includes(kit as (typeof KITS)[number])) throw new Error("Please select a valid kit.");
  const updated = await updateApplication(application.id, { kit, currentStep: 1 });
  await sendNextApplicationStep(updated);
  await respond(interaction, "Kit selected. Continue in your DMs.", true);
}

async function handleApplicationPositionSelection(interaction: DiscordInteraction, applicationId: string) {
  const application = await applicationForUser(applicationId, actor(interaction).id);
  if (application.status !== "in_progress" || application.type !== "staff" || application.currentStep !== 4) {
    throw new Error("This application is not waiting for a position selection.");
  }
  const position = interaction.data?.values?.[0];
  if (!position || !["Manager", "Admin", "Mod", "Helper"].includes(position)) {
    throw new Error("Please select a valid position.");
  }
  const updated = await updateApplication(application.id, {
    answers: { ...application.answers, position },
    currentStep: 5,
  });
  await submitCompletedApplication(updated);
  await respond(interaction, "Your application has been submitted for review.", true);
}

async function handleDirectMessage(message: DiscordMessage) {
  if (
    message.guild_id ||
    (message.channel_type !== undefined && message.channel_type !== 1) ||
    message.author?.bot ||
    !message.author?.id ||
    !message.content?.trim()
  ) return;
  try {
    const state = await getState();
    const application = state.applications.find(
      (item) =>
        item.status === "in_progress" &&
        item.userId === message.author?.id &&
        item.dmChannelId === message.channel_id,
    );
    if (!application) return;

    if (activeApplicationSteps.has(application.id)) {
      await sendDirectMessage(
        application.userId,
        "Please wait a moment while I save your previous answer and send the next question.",
      );
      return;
    }
    activeApplicationSteps.add(application.id);

    try {
      if (application.type === "tester" && application.currentStep >= 1 && application.currentStep <= 5) {
        const key = TESTER_QUESTION_KEYS[application.currentStep - 1];
        const updated = await updateApplication(application.id, {
          answers: { ...application.answers, [key]: message.content.trim() },
          currentStep: application.currentStep + 1,
        });
        await sendNextApplicationStep(updated);
        return;
      }

      if (application.type === "staff" && application.currentStep >= 1 && application.currentStep <= 3) {
        const key = STAFF_QUESTION_KEYS[application.currentStep - 1];
        const updated = await updateApplication(application.id, {
          answers: { ...application.answers, [key]: message.content.trim() },
          currentStep: application.currentStep + 1,
        });
        await sendNextApplicationStep(updated);
      }
    } finally {
      activeApplicationSteps.delete(application.id);
    }
  } catch (error) {
    logger.error({ error, userId: message.author?.id, channelId: message.channel_id }, "Direct message application handling failed");
  }
}

async function assignApplicationRoles(application: NexusApplication, botUserId?: string) {
  const memberResponse = await rest(`/guilds/${application.guildId}/members/${application.userId}`);
  if (!memberResponse.ok) {
    logger.warn(
      { applicationId: application.id, userId: application.userId, status: memberResponse.status },
      "Could not find the applicant in the Discord server while assigning roles",
    );
    return;
  }
  const member = (await memberResponse.json()) as DiscordGuildMember;
  const roles = await getGuildRoles(application.guildId);
  if (hasRestrictedRole(member.roles, roles)) {
    logger.info({ applicationId: application.id, userId: application.userId }, "Skipped application roles because the applicant is Restricted");
    return;
  }

  const requestedRoles = application.type === "tester"
    ? [
        {
          envNames: ["VERIFIED_TESTER_ROLE_ID", "DISCORD_TESTER_ROLE_ID"],
          name: "Verified Tester",
        },
        {
          envNames: [
            `TESTER_${(application.kit ?? "").toUpperCase()}_ROLE_ID`,
            `${(application.kit ?? "").toUpperCase()}_TESTER_ROLE_ID`,
          ],
          name: `${KIT_LABELS[application.kit as keyof typeof KIT_LABELS] ?? application.kit} Tester`,
        },
      ]
    : [
        {
          envNames: [`STAFF_${(application.answers.position ?? "").toUpperCase()}_ROLE_ID`, `${(application.answers.position ?? "").toUpperCase()}_ROLE_ID`],
          name: application.answers.position ?? "Staff",
        },
      ];

  for (const requestedRole of requestedRoles) {
    const role = await findRoleWithConfig(application.guildId, requestedRole.envNames, requestedRole.name, roles);
    if (!role) {
      logger.warn(
        { applicationId: application.id, roleName: requestedRole.name },
        "Application role was not found; the application decision was still saved",
      );
      continue;
    }
    await assignAutomaticRole(application.guildId, member, role, roles, botUserId);
  }
}

async function handleApplicationDecision(
  interaction: DiscordInteraction,
  action: "accept" | "reject",
  applicationId: string,
  botUserId?: string,
) {
  const guildId = interaction.guild_id;
  if (!guildId) throw new Error("Application reviews can only be handled in a server.");
  const state = await getState();
  const application = state.applications.find((item) => item.id === applicationId);
  if (!application || application.guildId !== guildId) throw new Error("Application not found.");
  if (application.status !== "submitted") {
    await respond(interaction, "This application has already been decided.", true);
    return;
  }
  if (!(await hasApplicationReviewPermission(interaction, application.type))) {
    await respond(
      interaction,
      application.type === "tester"
        ? "You need the Owner, Manager, Admin, or Mod role to review Tester Applications."
        : "Only the Owner or Manager can review Staff Applications.",
      true,
    );
    return;
  }

  const nextStatus = action === "accept" ? "accepted" : "rejected";
  const updated = await updateApplication(application.id, {
    status: nextStatus,
    decisionBy: actor(interaction).id,
    decidedAt: new Date().toISOString(),
  });
  if (updated.reviewChannelId && updated.reviewMessageId) {
    await rest(`/channels/${updated.reviewChannelId}/messages/${updated.reviewMessageId}`, {
      method: "PATCH",
      body: JSON.stringify({ components: applicationReviewComponents(updated.id, true) }),
    }).catch((error) => logger.warn({ error, applicationId }, "Could not disable application review buttons"));
  }
  if (action === "accept") await assignApplicationRoles(updated, botUserId);
  await sendDirectMessage(
    updated.userId,
    updated.type === "tester"
      ? `Your Tester Application has been ${action === "accept" ? "accepted!" : "rejected."}`
      : action === "accept"
        ? "Your Staff Application has been accepted!"
        : "Your Staff Application has been rejected.",
  );
  await respond(interaction, `Application ${action === "accept" ? "accepted" : "rejected"}.`, true);
}

async function handleApplicationComponent(interaction: DiscordInteraction, customId: string, botUserId?: string) {
  const [action, value] = customId.split(":");
  if (action === "application_panel") {
    if (value !== "tester" && value !== "staff") throw new Error("Unknown application type.");
    await beginApplication(interaction, value);
    return;
  }
  const applicationId = value;
  if (!applicationId) throw new Error("Invalid application component.");
  if (action === "application_start") {
    await startApplication(interaction, applicationId);
  } else if (action === "application_cancel") {
    await cancelApplication(interaction, applicationId);
  } else if (action === "application_kit") {
    await handleApplicationKitSelection(interaction, applicationId);
  } else if (action === "application_position") {
    await handleApplicationPositionSelection(interaction, applicationId);
  } else if (action === "application_accept" || action === "application_reject") {
    await handleApplicationDecision(
      interaction,
      action === "application_accept" ? "accept" : "reject",
      applicationId,
      botUserId,
    );
  }
}

const verificationPanel = {
  embeds: [
    {
      title: "📝 Evaluation Testing Waitlist",
      description: [
        "Upon applying, you will be added to a waitlist channel.",
        "Here you will be pinged when a tester of your region is available.",
        "If you are HT3 or higher, a high ticket will be created.",
        "",
        "• Region should be the region of the server you wish to test on",
        "",
        "• Username should be the name of the account you will be testing on",
        "",
        "🛑 **Failure to provide authentic information will result in a denied test.**",
      ].join("\n"),
      color: 0xff0d63,
    },
  ],
  components: [
    {
      type: 1,
      components: [
        { type: 2, style: 1, label: "Verify Account", custom_id: "nexus_verify_account" },
        { type: 2, style: 1, label: "Enter Waitlist", custom_id: "nexus_enter_waitlist" },
      ],
    },
    {
      type: 1,
      components: [
        { type: 2, style: 1, label: "View Cooldown", custom_id: "nexus_view_cooldown" },
      ],
    },
  ],
};

async function postVerificationPanel(guildId: string) {
  const requestTestChannel = await findChannel(guildId, "request-test");
  if (!requestTestChannel) {
    throw new Error("The 📩・request-test channel was not found. Run `/createchannel` first.");
  }
  await postToChannel(requestTestChannel.id, "", verificationPanel);
  return requestTestChannel;
}

function findOption(options: DiscordOption[] | undefined, name: string): DiscordOption | undefined {
  for (const item of options ?? []) {
    if (item.name === name && item.value !== undefined) return item;
    const nested = findOption(item.options, name);
    if (nested) return nested;
  }
  return undefined;
}

function option(interaction: DiscordInteraction, name: string) {
  return findOption(interaction.data?.options, name)?.value;
}

function requiredOption(interaction: DiscordInteraction, name: string) {
  const value = option(interaction, name);
  if (!value) throw new Error(`Please select an option for \`${name}\`.`);
  return value;
}

function actor(interaction: DiscordInteraction) {
  return interaction.member?.user ?? interaction.user ?? { id: "unknown", username: "Discord user" };
}

function hasTesterPermission(interaction: DiscordInteraction) {
  const permissions = BigInt(interaction.member?.permissions ?? "0");
  const administrator = (permissions & 0x8n) === 0x8n;
  const configuredRole = process.env.DISCORD_TESTER_ROLE_ID;
  const hasRole = Boolean(configuredRole && interaction.member?.roles?.includes(configuredRole));
  return administrator || hasRole;
}

function hasQueueTesterPermission(interaction: DiscordInteraction) {
  const permissions = BigInt(interaction.member?.permissions ?? "0");
  const administrator = (permissions & 0x8n) === 0x8n;
  const configuredRoles = [
    process.env.DISCORD_TESTER_ROLE_ID?.trim(),
    process.env.VERIFIED_TESTER_ROLE_ID?.trim(),
  ].filter((roleId): roleId is string => Boolean(roleId));
  return administrator || configuredRoles.some((roleId) => interaction.member?.roles?.includes(roleId));
}

function hasManageRolesPermission(interaction: DiscordInteraction) {
  const permissions = BigInt(interaction.member?.permissions ?? "0");
  const administrator = (permissions & 0x8n) === 0x8n;
  const manageRoles = (permissions & 0x10000000n) === 0x10000000n;
  return administrator || manageRoles;
}

async function hasApplicationPanelPermission(interaction: DiscordInteraction) {
  const permissions = BigInt(interaction.member?.permissions ?? "0");
  const administrator = (permissions & 0x8n) === 0x8n;
  const manageGuild = (permissions & 0x20n) === 0x20n;
  return administrator || manageGuild || (interaction.guild_id ? (await getGuildOwnerId(interaction.guild_id)) === actor(interaction).id : false);
}

async function setApplicationChannel(interaction: DiscordInteraction, type: ApplicationType) {
  if (!interaction.guild_id) {
    await respond(interaction, "This command can only be used in a server.", true);
    return;
  }

  if ((await getGuildOwnerId(interaction.guild_id)) !== actor(interaction).id) {
    await respond(interaction, "Only the server owner can use this command.", true);
    return;
  }

  const channelId = interaction.channel_id?.trim();
  if (!channelId) throw new Error("This command must be run in a text channel.");
  const channelResponse = await rest(`/channels/${channelId}`);
  if (!channelResponse.ok) throw new Error(`Could not inspect the Discord channel: ${channelResponse.status}`);
  const channel = (await channelResponse.json()) as { id: string; name?: string; type?: number };
  if (channel.type !== 0) throw new Error("Please run this command in a regular text channel.");

  const state = await getState();
  state.applicationChannels = state.applicationChannels ?? {};
  state.applicationChannels[interaction.guild_id] = {
    ...state.applicationChannels[interaction.guild_id],
    [type]: channel.id,
  };
  await saveState(state);

  const label = type === "tester" ? "Tester" : "Staff";
  const completedApplications = state.applications.filter(
    (application) =>
      application.guildId === interaction.guild_id &&
      application.type === type &&
      application.status === "in_progress" &&
      (type === "tester"
        ? application.currentStep > TESTER_QUESTIONS.length
        : application.currentStep > STAFF_QUESTIONS.length + 1),
  );
  let recovered = 0;
  for (const application of completedApplications) {
    await submitCompletedApplication(application);
    if (application.status === "submitted") recovered += 1;
  }
  const recoveredMessage = recovered > 0
    ? ` ${recovered} previously completed application(s) were also published.`
    : "";
  await respond(
    interaction,
    `${label} applications will now be collected in <#${channel.id}>.${recoveredMessage}`,
    true,
  );
}

function findSubcommand(options: DiscordOption[] | undefined): string | undefined {
  for (const item of options ?? []) {
    if (
      item.type === 1 ||
      String(item.type) === "1" ||
      item.name === "role" ||
      item.name === "all"
    ) {
      return item.name;
    }
    const nested = findSubcommand(item.options);
    if (nested) return nested;
  }
  return undefined;
}

function subcommand(interaction: DiscordInteraction) {
  return findSubcommand(interaction.data?.options);
}

function parseManualTierSpec(value: string) {
  const assignments = value
    .split(/[,;]+/)
    .map((part) => part.trim())
    .filter(Boolean)
    .map((part) => {
      const match = part.match(/^([a-z]+)\s*(?::|=|\s)\s*(n\/a|lt[1-5]|ht[1-5])$/i);
      if (!match) {
        throw new Error("Use tiers like `sword:lt4,mace:ht5`.");
      }
      return { kit: match[1].toLowerCase(), tier: match[2].toLowerCase() };
    });

  if (assignments.length === 0) throw new Error("At least one kit and tier is required.");
  for (const assignment of assignments) {
    if (!KITS.includes(assignment.kit as (typeof KITS)[number])) {
      throw new Error(`Unknown kit \`${assignment.kit}\`. Allowed kits: ${KITS.join(", ")}.`);
    }
    if (!TIERS.includes(assignment.tier as (typeof TIERS)[number])) {
      throw new Error(`Unknown tier \`${assignment.tier}\`. Allowed tiers: ${TIERS.join(", ")}.`);
    }
    if (assignments.filter((item) => item.kit === assignment.kit).length > 1) {
      throw new Error(`Only one tier per kit can be set at a time: \`${assignment.kit}\`.`);
    }
  }
  return assignments;
}

async function respond(
  interaction: DiscordInteraction,
  content: string,
  ephemeral = false,
  components?: DiscordComponent[],
) {
  await rest(`/interactions/${interaction.id}/${interaction.token}/callback`, {
    method: "POST",
    body: JSON.stringify({
      type: 4,
      data: {
        content,
        flags: ephemeral ? 64 : 0,
        ...(components ? { components } : {}),
      },
    }),
  });
}

async function showModal(
  interaction: DiscordInteraction,
  customId: string,
  title: string,
  components: DiscordComponent[],
) {
  await rest(`/interactions/${interaction.id}/${interaction.token}/callback`, {
    method: "POST",
    body: JSON.stringify({
      type: 9,
      data: { custom_id: customId, title, components },
    }),
  });
}

function componentValue(components: DiscordComponent[] | undefined, customId: string): string | undefined {
  for (const component of components ?? []) {
    if (component.custom_id === customId) return component.value;
    const nested = componentValue(component.components, customId);
    if (nested !== undefined) return nested;
  }
  return undefined;
}

async function registerCommands(applicationId: string) {
  const commands = [
    {
      name: "open",
      description: "Open the queue for this waitlist channel",
    },
    {
      name: "close",
      description: "Close the queue for this waitlist channel",
    },
    {
      name: "leave",
      description: "Leave the current queue",
    },
    {
      name: "testerleave",
      description: "Leave only the tester queue for this waitlist",
    },
    {
      name: "testerjoin",
      description: "Join only the tester queue for this waitlist",
    },
    {
      name: "next",
      description: "Open the next tester ticket for this channel",
    },
    {
      name: "skip",
      description: "Skip the current ticket for this channel",
    },
    {
      name: "result",
      description: "Save the current ticket result",
      options: [
        { name: "tier", description: "New tier", type: 3, required: true, choices: TIERS.map((tier) => ({ name: tier, value: tier })) },
      ],
    },
    {
      name: "verify",
      description: "Postet das NexusTiers Verifizierungs- und Waitlist-Panel",
    },
    {
      name: "applications",
      description: "Post the Tester and Staff application panel",
    },
    {
      name: "tickets",
      description: "Post the NexusTiers support ticket panel",
    },
    {
      name: "applicationstaff",
      description: "Set the channel for completed Staff applications",
      options: [
        {
          name: "set",
          description: "Use this channel for completed Staff applications",
          type: 1,
        },
      ],
    },
    {
      name: "applicationtester",
      description: "Set the channel for completed Tester applications",
      options: [
        {
          name: "set",
          description: "Use this channel for completed Tester applications",
          type: 1,
        },
      ],
    },
    {
      name: "createchannel",
      description: "Create NexusTiers channels and roles",
    },
    {
      name: "create",
      description: "Create NexusTiers tier roles",
      options: [{ name: "role", description: "Create all colored tier roles", type: 1 }],
    },
    {
      name: "delete",
      description: "Destructive NexusTiers administration",
      options: [
        { name: "role", description: "Delete all custom roles", type: 1 },
        { name: "all", description: "Delete all custom roles and channels", type: 1 },
      ],
    },
    {
      name: "clear",
      description: "Clear all website tiers for a user",
      options: [{ name: "user", description: "Discord user whose tiers should be removed", type: 6, required: true }],
    },
    {
      name: "user",
      description: "Owner-only manual user tier management",
      options: [
        {
          name: "set",
          description: "Assign tiers without a ticket",
          type: 1,
          options: [
            { name: "minecraft", description: "Minecraft username", type: 3, required: true },
            { name: "discord", description: "Discord name", type: 3, required: true },
            { name: "tiers", description: "Use kit:tier, e.g. sword:lt4,mace:ht5", type: 3, required: true },
          ],
        },
      ],
    },
  ];
  const guildId = process.env.DISCORD_GUILD_ID;
  const path = guildId
    ? `/applications/${applicationId}/guilds/${guildId}/commands`
    : `/applications/${applicationId}/commands`;

  if (guildId) {
    const clearGlobalResponse = await rest(`/applications/${applicationId}/commands`, {
      method: "PUT",
      body: JSON.stringify([]),
    });
    if (!clearGlobalResponse.ok) {
      throw new Error(
        `Could not remove old global commands: ${clearGlobalResponse.status} ${await clearGlobalResponse.text()}`,
      );
    }
  }
  logger.info({ path, commands: commands.map((command) => command.name) }, "Registering NexusTiers slash commands");
  const response = await rest(path, { method: "PUT", body: JSON.stringify(commands) });
  if (!response.ok) throw new Error(`Could not register commands: ${response.status} ${await response.text()}`);
  const registeredResponse = await rest(path);
  if (registeredResponse.ok) {
    const registered = (await registeredResponse.json()) as Array<{ name?: string }>;
    const counts = new Map<string, number>();
    for (const command of registered) {
      if (command.name) counts.set(command.name, (counts.get(command.name) ?? 0) + 1);
    }
    const duplicates = [...counts.entries()]
      .filter(([, count]) => count > 1)
      .map(([name, count]) => `${name} x${count}`);
    logger.info(
      { path, commandCount: registered.length, duplicates },
      "NexusTiers slash commands replaced",
    );
  }
}

async function joinQueueFromButton(interaction: DiscordInteraction, kit: string) {
  const user = actor(interaction);
  const state = await getState();
  const verified = state.verified.find((account) => account.discordUserId === user.id);
  if (!verified) {
    throw new Error("Please verify your Minecraft account using the Verify Account button first.");
  }
  const latestKitResult = state.results
    .filter(
      (result) =>
        result.kit === kit &&
        (result.playerDiscordUserId === user.id ||
          result.ign.toLowerCase() === verified.ign.toLowerCase()),
    )
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0];
  const entry = await joinQueue(
    {
      discordUserId: user.id,
      username: user.username,
      ign: verified.ign,
      currentTier: latestKitResult?.tier ?? "N/A",
      region: "EU",
      server: "eu.practice.net",
      kit,
    },
    kit,
  );
  if (interaction.guild_id) {
    const panel = queuePanels.get(`${interaction.guild_id}:${kit}`);
    if (panel) await updateQueuePanel(panel).catch((error) => logger.warn({ error }, "Could not refresh queue panel after join"));
  }
  await respond(interaction, `You are on the **${kit}** waitlist. Position: **#${entry.position}**.`, true);
}

function queueRoleEnvNames(kit: string) {
  const normalizedKit = kit.toUpperCase();
  return [`${normalizedKit}_QUEUE_ROLE_ID`, `QUEUE_${normalizedKit}_ROLE_ID`];
}

async function findOrCreateQueueRole(
  guildId: string,
  kit: string,
  roles: DiscordRole[],
) {
  const fallbackName = `${KIT_LABELS[kit as keyof typeof KIT_LABELS] ?? kit} Queue`;
  const existing = await findRoleWithConfig(guildId, queueRoleEnvNames(kit), fallbackName, roles);
  if (existing) return existing;

  const response = await rest(`/guilds/${guildId}/roles`, {
    method: "POST",
    body: JSON.stringify({
      name: fallbackName,
      color: 0x5865f2,
      hoist: true,
      mentionable: false,
    }),
  });
  if (!response.ok) {
    throw new Error(`Could not create the ${fallbackName} role: ${response.status}`);
  }
  return (await response.json()) as DiscordRole;
}

async function assignQueueRole(
  guildId: string,
  userId: string,
  kit: string,
  botUserId?: string,
) {
  const memberResponse = await rest(`/guilds/${guildId}/members/${userId}`);
  if (!memberResponse.ok) throw new Error("You must be a member of this Discord server.");
  const member = (await memberResponse.json()) as DiscordGuildMember;
  const roles = await getGuildRoles(guildId);
  if (hasRestrictedRole(member.roles, roles)) {
    throw new Error("Restricted members cannot enter a queue.");
  }

  const selectedRole = await findOrCreateQueueRole(guildId, kit, roles);
  const allRoles = [...roles, ...(roles.some((role) => role.id === selectedRole.id) ? [] : [selectedRole])];
  for (const otherKit of KITS) {
    if (otherKit === kit) continue;
    const otherRole = await findRoleWithConfig(
      guildId,
      queueRoleEnvNames(otherKit),
      `${KIT_LABELS[otherKit]} Queue`,
      allRoles,
    );
    if (otherRole) await removeAutomaticRole(guildId, member, otherRole);
  }
  await assignAutomaticRole(guildId, member, selectedRole, allRoles, botUserId);
  return selectedRole;
}

async function postTicketPanel(guildId: string, channelId: string) {
  const targetChannelId = process.env.TICKET_PANEL_CHANNEL_ID?.trim() || channelId;
  const channel = await getChannel(targetChannelId);
  if (channel.type !== 0) throw new Error("The ticket panel must be posted in a regular text channel.");
  await postToChannel(targetChannelId, "", ticketPanel);
  return targetChannelId;
}

async function handleTicketTypeSelection(interaction: DiscordInteraction) {
  const selected = ticketType(interaction.data?.values?.[0]);
  if (!selected) throw new Error("Please select a valid ticket type.");
  if (!interaction.guild_id) throw new Error("Tickets can only be created in a server.");

  const state = await getState();
  const existing = state.tickets.find(
    (ticket) =>
      ticket.guildId === interaction.guild_id &&
      ticket.creatorId === actor(interaction).id &&
      ticket.type === selected &&
      ticket.status === "open",
  );
  if (existing) {
    await respond(interaction, "You already have an open ticket in this category.", true);
    return;
  }

  await showModal(
    interaction,
    `ticket_modal:${selected}`,
    `${ticketDisplayName(selected)} Ticket`,
    ticketModalComponents(selected),
  );
}

async function handleTicketModalSubmit(interaction: DiscordInteraction, customId: string, botUserId?: string) {
  const selected = ticketType(customId.split(":")[1]);
  if (!selected) throw new Error("Please select a valid ticket type.");
  const guildId = interaction.guild_id;
  if (!guildId) throw new Error("Tickets can only be created in a server.");

  const user = actor(interaction);
  const reason = ticketFieldValue(componentValue(interaction.data?.components, "reason"));
  const reportedUser =
    selected === "support" ? undefined : ticketFieldValue(componentValue(interaction.data?.components, "reported_user"));
  const evidence =
    selected === "support" ? undefined : ticketFieldValue(componentValue(interaction.data?.components, "evidence"));
  const ticketId = `ticket_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

  const channel = await createSupportTicketChannel(
    guildId,
    selected,
    ticketId,
    user.id,
    user.username,
    botUserId,
  );
  try {
    const ticket = await createTicket({
      id: ticketId,
      guildId,
      channelId: channel.id,
      creatorId: user.id,
      creatorUsername: user.username,
      type: selected,
      reportedUser,
      reason,
      evidence,
      createdAt: new Date().toISOString(),
    });
    await postTicketMessage(ticket);
    await respond(interaction, `Your ${ticketDisplayName(selected).toLowerCase()} ticket has been created: <#${channel.id}>.`, true);
  } catch (error) {
    await deleteTicketChannel({ channelId: channel.id } as NexusTicket).catch((cleanupError) =>
      logger.warn({ cleanupError, channelId: channel.id }, "Could not clean up an incomplete ticket channel"),
    );
    throw error;
  }
}

async function ticketFromInteraction(interaction: DiscordInteraction) {
  if (!interaction.channel_id) throw new Error("This ticket action must be used inside a ticket channel.");
  const state = await getState();
  const ticket = ticketForChannel(state, interaction.channel_id);
  if (!ticket) throw new Error("This channel is not an active NexusTiers ticket.");
  return ticket;
}

async function handleTicketButtonInteraction(interaction: DiscordInteraction, customId: string) {
  const ticket = await ticketFromInteraction(interaction);
  const action = customId.replace("ticket_", "");

  if (action === "close") {
    if (ticket.status !== "open") {
      await respond(interaction, "This ticket is already closed.", true);
      return;
    }
    if (!(await canManageTicket(interaction, ticket, "close"))) {
      await respond(interaction, "You do not have permission to close this ticket.", true);
      return;
    }
    await respond(interaction, "Are you sure you want to close this ticket?", true, [
      {
        type: 1,
        components: [
          { type: 2, style: 4, label: "Confirm", custom_id: "ticket_close_confirm" },
          { type: 2, style: 2, label: "Cancel", custom_id: "ticket_close_cancel" },
        ],
      },
    ]);
    return;
  }

  if (action === "close_cancel") {
    await respond(interaction, "Ticket close cancelled.", true);
    return;
  }

  if (action === "close_confirm") {
    if (ticket.status !== "open") {
      await respond(interaction, "This ticket is already closed.", true);
      return;
    }
    if (!(await canManageTicket(interaction, ticket, "close"))) {
      await respond(interaction, "You do not have permission to close this ticket.", true);
      return;
    }
    await closeTicketChannel(ticket);
    const closedTicket = await updateTicket(ticket.id, {
      status: "closed",
      closedAt: new Date().toISOString(),
    });
    await postToChannel(
      closedTicket.channelId,
      "This ticket has been closed. Authorized staff may delete it.",
      { components: ticketControls("closed") },
    );
    await respond(interaction, "Ticket closed.", true);
    return;
  }

  if (action === "claim") {
    if (ticket.status !== "open") {
      await respond(interaction, "Closed tickets cannot be claimed.", true);
      return;
    }
    if (!(await canManageTicket(interaction, ticket, "claim"))) {
      await respond(
        interaction,
        ticket.type === "staff_report"
          ? "Only the Owner can claim a Staff Report."
          : "Only authorized staff members can claim this ticket.",
        true,
      );
      return;
    }
    const claimedTicket = await updateTicket(ticket.id, { claimedBy: actor(interaction).id });
    await postToChannel(claimedTicket.channelId, `Ticket claimed by <@${actor(interaction).id}>`, {
      allowed_mentions: { parse: [] },
    });
    await respond(interaction, "Ticket claimed.", true);
    return;
  }

  if (action === "delete") {
    if (ticket.status !== "closed") {
      await respond(interaction, "Close the ticket before deleting it.", true);
      return;
    }
    if (!(await canManageTicket(interaction, ticket, "delete"))) {
      await respond(
        interaction,
        ticket.type === "staff_report"
          ? "Only the Owner can delete a Staff Report."
          : "Only authorized staff members can delete this ticket.",
        true,
      );
      return;
    }
    await deleteTicketChannel(ticket);
    await respond(interaction, "Ticket deleted.", true);
  }
}

async function handleTicketComponent(interaction: DiscordInteraction, customId: string, botUserId?: string) {
  if (customId === "ticket_type") {
    await handleTicketTypeSelection(interaction);
    return;
  }
  if (customId.startsWith("ticket_modal:")) {
    await handleTicketModalSubmit(interaction, customId, botUserId);
    return;
  }
  await handleTicketButtonInteraction(interaction, customId);
}

async function handleButtonInteraction(interaction: DiscordInteraction, customId: string) {
  if (customId === "nexus_verify_account") {
    await showModal(interaction, "nexus_verify_account_modal", "Verify Account", [
      {
        type: 1,
        components: [
          {
            type: 4,
            custom_id: "ign",
            label: "Minecraft Username",
            style: 1,
            min_length: 1,
            max_length: 16,
            required: true,
            placeholder: "Dein Minecraft-Name",
          },
        ],
      },
    ]);
    return;
  }

  if (customId.startsWith("nexus_enter_waitlist:")) {
    const kit = customId.split(":")[1]?.toLowerCase();
    if (!kit || !KITS.includes(kit as (typeof KITS)[number])) throw new Error("Invalid queue.");
    await joinQueueFromButton(interaction, kit);
    return;
  }

  if (customId === "nexus_enter_waitlist") {
    if (interaction.guild_id && interaction.channel_id) {
      const channelResponse = await rest(`/channels/${interaction.channel_id}`);
      if (channelResponse.ok) {
        const channel = (await channelResponse.json()) as { name?: string };
        const channelName = channel.name ?? "";
        const kit = KITS.find(
          (candidate) =>
            channelName === `${candidate}-waitlist` ||
            channelName.endsWith(`・${candidate}-waitlist`) ||
            channelName.endsWith(`-${candidate}-waitlist`),
        );
        if (kit) {
          await joinQueueFromButton(interaction, kit);
          return;
        }
      }
    }
    await showModal(interaction, "nexus_enter_waitlist_modal", "Enter Waitlist", [
      {
        type: 1,
        components: [
          {
            type: 4,
            custom_id: "kit",
            label: "Kit",
            style: 1,
            required: true,
            placeholder: "z. B. sword",
          },
        ],
      },
      {
        type: 1,
        components: [
          {
            type: 4,
            custom_id: "region",
            label: "Region",
            style: 1,
            required: true,
            placeholder: "EU, NA oder AS",
          },
        ],
      },
      {
        type: 1,
        components: [
          {
            type: 4,
            custom_id: "server",
            label: "Server",
            style: 1,
            required: true,
            placeholder: "eu.practice.net",
          },
        ],
      },
    ]);
    return;
  }

  if (customId === "nexus_view_cooldown") {
    await respond(interaction, "Du hast derzeit keinen aktiven Cooldown.", true);
  }
}

async function handleModalSubmit(
  interaction: DiscordInteraction,
  customId: string,
  botUserId?: string,
) {
  const user = actor(interaction);
  if (customId === "nexus_verify_account_modal") {
    const ign = componentValue(interaction.data?.components, "ign")?.trim();
    if (!ign) throw new Error("Please enter your Minecraft username.");
    const account = await verifyAccount({ discordUserId: user.id, username: user.username, ign });
    await respond(interaction, `Account **${account.ign}** ist verifiziert.`, true);
    return;
  }

  if (customId === "nexus_enter_waitlist_modal") {
    const state = await getState();
    const verified = state.verified.find((account) => account.discordUserId === user.id);
    if (!verified) {
      throw new Error("Please click **Verify Account** and verify your Minecraft account first.");
    }
    const kit = componentValue(interaction.data?.components, "kit")?.trim().toLowerCase();
    if (!kit || !KITS.includes(kit as (typeof KITS)[number])) {
      throw new Error(`Invalid kit. Allowed kits: ${KITS.join(", ")}.`);
    }
    if (!interaction.guild_id) throw new Error("This action can only be used in a server.");
    const role = await assignQueueRole(interaction.guild_id, user.id, kit, botUserId);
    await respond(interaction, `You received the **${role.name}** role.`, true);
  }
}

async function handleInteraction(interaction: DiscordInteraction, botUserId?: string) {
  const name = interaction.data?.name;
  const user = actor(interaction);
  try {
    if (interaction.data?.component_type && interaction.data.custom_id?.startsWith("application_")) {
      await handleApplicationComponent(interaction, interaction.data.custom_id, botUserId);
      return;
    }
    if (interaction.data?.custom_id?.startsWith("ticket_modal:")) {
      await handleTicketComponent(interaction, interaction.data.custom_id, botUserId);
      return;
    }
    if (
      interaction.data?.component_type &&
      interaction.data.custom_id &&
      (interaction.data.custom_id === "ticket_type" || interaction.data.custom_id.startsWith("ticket_"))
    ) {
      await handleTicketComponent(interaction, interaction.data.custom_id, botUserId);
      return;
    }
    if (interaction.data?.component_type === 2 && interaction.data.custom_id) {
      await handleButtonInteraction(interaction, interaction.data.custom_id);
      return;
    }
    if (interaction.data?.custom_id?.endsWith("_modal")) {
      await handleModalSubmit(interaction, interaction.data.custom_id, botUserId);
      return;
    }
    if (name === "verify") {
      if (!interaction.guild_id) {
        await respond(interaction, "This command can only be used in a server.", true);
        return;
      }
      const guildResponse = await rest(`/guilds/${interaction.guild_id}`);
      if (!guildResponse.ok) throw new Error(`Could not verify the server owner: ${guildResponse.status}`);
      const guild = (await guildResponse.json()) as { owner_id: string };
      if (guild.owner_id !== user.id) {
        await respond(interaction, "Only the server owner can use this command.", true);
        return;
      }
      const channel = await postVerificationPanel(interaction.guild_id);
      await respond(interaction, `The verification panel was posted in <#${channel.id}>.`, true);
      return;
    }
    if (name === "applicationstaff" || name === "applicationtester") {
      if (subcommand(interaction) !== "set") {
        await respond(
          interaction,
          `Use this command as \`/${name} set\` in the desired target channel.`,
          true,
        );
        return;
      }
      await setApplicationChannel(interaction, name === "applicationstaff" ? "staff" : "tester");
      return;
    }
    if (name === "applications") {
      if (!interaction.guild_id) {
        await respond(interaction, "This command can only be used in a server.", true);
        return;
      }
      if (!(await hasApplicationPanelPermission(interaction))) {
        await respond(interaction, "You need the Manage Server permission to post the application panel.", true);
        return;
      }
      const panelChannelId = process.env.APPLICATION_PANEL_CHANNEL_ID?.trim() || interaction.channel_id;
      if (!panelChannelId) throw new Error("No application panel channel is configured.");
      await postToChannel(panelChannelId, "", applicationPanel);
      await respond(interaction, "Application panel posted.", true);
      return;
    }
    if (name === "tickets") {
      if (!interaction.guild_id) {
        await respond(interaction, "This command can only be used in a server.", true);
        return;
      }
      if (!(await hasApplicationPanelPermission(interaction))) {
        await respond(interaction, "You need the Manage Server permission to post the ticket panel.", true);
        return;
      }
      const panelChannelId = await postTicketPanel(interaction.guild_id, interaction.channel_id ?? "");
      await respond(interaction, `Ticket panel posted in <#${panelChannelId}>.`, true);
      return;
    }
    if (name === "create") {
      if (subcommand(interaction) !== "role") {
        await respond(interaction, "Use this command as \`/create role\`.", true);
        return;
      }
      if (!interaction.guild_id) {
        await respond(interaction, "This command can only be used in a server.", true);
        return;
      }
      if (!hasManageRolesPermission(interaction)) {
        await respond(interaction, "You need the \`Manage Roles\` permission for this command.", true);
        return;
      }
      const roleResult = await createTierRoles(interaction.guild_id);
      const skippedMessage = roleResult.skipped.length > 0
        ? " " + roleResult.skipped.length + " managed roles were skipped."
        : "";
      await respond(
        interaction,
        "Tier roles complete: " + roleResult.created.length + " created, " + roleResult.updated.length + " updated out of " + roleResult.total + ". All tier roles are colored and independently visible." + skippedMessage,
      );
      return;
    }
    if (name === "delete") {
      if (!interaction.guild_id) {
        await respond(interaction, "This command can only be used in a server.", true);
        return;
      }
      const guildResponse = await rest(`/guilds/${interaction.guild_id}`);
      if (!guildResponse.ok) throw new Error(`Could not verify the server owner: ${guildResponse.status}`);
      const guild = (await guildResponse.json()) as { owner_id: string };
      if (guild.owner_id !== user.id) {
        await respond(interaction, "Only the server owner can delete roles.", true);
        return;
      }
      const deleteMode = subcommand(interaction);
      if (deleteMode !== "role" && deleteMode !== "all") {
        logger.warn(
          {
            command: name,
            options: interaction.data?.options?.map((item) => ({
              name: item.name,
              type: item.type,
              nested: item.options?.map((nested) => ({ name: nested.name, type: nested.type })),
            })),
          },
          "Could not identify delete subcommand",
        );
        await respond(interaction, "Use this command as `/delete role` or `/delete all`.", true);
        return;
      }
      const roleResult = await deleteAllRoles(interaction.guild_id);
      const skippedMessage = roleResult.skipped.length > 0
        ? ` ${roleResult.skipped.length} roles could not be deleted because of Discord permissions or role hierarchy.`
        : "";
      if (deleteMode === "role") {
        await respond(interaction, `Role deletion complete: ${roleResult.deleted.length} roles deleted.${skippedMessage}`);
        return;
      }
      const channelResult = await deleteAllChannels(interaction.guild_id);
      const skippedChannelsMessage = channelResult.skipped.length > 0
        ? ` ${channelResult.skipped.length} channels could not be deleted because of Discord permissions.`
        : "";
      await respond(
        interaction,
        `Full deletion complete: ${roleResult.deleted.length} roles and ${channelResult.deleted.length} channels deleted.${skippedMessage}${skippedChannelsMessage}`,
      );
      return;
    }
    if (name === "clear") {
      if (!interaction.guild_id) {
        await respond(interaction, "This command can only be used in a server.", true);
        return;
      }
      const guildResponse = await rest(`/guilds/${interaction.guild_id}`);
      if (!guildResponse.ok) throw new Error(`Could not verify the server owner: ${guildResponse.status}`);
      const guild = (await guildResponse.json()) as { owner_id: string };
      if (guild.owner_id !== user.id) {
        await respond(interaction, "Only the server owner can clear website tiers.", true);
        return;
      }
      const targetUserId = String(option(interaction, "user"));
      const cleared = await clearPlayerTiers(targetUserId);
      const resultLabel = cleared.removedCount === 1 ? "result" : "results";
      await respond(
        interaction,
        `Website tiers removed for <@${targetUserId}>: ${cleared.removedCount} ${resultLabel}.`,
        true,
      );
      return;
    }
    if (name === "user") {
      if (!interaction.guild_id) {
        await respond(interaction, "This command can only be used in a server.", true);
        return;
      }
      if (subcommand(interaction) !== "set") {
        await respond(
          interaction,
          "Use this command as `/user set minecraft discord tiers` — for example `sword:lt4,mace:ht5`.",
          true,
        );
        return;
      }
      const guildResponse = await rest(`/guilds/${interaction.guild_id}`);
      if (!guildResponse.ok) throw new Error(`Could not verify the server owner: ${guildResponse.status}`);
      const guild = (await guildResponse.json()) as { owner_id: string };
      if (guild.owner_id !== user.id) {
        await respond(interaction, "Only the server owner can use `/user set`.", true);
        return;
      }

      const minecraftName = String(requiredOption(interaction, "minecraft")).trim();
      const discordName = String(requiredOption(interaction, "discord")).trim();
      const tierAssignments = parseManualTierSpec(String(requiredOption(interaction, "tiers")));
      const results = await setManualTiers({
        ign: minecraftName,
        playerUsername: discordName,
        tiers: tierAssignments,
        assignedBy: user.username,
      });
      await respond(
        interaction,
        `Manual tiers set for **${minecraftName}** (${discordName}): ${results
          .map((result) => `**${result.kit} ${result.tier}**`)
          .join(", ")}.`,
        true,
      );
      return;
    }
    if (name === "createchannel" && !hasTesterPermission(interaction)) {
      await respond(interaction, "Only the Verified Tester rank can use this command.", true);
      return;
    }
    if (["open", "close", "next", "skip", "result", "testerleave", "testerjoin"].includes(name ?? "") && !hasQueueTesterPermission(interaction)) {
      await respond(interaction, "Only the Verified Tester rank can use this command.", true);
      return;
    }
    if (name === "open") {
      const kit = await resolveKit(interaction);
      if (!interaction.guild_id) throw new Error("This command can only be used in a server.");
      const waitlistChannel = await findChannel(interaction.guild_id, `${kit}-waitlist`);
      if (!waitlistChannel) {
        throw new Error(`The #${kit}-waitlist channel was not found. Run \`/createchannel\` first.`);
      }
      const queue = await openQueue({ actorId: user.id, actorName: user.username }, kit);
      const panelKey = `${interaction.guild_id}:${kit}`;
      const existingPanel = queuePanels.get(panelKey);
      let panelMessageId = existingPanel?.messageId;
      if (existingPanel) {
        const updateResponse = await rest(`/channels/${existingPanel.channelId}/messages/${existingPanel.messageId}`, {
          method: "PATCH",
          body: JSON.stringify(queuePanelPayload(queue, kit)),
        });
        if (!updateResponse.ok) {
          queuePanels.delete(panelKey);
          panelMessageId = undefined;
        }
      }
      if (!panelMessageId) {
        const message = await postToChannel(waitlistChannel.id, "", queuePanelPayload(queue, kit));
        panelMessageId = message.id;
      }
      queuePanels.set(panelKey, {
        guildId: interaction.guild_id,
        kit,
        channelId: waitlistChannel.id,
        messageId: panelMessageId,
      });
      startQueuePanelUpdater();
      await respond(
        interaction,
        `The **${queue.label}** queue is open. The queue panel was updated in <#${waitlistChannel.id}>.`,
        true,
      );
      return;
    }
    if (name === "close") {
      const kit = await resolveKit(interaction);
      if (!interaction.guild_id) throw new Error("This command can only be used in a server.");
      const waitlistChannel = await findChannel(interaction.guild_id, `${kit}-waitlist`);
      if (!waitlistChannel) {
        throw new Error(`The #${kit}-waitlist channel was not found. Run \`/createchannel\` first.`);
      }
      const queue = await closeQueue({ actorId: user.id, actorName: user.username }, kit);
      const panelKey = `${interaction.guild_id}:${kit}`;
      const existingPanel = queuePanels.get(panelKey);
      if (existingPanel) {
        await deleteMessage(existingPanel.channelId, existingPanel.messageId);
        queuePanels.delete(panelKey);
      }
      const closedMessage = await postToChannel(
        waitlistChannel.id,
        "",
        closedQueuePanelPayload(queue),
      );
      queuePanels.set(panelKey, {
        guildId: interaction.guild_id,
        kit,
        channelId: waitlistChannel.id,
        messageId: closedMessage.id,
      });
      startQueuePanelUpdater();
      await respond(
        interaction,
        `The **${queue.label}** queue is closed. The previous queue message was deleted and replaced.`,
        true,
      );
      return;
    }
    if (name === "leave") {
      const kit = await resolveKit(interaction);
      const result = await leaveQueue(
        { discordUserId: user.id, username: user.username },
        kit,
      );
      if (interaction.guild_id) {
        const panel = queuePanels.get(`${interaction.guild_id}:${kit}`);
        if (panel) {
          await updateQueuePanel(panel).catch((error) => {
            logger.warn({ error }, "Could not refresh queue panel after leave");
          });
        }
      }
      await respond(
        interaction,
        `You left the **${result.queue.label}** queue. Your previous position was **#${result.previousPosition}**.`,
        true,
      );
      return;
    }
    if (name === "testerleave") {
      const kit = await resolveKit(interaction);
      const result = await leaveTester({ actorId: user.id, actorName: user.username }, kit);
      if (interaction.guild_id) {
        const panel = queuePanels.get(`${interaction.guild_id}:${kit}`);
        if (panel) {
          await updateQueuePanel(panel).catch((error) => {
            logger.warn({ error }, "Could not refresh queue panel after tester leave");
          });
        }
      }
      await respond(interaction, `You left the tester queue for **${result.queue.label}**. Your player queue entry was not changed.`, true);
      return;
    }
    if (name === "testerjoin") {
      const kit = await resolveKit(interaction);
      const result = await joinTester({ actorId: user.id, actorName: user.username }, kit);
      if (interaction.guild_id) {
        const panel = queuePanels.get(`${interaction.guild_id}:${kit}`);
        if (panel) {
          await updateQueuePanel(panel).catch((error) => {
            logger.warn({ error }, "Could not refresh queue panel after tester join");
          });
        }
      }
      await respond(interaction, `You joined the tester queue for **${result.label}**. Your player queue entry was not changed.`, true);
      return;
    }
    if (name === "next") {
      const kit = await resolveKit(interaction);
      const ticket = await nextTicket({ actorId: user.id, actorName: user.username }, kit);
      const ticketChannel = interaction.guild_id
        ? await createTicketChannel(
            interaction.guild_id,
            kit,
            ticket.player.username,
            ticket.tester.username,
            ticket.player.discordUserId,
            ticket.tester.discordUserId,
            botUserId,
          )
        : null;
      if (ticketChannel) ticketChannelKits.set(ticketChannel.id, kit);
      if (ticketChannel) {
        await postToChannel(
          ticketChannel.id,
          `**NexusTiers Ticket**\nPlayer: <@${ticket.player.discordUserId}> (${ticket.player.ign})\nTester: <@${ticket.tester.discordUserId}>\nKit: **${kit}**\nCurrent Tier: **${ticket.player.currentTier || "N/A"}**\nWhen finished: \`/result\` • If the player does not show up: \`/skip\``,
        );
      }
      return;
    }
    if (name === "skip") {
      const kit = await resolveKit(interaction);
      const state = await getState();
      const current = state.queues[kit as keyof typeof state.queues]?.currentTicket;
      await skipTicket({ actorId: user.id, actorName: user.username }, kit);
      if (interaction.guild_id && current) {
        const channel = await findChannel(interaction.guild_id, `ticket-${kit}-${current.player.username.toLowerCase().replace(/[^a-z0-9-]/g, "-").slice(0, 24)}`);
        if (channel) {
          await deleteQueueTicketChannel(channel.id).catch((error) => {
            logger.warn({ error, channelId: channel.id }, "Could not delete skipped queue ticket channel");
          });
          ticketChannelKits.delete(channel.id);
        }
      }
      await respond(interaction, `Ticket in **${kit}** skipped. The queue has moved forward.`);
      return;
    }
    if (name === "result") {
      const kit = await resolveKit(interaction);
      const tier = requiredOption(interaction, "tier");
      const state = await getState();
      const ticket = state.queues[kit as keyof typeof state.queues]?.currentTicket;
      if (!ticket) throw new Error("There is no open ticket for this kit.");
      const result = await submitResult({
        playerDiscordUserId: ticket.player.discordUserId,
        playerUsername: ticket.player.username,
        ign: ticket.player.ign,
        kit,
        tier,
        testerId: user.id,
        testerName: user.username,
        previousTier: ticket.player.currentTier || "N/A",
        region: ticket.player.region,
      });
      if (interaction.guild_id) {
        const resultsChannel = await findChannel(interaction.guild_id, "results");
        if (resultsChannel) {
          await postToChannel(
            resultsChannel.id,
            "",
            {
              embeds: [
                {
                  title: `♡ ${result.playerUsername} ♡ Test Results 🏆`,
                  description: `<@${result.playerDiscordUserId}>`,
                  color: 0x9b59b6,
                  thumbnail: {
                    url: `https://mc-heads.net/avatar/${encodeURIComponent(result.ign)}/128`,
                  },
                  fields: [
                    { name: "Tester", value: `<@${user.id}>` },
                    { name: "Region", value: result.region ?? "N/A" },
                    { name: "Username", value: result.ign },
                    { name: "Previous Rank", value: result.previousTier || "N/A" },
                    { name: "Rank Earned", value: result.tier.toUpperCase() },
                    { name: "Gamemode", value: KIT_LABELS[kit as keyof typeof KIT_LABELS] },
                  ],
                  footer: { text: "NexusTiers Test Results" },
                },
              ],
            },
          );
        }
      }
    if (interaction.guild_id) {
      await syncTierResultRole(interaction.guild_id, result, botUserId).catch((error) => {
        logger.warn({ error, guildId: interaction.guild_id, userId: result.playerDiscordUserId }, "Tier role synchronization failed");
      });
      const channel = await findChannel(
        interaction.guild_id,
        `ticket-${kit}-${ticket.player.username.toLowerCase().replace(/[^a-z0-9-]/g, "-").slice(0, 24)}`,
      );
      if (channel) {
        await deleteQueueTicketChannel(channel.id).catch((error) => {
          logger.warn({ error, channelId: channel.id }, "Could not delete completed queue ticket channel");
        });
        ticketChannelKits.delete(channel.id);
      }
    }
      await respond(interaction, `Result saved: **${result.ign}** earned **${result.tier}** in **${kit}**. The player and tester were mentioned in the result post.`);
      return;
    }
    if (name === "createchannel") {
      if (!interaction.guild_id) throw new Error("This command can only be used in a server.");
      const setup = await setupServer({ guildId: interaction.guild_id, actorId: user.id });
      await respond(interaction, setup.message);
      return;
    }
    await respond(interaction, "Unknown NexusTiers command.", true);
  } catch (error) {
    await respond(interaction, error instanceof Error ? error.message : "Command failed.", true);
  }
}

export function startDiscordBot() {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) {
    logger.warn("DISCORD_BOT_TOKEN is missing; Discord bot gateway is disabled.");
    return;
  }
  const WebSocketCtor = (globalThis as unknown as { WebSocket?: new (url: string) => GatewaySocket }).WebSocket;
  if (!WebSocketCtor) {
    logger.warn("WebSocket is unavailable; Discord bot gateway is disabled.");
    return;
  }
  const socket = new WebSocketCtor("wss://gateway.discord.gg/?v=10&encoding=json");
  let botUserId: string | undefined;
  socket.addEventListener("message", (event) => {
    if (typeof event.data !== "string") {
      logger.warn("Discord gateway sent a non-text payload; ignoring it");
      return;
    }
    const payload = JSON.parse(event.data) as {
      op: number;
      t?: string;
      d: { heartbeat_interval?: number; user?: { id: string } } & DiscordInteraction;
    };
    if (payload.op === 10) {
      const interval = payload.d.heartbeat_interval ?? 41250;
      setInterval(() => socket.send(JSON.stringify({ op: 1, d: null })), interval);
      socket.send(
        JSON.stringify({
          op: 2,
          d: {
            token,
            intents: 36867,
            properties: { os: "linux", browser: "NexusTiers", device: "NexusTiers" },
          },
        }),
      );
    }
    if (payload.op === 0 && payload.t === "READY") {
      const applicationId = payload.d.user?.id;
      botUserId = applicationId;
      if (applicationId) {
        registerCommands(applicationId).then(
          () => logger.info({ applicationId }, "NexusTiers slash commands registered"),
          (error) => logger.error({ error }, "Could not register NexusTiers slash commands"),
        );
      }
    }
    if (payload.op === 0 && payload.t === "INTERACTION_CREATE") {
      void handleInteraction(payload.d, botUserId);
    }
    if (payload.op === 0 && payload.t === "MESSAGE_CREATE") {
      void handleDirectMessage(payload.d as DiscordMessage);
    }
    if (payload.op === 0 && payload.t === "GUILD_MEMBER_ADD") {
      void handleGuildMemberAdd(payload.d as DiscordGuildMember, botUserId);
    }
    if (payload.op === 0 && payload.t === "GUILD_MEMBER_UPDATE") {
      void handleGuildMemberUpdate(payload.d as DiscordGuildMember, botUserId);
    }
  });
  socket.addEventListener("error", (event) => {
    logger.error({ error: event.error }, "Discord gateway socket error");
  });
  socket.addEventListener("close", (event) => {
    if (event.code === 4014) {
      logger.error(
        { code: event.code, reason: event.reason },
        "Discord rejected the gateway intents. Enable the Server Members Intent and Message Content Intent in the Discord Developer Portal.",
      );
      return;
    }
    logger.warn({ code: event.code, reason: event.reason }, "Discord gateway socket closed");
  });
  logger.info("NexusTiers Discord gateway started");
}