import { eq } from "drizzle-orm";
import { db, nexusStateTable } from "@workspace/db";
import {
  GetQueueParams,
  GetPlayerTiersParams,
  JoinQueueParams,
  OpenQueueParams,
  CloseQueueParams,
  NextTicketParams,
  SkipTicketParams,
  SetupServerBody,
  SubmitResultBody,
  VerifyAccountBody,
  ApplyWaitlistBody,
} from "@workspace/api-zod";
import { logger } from "./logger";

export const KITS = [
  "uhc",
  "sword",
  "mace",
  "diapot",
  "nethpot",
  "smp",
  "crystal",
  "axe",
  "cart",
] as const;
export type Kit = (typeof KITS)[number];
export const KIT_LABELS: Record<Kit, string> = {
  uhc: "UHC",
  sword: "Sword",
  mace: "Mace",
  diapot: "Diapot",
  nethpot: "NethPot",
  smp: "SMP",
  crystal: "Crystal",
  axe: "Axe",
  cart: "Cart",
};
export const TIERS = [
  "N/A",
  "lt5",
  "ht5",
  "lt4",
  "ht4",
  "lt3",
  "ht3",
  "lt2",
  "ht2",
  "lt1",
  "ht1",
] as const;

type Tier = (typeof TIERS)[number];
export type NexusCooldown = {
  discordUserId: string;
  minecraftUser: string;
  kit: Kit;
  startedAt: string;
  expiresAt: string;
  resultId?: string;
};
export type KitCooldownDurations = Record<Kit, number>;
type QueueEntry = {
  id: string;
  position: number;
  discordUserId: string;
  username: string;
  ign: string;
  currentTier: string;
  region: string;
  server: string;
  joinedAt: string;
};
type Tester = {
  discordUserId: string;
  username: string;
  region: string;
  active: boolean;
};
const SEEDED_TESTER_IDS = new Set(["733734885822431364", "1439980592191246376"]);
type Ticket = {
  id: string;
  kit: string;
  player: QueueEntry;
  tester: Tester;
  status: "open" | "skipped" | "completed";
  openedAt: string;
  channelId?: string;
};
type Queue = {
  kit: Kit;
  label: string;
  status: "open" | "closed";
  entries: QueueEntry[];
  activeTesters: Tester[];
  tickets: Ticket[];
  /** Legacy single-ticket field kept so older persisted state can migrate safely. */
  currentTicket: Ticket | null;
  lastUpdate: string;
};
type TierResult = {
  id: string;
  playerUsername: string;
  ign: string;
  kit: string;
  tier: string;
  previousTier: string;
  testerName: string;
  createdAt: string;
  discordMessage?: string;
  playerDiscordUserId?: string;
  region?: string;
  isEval?: boolean;
};
type ActivityItem = {
  id: string;
  title: string;
  description: string;
  timestamp: string;
  kind: "queue" | "ticket" | "result" | "setup" | "verification";
};
export type ApplicationType = "tester" | "staff";
export type ApplicationStatus = "in_progress" | "submitted" | "accepted" | "rejected" | "cancelled";
export type TicketType = "support" | "report" | "staff_report" | "high_tier";
export type TicketStatus = "open" | "closed";
export type NexusTicket = {
  id: string;
  guildId: string;
  channelId: string;
  creatorId: string;
  creatorUsername: string;
  type: TicketType;
  requestedTier?: string;
  kit?: string;
  minecraftUser?: string;
  reportedUser?: string;
  reason: string;
  evidence?: string;
  createdAt: string;
  claimedBy?: string;
  status: TicketStatus;
  closedAt?: string;
};
export type NexusApplication = {
  id: string;
  type: ApplicationType;
  status: ApplicationStatus;
  guildId: string;
  userId: string;
  username: string;
  kit?: string;
  answers: Record<string, string>;
  currentStep: number;
  dmChannelId?: string;
  applicationChannelId?: string;
  reviewChannelId?: string;
  reviewMessageId?: string;
  decisionBy?: string;
  decidedAt?: string;
  createdAt: string;
  updatedAt: string;
};
export type RestrictionStatus = "active" | "expired" | "unrestricted" | "permanent";
export type SavedRestrictionTier = {
  id: string;
  kit: string;
  tier: string;
};
export type NexusRestriction = {
  id: string;
  guildId: string;
  discordUserId: string;
  minecraftUser: string;
  previousRoleIds: string[];
  savedTierRoleIds: string[];
  savedTierIds: string[];
  savedTiers: SavedRestrictionTier[];
  duration: string;
  startTimestamp: string;
  endTimestamp?: string;
  reason: string;
  moderatorId: string;
  status: RestrictionStatus;
  unrestrictedTimestamp?: string;
  unrestrictedBy?: string;
};
export type NexusState = {
  queues: Record<Kit, Queue>;
  results: TierResult[];
  cooldowns: NexusCooldown[];
  cooldownDurations: KitCooldownDurations;
  verified: Array<{
    discordUserId: string;
    username: string;
    ign: string;
    verifiedAt: string;
  }>;
  activity: ActivityItem[];
  applications: NexusApplication[];
  applicationChannels: Record<string, { tester?: string; staff?: string }>;
  tickets: NexusTicket[];
  restrictions: NexusRestriction[];
};

const now = () => new Date().toISOString();
export const DEFAULT_KIT_COOLDOWN_MS = 3 * 24 * 60 * 60 * 1000;
const id = (prefix: string) =>
  `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;

function defaultCooldownDurations(): KitCooldownDurations {
  return Object.fromEntries(
    KITS.map((kit) => [kit, DEFAULT_KIT_COOLDOWN_MS]),
  ) as KitCooldownDurations;
}

function seedState(): NexusState {
  const queues = Object.fromEntries(
    KITS.map((kit) => {
      return [
        kit,
        {
          kit,
          label: KIT_LABELS[kit],
          status: kit === "uhc" ? "closed" : "open",
          entries: [],
          activeTesters: [],
          tickets: [],
          currentTicket: null,
          lastUpdate: now(),
        } satisfies Queue,
      ];
    }),
  ) as unknown as Record<Kit, Queue>;

  return {
    queues,
    cooldowns: [],
    cooldownDurations: defaultCooldownDurations(),
    verified: [
      {
        discordUserId: "733734885822431364",
        username: "Qloxyz_",
        ign: "Qloxyz_",
        verifiedAt: new Date(Date.now() - 86400000).toISOString(),
      },
    ],
    results: [
      {
        id: "seed_result_1",
        playerUsername: "Qloxyz_",
        ign: "Qloxyz_",
        kit: "sword",
        tier: "lt4",
        previousTier: "ht4",
        testerName: "Qloxyz_",
        createdAt: new Date(Date.now() - 86400000 * 3).toISOString(),
        discordMessage:
          "Qloxyz_'s Test Results — Tester: <@733734885822431364> — Region: EU — Previous Rank: High Tier 4 — Rank Earned: Low Tier 4",
        playerDiscordUserId: "733734885822431364",
        region: "EU",
      },
    ],
    activity: [
      {
        id: "seed_activity_1",
        title: "Crystal queue opened",
        description: "The Crystal waitlist is accepting players.",
        timestamp: new Date(Date.now() - 1000 * 60 * 8).toISOString(),
        kind: "queue",
      },
      {
        id: "seed_activity_2",
        title: "Result recorded",
        description: "Qloxyz_ received lt4 in Sword.",
        timestamp: new Date(Date.now() - 86400000 * 3).toISOString(),
        kind: "result",
      },
    ],
    applications: [],
    applicationChannels: {},
    tickets: [],
    restrictions: [],
  };
}

let cached: NexusState | null = null;
let saving: Promise<void> = Promise.resolve();

export async function getState(): Promise<NexusState> {
  if (cached) return cached;
  try {
    const rows = await db.select().from(nexusStateTable).where(eq(nexusStateTable.id, 1));
    cached = (rows[0]?.data as NexusState | undefined) ?? null;
  } catch (error) {
    logger.warn({ error }, "Nexus state database read failed; using memory");
  }
  if (!cached || !cached.queues) {
    cached = seedState();
    await saveState(cached);
  } else {
    let changed = false;
    if (!Array.isArray(cached.applications)) {
      cached.applications = [];
      changed = true;
    }
    if (!cached.applicationChannels || typeof cached.applicationChannels !== "object") {
      cached.applicationChannels = {};
      changed = true;
    }
    if (!Array.isArray(cached.tickets)) {
      cached.tickets = [];
      changed = true;
    }
    if (!Array.isArray(cached.restrictions)) {
      cached.restrictions = [];
      changed = true;
    }
    if (!Array.isArray(cached.cooldowns)) {
      cached.cooldowns = [];
      changed = true;
    }
    if (!cached.cooldownDurations || typeof cached.cooldownDurations !== "object") {
      cached.cooldownDurations = defaultCooldownDurations();
      changed = true;
    } else {
      for (const kit of KITS) {
        const duration = cached.cooldownDurations[kit];
        if (typeof duration !== "number" || !Number.isSafeInteger(duration) || duration <= 0) {
          cached.cooldownDurations[kit] = DEFAULT_KIT_COOLDOWN_MS;
          changed = true;
        }
      }
    }
    for (const queue of Object.values(cached.queues)) {
      if (!Array.isArray(queue.tickets)) {
        queue.tickets = queue.currentTicket ? [queue.currentTicket] : [];
        queue.currentTicket = null;
        changed = true;
      }
      const realEntries = queue.entries.filter((entry) => !entry.id.startsWith("seed_"));
      if (realEntries.length !== queue.entries.length) {
        queue.entries = realEntries;
        normalizePositions(queue);
        changed = true;
      }
      const realTesters = queue.activeTesters.filter((tester) => !SEEDED_TESTER_IDS.has(tester.discordUserId));
      if (realTesters.length !== queue.activeTesters.length) {
        queue.activeTesters = realTesters;
        changed = true;
      }
    }
    if (changed) await saveState(cached);
  }
  return cached;
}

export async function createTicket(input: Omit<NexusTicket, "status">) {
  const state = await getState();
  const ticket: NexusTicket = {
    ...input,
    status: "open",
  };
  state.tickets.unshift(ticket);
  await saveState(state);
  return ticket;
}

export async function updateTicket(
  ticketId: string,
  patch: Partial<Omit<NexusTicket, "id" | "guildId" | "creatorId" | "createdAt">>,
) {
  const state = await getState();
  const ticket = state.tickets.find((item) => item.id === ticketId);
  if (!ticket) throw new Error("Ticket not found.");
  Object.assign(ticket, patch);
  await saveState(state);
  return ticket;
}

export function ticketForChannel(state: NexusState, channelId: string) {
  return state.tickets.find((ticket) => ticket.channelId === channelId);
}

export function queueTicketForChannel(state: NexusState, channelId: string) {
  for (const queue of Object.values(state.queues)) {
    const ticket = queue.tickets.find((candidate) => candidate.channelId === channelId);
    if (ticket) return ticket;
  }
  return null;
}

export async function setQueueTicketChannel(ticketId: string, channelId: string) {
  const state = await getState();
  for (const queue of Object.values(state.queues)) {
    const ticket = queue.tickets.find((candidate) => candidate.id === ticketId);
    if (ticket) {
      ticket.channelId = channelId;
      await saveState(state);
      return ticket;
    }
  }
  throw new Error("Queue ticket not found.");
}

export function saveState(state: NexusState): Promise<void> {
  cached = state;
  saving = saving
    .catch(() => undefined)
    .then(async () => {
      try {
        await db
          .insert(nexusStateTable)
          .values({ id: 1, data: state })
          .onConflictDoUpdate({
            target: nexusStateTable.id,
            set: { data: state, updatedAt: new Date() },
          });
      } catch (error) {
        logger.warn({ error }, "Nexus state database write failed; keeping memory");
      }
    });
  return saving;
}

export async function createApplication(input: {
  type: ApplicationType;
  guildId: string;
  userId: string;
  username: string;
  applicationChannelId?: string;
}) {
  const state = await getState();
  const timestamp = now();
  const application: NexusApplication = {
    id: id("application"),
    ...input,
    status: "in_progress",
    answers: {},
    currentStep: -1,
    createdAt: timestamp,
    updatedAt: timestamp,
  };
  state.applications.unshift(application);
  await saveState(state);
  return application;
}

export async function updateApplication(
  applicationId: string,
  patch: Partial<Omit<NexusApplication, "id" | "type" | "guildId" | "userId" | "createdAt">>,
) {
  const state = await getState();
  const application = state.applications.find((item) => item.id === applicationId);
  if (!application) throw new Error("Application not found.");
  Object.assign(application, patch, { updatedAt: now() });
  await saveState(state);
  return application;
}

export function normalizePositions(queue: Queue) {
  queue.entries.forEach((entry, index) => {
    entry.position = index + 1;
  });
}

export function getQueue(state: NexusState, kit: string): Queue | undefined {
  return KITS.includes(kit as Kit) ? state.queues[kit as Kit] : undefined;
}

export function queueOverview(queue: Queue) {
  return {
    kit: queue.kit,
    label: queue.label,
    status: queue.status,
    count: queue.entries.length,
    max: 20,
    activeTesters: queue.activeTesters.length,
    channelName: `${queue.kit}-waitlist`,
    lastUpdate: queue.lastUpdate,
  };
}

function normalizeMinecraftUser(minecraftUser: string | undefined) {
  return minecraftUser?.trim().toLowerCase();
}

function cooldownMatchesPlayer(
  cooldown: NexusCooldown,
  discordUserId: string | undefined,
  minecraftUser: string | undefined,
) {
  const normalizedMinecraftUser = normalizeMinecraftUser(minecraftUser);
  return (
    (Boolean(discordUserId) && cooldown.discordUserId === discordUserId) ||
    (Boolean(normalizedMinecraftUser) &&
      cooldown.minecraftUser.trim().toLowerCase() === normalizedMinecraftUser)
  );
}

export function getKitCooldownDurationMs(state: NexusState, kit: Kit) {
  return state.cooldownDurations?.[kit] ?? DEFAULT_KIT_COOLDOWN_MS;
}

export function findActiveKitCooldown(
  state: NexusState,
  kit: Kit,
  discordUserId?: string,
  minecraftUser?: string,
) {
  const timestamp = Date.now();
  return state.cooldowns.find(
    (cooldown) =>
      cooldown.kit === kit &&
      new Date(cooldown.expiresAt).getTime() > timestamp &&
      cooldownMatchesPlayer(cooldown, discordUserId, minecraftUser),
  );
}

export function assertKitCooldownAvailable(
  state: NexusState,
  kit: Kit,
  discordUserId?: string,
  minecraftUser?: string,
) {
  const activeCooldown = findActiveKitCooldown(state, kit, discordUserId, minecraftUser);
  if (activeCooldown) {
    const discordTimestamp = Math.floor(new Date(activeCooldown.expiresAt).getTime() / 1000);
    throw new Error(
      `You cannot use the ${KIT_LABELS[kit]} kit yet. Your cooldown ends <t:${discordTimestamp}:R>.`,
    );
  }
}

function normalizedKit(kitValue: string): Kit {
  const kit = kitValue.trim().toLowerCase();
  if (!KITS.includes(kit as Kit)) {
    throw new Error(`Unknown kit: ${kitValue}. Allowed kits: ${KITS.join(", ")}.`);
  }
  return kit as Kit;
}

export async function setKitCooldownDuration(kitValue: string, durationMs: number) {
  const kit = normalizedKit(kitValue);
  if (!Number.isSafeInteger(durationMs) || durationMs <= 0) {
    throw new Error("Cooldown duration must be a positive whole number of milliseconds.");
  }
  const state = await getState();
  state.cooldownDurations[kit] = durationMs;
  await saveState(state);
  return { kit, durationMs };
}

export async function removeKitCooldown(input: {
  discordUserId: string;
  minecraftUser: string;
  kit: string;
}) {
  const kit = normalizedKit(input.kit);
  const state = await getState();
  const normalizedMinecraftUser = normalizeMinecraftUser(input.minecraftUser);
  const cooldownIndex = state.cooldowns.findIndex(
    (cooldown) =>
      cooldown.kit === kit &&
      cooldown.discordUserId === input.discordUserId &&
      cooldown.minecraftUser.trim().toLowerCase() === normalizedMinecraftUser,
  );
  if (cooldownIndex === -1) return null;
  const [removed] = state.cooldowns.splice(cooldownIndex, 1);
  await saveState(state);
  return removed;
}

function addActivity(
  state: NexusState,
  title: string,
  description: string,
  kind: ActivityItem["kind"],
) {
  state.activity.unshift({ id: id("activity"), title, description, timestamp: now(), kind });
  state.activity = state.activity.slice(0, 30);
}

const TIER_POINTS: Record<string, number> = {
  ht1: 60,
  lt1: 45,
  ht2: 30,
  lt2: 20,
  ht3: 10,
  lt3: 6,
  ht4: 4,
  lt4: 3,
  ht5: 2,
  lt5: 1,
};

function tierRank(tier: string) {
  const match = tier.toLowerCase().match(/^(?:lt|ht)([1-7])$/);
  if (!match) return 999;
  return Number(match[1]) * 2 + (tier.toLowerCase().startsWith("lt") ? 1 : 0);
}

function latestResultsByPlayerAndKit(results: TierResult[]) {
  const latest = new Map<string, TierResult>();
  for (const result of results) {
    const key = `${result.ign.trim().toLowerCase()}::${result.kit}`;
    const current = latest.get(key);
    if (!current || new Date(result.createdAt).getTime() > new Date(current.createdAt).getTime()) {
      latest.set(key, result);
    }
  }
  return Array.from(latest.values());
}

function isActiveRestriction(restriction: NexusRestriction) {
  return restriction.status === "active" || restriction.status === "permanent";
}

export function activeRestrictionForDiscord(
  state: NexusState,
  discordUserId: string | undefined,
) {
  if (!discordUserId) return undefined;
  return state.restrictions.find(
    (restriction) =>
      restriction.discordUserId === discordUserId && isActiveRestriction(restriction),
  );
}

export function activeRestrictionForMinecraft(
  state: NexusState,
  minecraftUser: string | undefined,
) {
  const normalized = minecraftUser?.trim().toLowerCase();
  if (!normalized) return undefined;
  return state.restrictions.find(
    (restriction) =>
      restriction.minecraftUser.trim().toLowerCase() === normalized &&
      isActiveRestriction(restriction),
  );
}

export function isDiscordUserRestricted(state: NexusState, discordUserId: string | undefined) {
  return Boolean(activeRestrictionForDiscord(state, discordUserId));
}

export function isMinecraftUserRestricted(state: NexusState, minecraftUser: string | undefined) {
  return Boolean(activeRestrictionForMinecraft(state, minecraftUser));
}

export function findActiveRestriction(
  state: NexusState,
  guildId: string,
  discordUserId: string,
  minecraftUser: string,
) {
  const normalizedMinecraftUser = minecraftUser.trim().toLowerCase();
  return state.restrictions.find(
    (restriction) =>
      restriction.guildId === guildId &&
      restriction.discordUserId === discordUserId &&
      restriction.minecraftUser.trim().toLowerCase() === normalizedMinecraftUser &&
      isActiveRestriction(restriction),
  );
}

export async function createRestriction(input: {
  guildId: string;
  discordUserId: string;
  minecraftUser: string;
  previousRoleIds: string[];
  savedTierRoleIds: string[];
  duration: string;
  endTimestamp?: string;
  reason: string;
  moderatorId: string;
}) {
  const state = await getState();
  if (
    activeRestrictionForDiscord(state, input.discordUserId) ||
    activeRestrictionForMinecraft(state, input.minecraftUser)
  ) {
    throw new Error("This user is already restricted.");
  }

  const savedTiers = latestResultsByPlayerAndKit(state.results)
    .filter(
      (result) =>
        result.ign.trim().toLowerCase() === input.minecraftUser.trim().toLowerCase(),
    )
    .map((result) => ({
      id: result.id,
      kit: result.kit,
      tier: result.tier,
    }));
  const timestamp = now();
  const restriction: NexusRestriction = {
    id: id("restriction"),
    guildId: input.guildId,
    discordUserId: input.discordUserId,
    minecraftUser: input.minecraftUser.trim(),
    previousRoleIds: [...input.previousRoleIds],
    savedTierRoleIds: [...input.savedTierRoleIds],
    savedTierIds: savedTiers.map((tier) => tier.id),
    savedTiers,
    duration: input.duration.trim(),
    startTimestamp: timestamp,
    ...(input.endTimestamp ? { endTimestamp: input.endTimestamp } : {}),
    reason: input.reason.trim(),
    moderatorId: input.moderatorId,
    status: input.endTimestamp ? "active" : "permanent",
  };
  state.restrictions.unshift(restriction);
  addActivity(
    state,
    `${restriction.minecraftUser} was restricted`,
    `${restriction.duration} • ${restriction.reason}`,
    "verification",
  );
  await saveState(state);
  return restriction;
}

export async function getDueRestrictions() {
  const state = await getState();
  const timestamp = Date.now();
  return state.restrictions.filter(
    (restriction) =>
      restriction.status === "active" &&
      restriction.endTimestamp &&
      new Date(restriction.endTimestamp).getTime() <= timestamp,
  );
}

export async function completeRestriction(
  restrictionId: string,
  status: "expired" | "unrestricted",
  actorId: string,
) {
  const state = await getState();
  const restriction = state.restrictions.find((item) => item.id === restrictionId);
  if (!restriction) throw new Error("Restriction not found.");
  restriction.status = status;
  if (status === "unrestricted") {
    restriction.unrestrictedTimestamp = now();
    restriction.unrestrictedBy = actorId;
  }
  addActivity(
    state,
    status === "expired" ? `${restriction.minecraftUser} restriction expired` : `${restriction.minecraftUser} restriction removed`,
    status === "expired" ? "The saved Discord roles and tiers were restored automatically." : `Restriction removed by ${actorId}.`,
    "verification",
  );
  await saveState(state);
  return restriction;
}

export async function getLeaderboard() {
  const state = await getState();
  const players = new Map<string, {
    username: string;
    ign: string;
    points: number;
    results: number;
    bestTier: string;
    lastResult: string;
    region?: string;
    kits: string[];
    tiers: Array<{ kit: Kit; tier: string }>;
  }>();
  for (const result of latestResultsByPlayerAndKit(state.results)) {
    if (isMinecraftUserRestricted(state, result.ign)) continue;
    const key = result.ign.trim().toLowerCase();
    const isRankedResult = result.isEval !== true;
    const current = players.get(key) ?? {
      username: result.playerUsername,
      ign: result.ign,
      points: 0,
      results: 0,
      bestTier: "N/A",
      lastResult: result.createdAt,
      kits: [],
      tiers: [],
    };
    if (isRankedResult) {
      current.points += TIER_POINTS[result.tier.toLowerCase()] ?? 0;
      current.results += 1;
    }
    if (!current.kits.includes(result.kit)) {
      current.kits.push(result.kit);
      current.tiers.push({ kit: result.kit as Kit, tier: result.tier });
    }
    if (isRankedResult && tierRank(result.tier) < tierRank(current.bestTier)) current.bestTier = result.tier;
    if (new Date(result.createdAt).getTime() > new Date(current.lastResult).getTime()) current.lastResult = result.createdAt;
    if (!current.region || new Date(result.createdAt).getTime() >= new Date(current.lastResult).getTime()) current.region = result.region;
    players.set(key, current);
  }
  return Array.from(players.values())
    .filter((player) => player.results > 0)
    .sort((a, b) => b.points - a.points || b.results - a.results || a.ign.localeCompare(b.ign))
    .map((player, index) => ({ ...player, rank: index + 1 }));
}
export async function getKitRanking(kitValue: string) {
  if (!KITS.includes(kitValue as Kit)) throw new Error("Unknown kit");
  const kit = kitValue as Kit;
  const state = await getState();
  const latestForKit = latestResultsByPlayerAndKit(state.results).filter(
    (result) => result.kit === kit && !isMinecraftUserRestricted(state, result.ign),
  );

  const tiers = Array.from({ length: 5 }, (_, index) => ({
    tier: index + 1,
    players: [] as Array<{ ign: string; username: string; tier: string; region?: string; createdAt: string }>,
  }));

  for (const result of latestForKit) {
    const match = result.tier.toLowerCase().match(/^(?:ht|lt)([1-5])$/);
    if (!match) continue;
    tiers[Number(match[1]) - 1].players.push({
      ign: result.ign,
      username: result.playerUsername,
      tier: result.tier.toLowerCase(),
      region: result.region,
      createdAt: result.createdAt,
    });
  }

  for (const column of tiers) {
    column.players.sort((a, b) => tierRank(a.tier) - tierRank(b.tier) || a.ign.localeCompare(b.ign));
  }

  return { kit, label: KIT_LABELS[kit], totalPlayers: latestForKit.length, tiers };
}
export async function openQueue(input: unknown, kitValue: string) {
  const kit = OpenQueueParams.parse({ kit: kitValue }).kit as Kit;
  const queue = (await getState()).queues[kit];
  const actor = input as { actorId?: string; actorName?: string };
  const reopeningClosedQueue = queue.status === "closed";
  if (reopeningClosedQueue) {
    queue.entries = [];
    queue.activeTesters = [];
    queue.tickets = [];
    queue.currentTicket = null;
  }
  queue.activeTesters = queue.activeTesters.filter((tester) => !SEEDED_TESTER_IDS.has(tester.discordUserId));
  if (actor.actorId && !queue.activeTesters.some((tester) => tester.discordUserId === actor.actorId)) {
    queue.activeTesters.push({
      discordUserId: actor.actorId,
      username: actor.actorName ?? "Tester",
      region: "N/A",
      active: true,
    });
  }
  queue.status = "open";
  queue.lastUpdate = now();
  const state = await getState();
  addActivity(state, `${queue.label} queue opened`, "Players can join the waitlist.", "queue");
  await saveState(state);
  return queue;
}

/** Add a user to the tester queue only; player queue entries are untouched. */
export async function joinTester(input: unknown, kitValue: string) {
  const kit = OpenQueueParams.parse({ kit: kitValue }).kit as Kit;
  const actor = input as { actorId?: string; actorName?: string };
  if (!actor.actorId) throw new Error("Could not identify the tester.");

  const state = await getState();
  const queue = state.queues[kit];
  if (queue.status !== "open") throw new Error(`The ${queue.label} queue is closed.`);
  if (queue.activeTesters.some((tester) => tester.discordUserId === actor.actorId)) {
    throw new Error(`You are already an active tester for the ${queue.label} queue.`);
  }

  queue.activeTesters.push({
    discordUserId: actor.actorId,
    username: actor.actorName ?? "Tester",
    region: "N/A",
    active: true,
  });
  queue.lastUpdate = now();
  addActivity(state, `${actor.actorName ?? "Tester"} joined the ${queue.label} tester queue`, "The tester queue changed; player queue entries were not changed.", "queue");
  await saveState(state);
  return queue;
}

export async function closeQueue(_input: unknown, kitValue: string) {
  const kit = CloseQueueParams.parse({ kit: kitValue }).kit as Kit;
  const state = await getState();
  const queue = state.queues[kit];
  queue.status = "closed";
  queue.lastUpdate = now();
  addActivity(state, `${queue.label} queue closed`, "The waitlist is no longer accepting entries.", "queue");
  await saveState(state);
  return queue;
}

export async function nextTicket(input: unknown, kitValue: string) {
  const kit = NextTicketParams.parse({ kit: kitValue }).kit as Kit;
  const state = await getState();
  const queue = state.queues[kit];
  const actor = input as { actorId?: string };
  const player = queue.entries[0];
  const tester = actor.actorId
    ? queue.activeTesters.find((activeTester) => activeTester.discordUserId === actor.actorId)
    : queue.activeTesters[0];
  if (!player || !tester) throw new Error("No queued player or active tester is available.");
  const ticket: Ticket = {
    id: id("ticket"),
    kit,
    player,
    tester,
    status: "open",
    openedAt: now(),
  };
  queue.tickets.push(ticket);
  queue.entries.shift();
  normalizePositions(queue);
  queue.lastUpdate = now();
  addActivity(state, `Ticket opened for ${player.username}`, `${queue.label} • tester ${tester.username}`, "ticket");
  await saveState(state);
  return ticket;
}

export async function skipTicket(input: unknown, kitValue: string) {
  const kit = SkipTicketParams.parse({ kit: kitValue }).kit as Kit;
  const state = await getState();
  const queue = state.queues[kit];
  const data = input as { actorId?: string; ticketId?: string };
  const ticketIndex = data.ticketId
    ? queue.tickets.findIndex((ticket) => ticket.id === data.ticketId)
    : queue.tickets.findIndex((ticket) => ticket.tester.discordUserId === data.actorId);
  if (ticketIndex === -1) throw new Error("There is no active ticket.");
  queue.tickets[ticketIndex].status = "skipped";
  queue.tickets.splice(ticketIndex, 1);
  queue.lastUpdate = now();
  addActivity(state, `Ticket skipped in ${queue.label}`, "The player was removed from the queue when the ticket opened.", "ticket");
  await saveState(state);
  return queue;
}

export async function joinQueue(input: unknown, kitValue: string) {
  const kit = JoinQueueParams.parse({ kit: kitValue }).kit as Kit;
  const data = ApplyWaitlistBody.parse(input);
  const state = await getState();
  if (
    isDiscordUserRestricted(state, data.discordUserId) ||
    isMinecraftUserRestricted(state, data.ign)
  ) {
    throw new Error("You cannot join the whitelist while you are restricted.");
  }
  assertKitCooldownAvailable(state, kit, data.discordUserId, data.ign);
  const queue = state.queues[kit];
  if (queue.status !== "open") throw new Error("This queue is closed.");
  if (queue.entries.length >= 20) throw new Error("This queue is full.");
  if (queue.entries.some((entry) => entry.discordUserId === data.discordUserId)) {
    throw new Error("This player is already in the queue.");
  }
  if (queue.tickets.some((ticket) => ticket.player.discordUserId === data.discordUserId)) {
    throw new Error("This player already has an open ticket.");
  }
  const entry: QueueEntry = {
    id: id("entry"),
    position: queue.entries.length + 1,
    discordUserId: data.discordUserId,
    username: data.username,
    ign: data.ign,
    currentTier: data.currentTier,
    region: data.region,
    server: data.server,
    joinedAt: now(),
  };
  queue.entries.push(entry);
  queue.lastUpdate = now();
  addActivity(state, `${data.username} joined ${queue.label}`, `Position ${entry.position} • ${data.region}`, "queue");
  await saveState(state);
  return entry;
}

export async function leaveQueue(input: unknown, kitValue: string) {
  const kit = JoinQueueParams.parse({ kit: kitValue }).kit as Kit;
  const data = input as { discordUserId?: string; username?: string };
  if (!data.discordUserId) throw new Error("Could not identify the Discord user.");

  const state = await getState();
  const queue = state.queues[kit];
  const entryIndex = queue.entries.findIndex((entry) => entry.discordUserId === data.discordUserId);
  if (entryIndex === -1) {
    throw new Error(`You are not in the ${queue.label} queue.`);
  }

  const [entry] = queue.entries.splice(entryIndex, 1);
  normalizePositions(queue);
  queue.lastUpdate = now();
  addActivity(
    state,
    `${entry.username} left ${queue.label}`,
    `Removed from queue position ${entryIndex + 1}.`,
    "queue",
  );
  await saveState(state);
  return { entry, queue, previousPosition: entryIndex + 1 };
}

/** Remove a user from the tester queue only; player queue entries are untouched. */
export async function leaveTester(input: unknown, kitValue: string) {
  const kit = JoinQueueParams.parse({ kit: kitValue }).kit as Kit;
  const data = input as { actorId?: string; actorName?: string };
  if (!data.actorId) throw new Error("Could not identify the tester.");

  const state = await getState();
  const queue = state.queues[kit];
  const testerIndex = queue.activeTesters.findIndex((tester) => tester.discordUserId === data.actorId);
  if (testerIndex === -1) throw new Error(`You are not an active tester for the ${queue.label} queue.`);
  if (queue.tickets.some((ticket) => ticket.tester.discordUserId === data.actorId)) {
    throw new Error("You have an open ticket. Finish it with `/result` or `/skip` before leaving.");
  }

  const [tester] = queue.activeTesters.splice(testerIndex, 1);
  queue.lastUpdate = now();
  addActivity(state, `${tester.username} left the ${queue.label} tester queue`, "The tester queue changed; player queue entries were not changed.", "queue");
  await saveState(state);
  return { tester, queue };
}

export async function verifyAccount(input: unknown) {
  const data = VerifyAccountBody.parse(input);
  const state = await getState();
  if (isDiscordUserRestricted(state, data.discordUserId)) {
    throw new Error("You cannot verify your Minecraft account while you are restricted.");
  }
  const verified = { ...data, verifiedAt: now() };
  state.verified = [
    verified,
    ...state.verified.filter((item) => item.discordUserId !== data.discordUserId),
  ];
  addActivity(state, `${data.username} verified`, `Minecraft account ${data.ign} linked.`, "verification");
  await saveState(state);
  return verified;
}

export async function clearPlayerTiers(ignValue: string) {
  const ign = ignValue.trim().toLowerCase();
  if (!ign) throw new Error("A Minecraft username is required.");

  const state = await getState();
  if (isMinecraftUserRestricted(state, ign)) {
    throw new Error("Tier data cannot be changed while this player is restricted.");
  }
  const removed = state.results.filter((result) => result.ign.trim().toLowerCase() === ign);
  state.results = state.results.filter((result) => !removed.includes(result));
  await saveState(state);
  return { removedCount: removed.length };
}

export async function setManualTiers(input: {
  ign: string;
  playerUsername: string;
  tiers: Array<{ kit: string; tier: string }>;
  assignedBy: string;
}) {
  const ign = input.ign.trim();
  const playerUsername = input.playerUsername.trim();
  if (!ign) throw new Error("A Minecraft username is required.");
  if (!playerUsername) throw new Error("A Discord name is required.");
  if (input.tiers.length === 0) throw new Error("At least one tier is required.");

  const state = await getState();
  if (isMinecraftUserRestricted(state, ign)) {
    throw new Error("Tier data cannot be changed while this player is restricted.");
  }
  const createdAt = now();
  const results: TierResult[] = [];

  for (const assignment of input.tiers) {
    const kit = assignment.kit.trim().toLowerCase();
    const tier = assignment.tier.trim().toLowerCase();
    if (!KITS.includes(kit as Kit)) throw new Error(`Unknown kit: ${assignment.kit}.`);
    if (!TIERS.includes(tier as Tier)) throw new Error(`Unknown tier: ${assignment.tier}.`);

    const previousTier =
      state.results.find(
        (result) => result.ign.trim().toLowerCase() === ign.toLowerCase() && result.kit === kit,
      )?.tier ?? "N/A";
    const result: TierResult = {
      id: id("manual-result"),
      playerUsername,
      ign,
      kit,
      tier,
      previousTier,
      testerName: input.assignedBy,
      createdAt,
      discordMessage: `${playerUsername}'s manual tier assignment — ${KIT_LABELS[kit as Kit]}: ${tier}`,
      region: "N/A",
    };
    state.results.unshift(result);
    results.push(result);
  }

  addActivity(
    state,
    `${ign} received manual tiers`,
    `${results.map((result) => `${KIT_LABELS[result.kit as Kit]} ${result.tier}`).join(", ")} • assigned by ${input.assignedBy}`,
    "result",
  );
  await saveState(state);
  return results;
}

export async function submitResult(input: unknown) {
  const data = SubmitResultBody.parse(input);
  const state = await getState();
  if (
    isDiscordUserRestricted(state, data.playerDiscordUserId) ||
    isMinecraftUserRestricted(state, data.ign)
  ) {
    throw new Error("Tier results cannot be recorded while this player is restricted.");
  }
  const kit = data.kit as Kit;
  const queue = state.queues[kit];
  const result: TierResult = {
    id: id("result"),
    playerUsername: data.playerUsername,
    ign: data.ign,
    kit,
    tier: data.tier,
    previousTier: data.previousTier,
    testerName: data.testerName,
    createdAt: now(),
    playerDiscordUserId: data.playerDiscordUserId,
    region: data.region,
    isEval: data.isEval === true,
  };
  result.discordMessage = [
    `${data.playerUsername}'s Test Results`,
    `Tester: <@${data.testerId}>`,
    `Region: ${data.region ?? "N/A"}`,
    `Username: ${data.ign}`,
    `Previous Rank: ${data.previousTier || "N/A"}`,
    `Rank Earned: ${data.tier}`,
  ].join("\n");
  state.results.unshift(result);
  const startedAt = now();
  const cooldownDurationMs = getKitCooldownDurationMs(state, kit);
  state.cooldowns = state.cooldowns.filter(
    (cooldown) =>
      !(
        cooldown.kit === kit &&
        cooldownMatchesPlayer(cooldown, data.playerDiscordUserId, data.ign)
      ),
  );
  state.cooldowns.unshift({
    discordUserId: data.playerDiscordUserId,
    minecraftUser: data.ign.trim(),
    kit,
    startedAt,
    expiresAt: new Date(Date.now() + cooldownDurationMs).toISOString(),
    resultId: result.id,
  });
  const dataTicketId = data.ticketId;
  const ticketIndex = dataTicketId
    ? queue.tickets.findIndex((ticket) => ticket.id === dataTicketId)
    : queue.tickets.findIndex((ticket) => ticket.player.ign.toLowerCase() === data.ign.toLowerCase());
  if (ticketIndex !== -1) {
    queue.tickets[ticketIndex].status = "completed";
    queue.tickets.splice(ticketIndex, 1);
    queue.lastUpdate = now();
  }
  addActivity(state, `${data.ign} received ${data.tier}`, `${KIT_LABELS[kit]} result by ${data.testerName}.`, "result");
  await saveState(state);
  return result;
}

export async function playerProfile(ignValue: string) {
  const ign = GetPlayerTiersParams.parse({ ign: ignValue }).ign;
  const state = await getState();
  if (isMinecraftUserRestricted(state, ign)) return null;
  const tiers = latestResultsByPlayerAndKit(state.results).filter((result) => result.ign.toLowerCase() === ign.toLowerCase());
  const rank = (tier: string) => (tier === "N/A" ? 999 : Number(tier.slice(2)) * 2 + (tier.startsWith("lt") ? 1 : 0));
  const sortedTiers = tiers.filter((result) => result.isEval !== true).sort((a, b) => rank(a.tier) - rank(b.tier));
  const bestTier = sortedTiers[0]?.tier ?? "N/A";
  const leaderboard = await getLeaderboard();
  const player = leaderboard.find((entry) => entry.ign.toLowerCase() === ign.toLowerCase());
  const newest = [...tiers].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())[0];
  return {
    ign,
    username: newest?.playerUsername ?? ign,
    bestTier,
    position: player?.rank ?? null,
    points: player?.points ?? 0,
    results: player?.results ?? 0,
    region: newest?.region ?? null,
    tiers: [...tiers].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()),
  };
}

const TIER_NAMES = ["lt5", "ht5", "lt4", "ht4", "lt3", "ht3", "lt2", "ht2", "lt1", "ht1"];
const TIER_ROLE_COLORS: Record<string, number> = {
  lt5: 0x95a5a6,
  ht5: 0x7f8c8d,
  lt4: 0x2ecc71,
  ht4: 0x27ae60,
  lt3: 0x3498db,
  ht3: 0x2980b9,
  lt2: 0x9b59b6,
  ht2: 0x8e44ad,
  lt1: 0xf1c40f,
  ht1: 0xe74c3c,
};
type SetupChannel = {
  key: string;
  name: string;
  type?: 0 | 2;
  category: string;
  topic?: string;
};

type SetupCategory = {
  key: string;
  name: string;
};

const setupCategories: SetupCategory[] = [
  { key: "important", name: "Important" },
  { key: "tierlist", name: "Tierlist" },
  { key: "special-partners", name: "Special Partners" },
  { key: "community", name: "Community" },
  { key: "request-test-help", name: "Request Test & Help" },
  { key: "waitlist", name: "Waitlist" },
  { key: "tickets", name: "Tickets" },
];

const setupChannels: SetupChannel[] = [
  { key: "rules", name: "📕・rules", category: "important", topic: "NexusTiers server rules." },
  { key: "announcements", name: "📢・announcements", category: "important" },
  { key: "polls", name: "📊・polls", category: "important" },
  { key: "partnerships", name: "🤝・partnerships", category: "important" },
  { key: "mini-announcements", name: "📢・mini-announcements", category: "important" },
  { key: "levelling-info", name: "📰・levelling-info", category: "important" },

  { key: "staff-movements", name: "💥・staff-movements", category: "tierlist" },
  { key: "punishments", name: "⛔・punishments", category: "tierlist" },
  { key: "tierlist-website", name: "📌・tierlist-website", category: "tierlist" },
  { key: "testing-servers", name: "🎟️・testing-servers", category: "tierlist" },
  { key: "kit-information", name: "📚・kit-information", category: "tierlist" },
  { key: "testing-mods", name: "📄・testing-mods", category: "tierlist" },
  { key: "high-results", name: "🏆・high-results", category: "tierlist" },
  { key: "results", name: "🏆・results", category: "tierlist", topic: "NexusTiers test results." },

  { key: "waifly-hosting", name: "🏆・waifly-hosting", category: "special-partners" },

  { key: "general", name: "💬・general", category: "community" },
  { key: "media", name: "📸・media", category: "community" },
  { key: "commands", name: "🤖・commands", category: "community" },
  { key: "matchmaking", name: "📢・matchmaking", category: "community" },
  { key: "general-voice", name: "🔊・General", type: 2, category: "community" },
  { key: "general-2-voice", name: "🔊・General 2", type: 2, category: "community" },
  { key: "screenshare", name: "🔊・Screenshare", type: 2, category: "community" },
  { key: "screenshare-2", name: "🔊・Screenshare 2", type: 2, category: "community" },

  { key: "request-test", name: "📩・request-test", category: "request-test-help", topic: "Request a NexusTiers test." },
  { key: "request-support", name: "📫・request-support", category: "request-test-help" },
  { key: "high-test", name: "📩・high-test", category: "request-test-help" },
  { key: "tester-applications", name: "💼・tester-applications", category: "request-test-help" },
  { key: "staff-applications", name: "💼・staff-applications", category: "request-test-help" },

  { key: "nexus", name: "🌐・nexus", category: "waitlist" },
  { key: "uhc-waitlist", name: "⚔️・uhc-waitlist", category: "waitlist" },
  { key: "sword-waitlist", name: "🗡️・sword-waitlist", category: "waitlist" },
  { key: "mace-waitlist", name: "🔨・mace-waitlist", category: "waitlist" },
  { key: "diapot-waitlist", name: "🧪・diapot-waitlist", category: "waitlist" },
  { key: "nethpot-waitlist", name: "🧪・nethpot-waitlist", category: "waitlist" },
  { key: "smp-waitlist", name: "🌍・smp-waitlist", category: "waitlist" },
  { key: "crystal-waitlist", name: "💎・crystal-waitlist", category: "waitlist" },
  { key: "axe-waitlist", name: "🪓・axe-waitlist", category: "waitlist" },

  { key: "tickets", name: "🎫・tickets", category: "tickets", topic: "NexusTiers active tester tickets." },
];
async function discordRequest(path: string, init: RequestInit = {}) {
  const token = process.env.DISCORD_BOT_TOKEN;
  if (!token) throw new Error("DISCORD_BOT_TOKEN is not configured.");
  const response = await fetch(`https://discord.com/api/v10${path}`, {
    ...init,
    headers: {
      Authorization: `Bot ${token}`,
      "Content-Type": "application/json",
      ...(init.headers ?? {}),
    },
  });
  if (!response.ok) throw new Error(`Discord API ${response.status}: ${await response.text()}`);
  return response.status === 204 ? null : response.json();
}

export async function setupServer(input: unknown) {
  const data = SetupServerBody.parse(input);
  const [channels, roles] = await Promise.all([
    discordRequest(`/guilds/${data.guildId}/channels`),
    discordRequest(`/guilds/${data.guildId}/roles`),
  ]) as [
    Array<{ name: string; id: string; type?: number; parent_id?: string | null }>,
    Array<{ name: string; id: string; hoist?: boolean; managed?: boolean; color?: number }>,
  ];
  const createdChannels: string[] = [];
  const categoryIds = new Map<string, string>();

  for (const category of setupCategories) {
    let existing = channels.find(
      (channel) =>
        channel.type === 4 &&
        (channel.name === category.name || channel.name === category.key),
    );
    if (!existing) {
      existing = (await discordRequest(`/guilds/${data.guildId}/channels`, {
        method: "POST",
        body: JSON.stringify({ name: category.name, type: 4 }),
      })) as { name: string; id: string; type?: number; parent_id?: string | null };
      createdChannels.push(category.name);
    } else if (existing.name !== category.name) {
      await discordRequest(`/channels/${existing.id}`, {
        method: "PATCH",
        body: JSON.stringify({ name: category.name }),
      });
    }
    categoryIds.set(category.key, existing.id);
  }

  for (const channel of setupChannels) {
    const parentId = categoryIds.get(channel.category);
    if (!parentId) continue;
    let existing = channels.find(
      (candidate) =>
        candidate.type === (channel.type ?? 0) &&
        (candidate.name === channel.name ||
          candidate.name === channel.key ||
          candidate.name.endsWith(`・${channel.key}`)),
    );
    if (!existing) {
      existing = (await discordRequest(`/guilds/${data.guildId}/channels`, {
        method: "POST",
        body: JSON.stringify({
          name: channel.name,
          type: channel.type ?? 0,
          parent_id: parentId,
          ...(channel.topic ? { topic: channel.topic } : {}),
        }),
      })) as { name: string; id: string; type?: number; parent_id?: string | null };
      createdChannels.push(channel.name);
    } else {
      const patch: Record<string, string | number> = {};
      if (existing.name !== channel.name) patch.name = channel.name;
      if (existing.parent_id !== parentId) patch.parent_id = parentId;
      if (channel.topic && channel.type !== 2) patch.topic = channel.topic;
      if (Object.keys(patch).length > 0) {
        await discordRequest(`/channels/${existing.id}`, {
          method: "PATCH",
          body: JSON.stringify(patch),
        });
      }
    }
  }
  const desiredRoles = [
    { name: "NexusTiers", color: 0, hoist: true },
    { name: "Verified Tester", color: 0, hoist: true },
    { name: "Restricted", color: 0xed4245, hoist: true },
    ...TIER_NAMES.flatMap((tier) =>
      KITS.map((kit) => ({
        name: `${tier.toUpperCase()} ${KIT_LABELS[kit]}`,
        color: TIER_ROLE_COLORS[tier],
        hoist: true,
      })),
    ),
  ];
  const createdRoles: string[] = [];
  for (const desired of desiredRoles) {
    const existingRole = roles.find((role) => role.name.toLowerCase() === desired.name.toLowerCase());
    if (existingRole) {
      if (
        !existingRole.managed &&
        (existingRole.name !== desired.name ||
          existingRole.hoist !== desired.hoist ||
          existingRole.color !== desired.color)
      ) {
        await discordRequest(`/guilds/${data.guildId}/roles/${existingRole.id}`, {
          method: "PATCH",
          body: JSON.stringify({
            name: desired.name,
            color: desired.color,
            hoist: desired.hoist,
            mentionable: false,
          }),
        });
      }
      continue;
    }
    await discordRequest(`/guilds/${data.guildId}/roles`, {
      method: "POST",
      body: JSON.stringify({
        name: desired.name,
        color: desired.color,
        hoist: desired.hoist,
        mentionable: false,
      }),
    });
    createdRoles.push(desired.name);
  }
  const state = await getState();
  addActivity(state, "Discord server setup complete", `${createdChannels.length} channels and ${createdRoles.length} roles created.`, "setup");
  await saveState(state);
  return {
    guildId: data.guildId,
    createdChannels,
    createdRoles,
    message: `NexusTiers setup complete: ${createdChannels.length} channels and ${createdRoles.length} roles created.`,
  };
}

export async function discordApi(path: string, init: RequestInit = {}) {
  return discordRequest(path, init);
}