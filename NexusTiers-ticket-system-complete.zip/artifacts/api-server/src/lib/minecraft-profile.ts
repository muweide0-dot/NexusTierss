export type MinecraftProfile = {
  uuid: string;
  name: string;
};

const USERNAME_PATTERN = /^[A-Za-z0-9_]{3,16}$/;
const UUID_PATTERN = /^[a-f0-9]{32}$/;

export function normalizeMinecraftUuid(value: string | undefined): string | null {
  const normalized = value?.replace(/-/g, "").trim().toLowerCase();
  return normalized && UUID_PATTERN.test(normalized) ? normalized : null;
}

function parseProfile(value: unknown): MinecraftProfile | null {
  if (!value || typeof value !== "object") return null;
  const data = value as { id?: unknown; name?: unknown };
  const uuid = normalizeMinecraftUuid(typeof data.id === "string" ? data.id : undefined);
  const name = typeof data.name === "string" ? data.name : "";
  if (!uuid || !USERNAME_PATTERN.test(name)) return null;
  return { uuid, name };
}

export async function getMinecraftProfileByName(ign: string): Promise<MinecraftProfile | null> {
  const username = ign.trim();
  if (!USERNAME_PATTERN.test(username)) return null;
  try {
    const response = await fetch(
      "https://api.mojang.com/users/profiles/minecraft/" + encodeURIComponent(username),
      { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(8_000) },
    );
    if (response.status === 204 || response.status === 404 || !response.ok) return null;
    return parseProfile(await response.json());
  } catch {
    return null;
  }
}

export async function getMinecraftProfileByUuid(uuid: string): Promise<MinecraftProfile | null> {
  const normalizedUuid = normalizeMinecraftUuid(uuid);
  if (!normalizedUuid) return null;
  try {
    const response = await fetch(
      "https://sessionserver.mojang.com/session/minecraft/profile/" + normalizedUuid,
      { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(8_000) },
    );
    if (response.status === 204 || response.status === 404 || !response.ok) return null;
    return parseProfile(await response.json());
  } catch {
    return null;
  }
}
