import { logger } from "./logger";
import {
  getMinecraftProfileByName,
  getMinecraftProfileByUuid,
  normalizeMinecraftUuid,
  type MinecraftProfile,
} from "./minecraft-profile";
import { getState, saveState } from "./nexus";

const SYNC_INTERVAL_MS = 6 * 60 * 60 * 1000;
const REQUEST_INTERVAL_MS = 1_000;
const INITIAL_SYNC_DELAY_MS = 15_000;

let syncRunning = false;
let scheduledRun: ReturnType<typeof setTimeout> | null = null;

function delay(milliseconds: number) {
  return new Promise((resolve) => setTimeout(resolve, milliseconds));
}

export async function syncMinecraftNames() {
  if (syncRunning) return { skipped: true, checked: 0, namesUpdated: 0, recordsLinked: 0 };
  syncRunning = true;
  try {
    const state = await getState();
    let changed = false;
    let namesUpdated = 0;
    let recordsLinked = 0;
    if (!Array.isArray(state.verified)) {
      state.verified = [];
      changed = true;
    }
    if (!Array.isArray(state.results)) {
      state.results = [];
      changed = true;
    }

    const byNameCache = new Map<string, Promise<MinecraftProfile | null>>();
    const byUuidCache = new Map<string, Promise<MinecraftProfile | null>>();
    let lastRequestAt = 0;
    const throttled = async (request: () => Promise<MinecraftProfile | null>) => {
      const wait = Math.max(0, lastRequestAt + REQUEST_INTERVAL_MS - Date.now());
      if (wait > 0) await delay(wait);
      lastRequestAt = Date.now();
      return request();
    };
    const profileByName = (name: string) => {
      const key = name.trim().toLowerCase();
      if (!key) return Promise.resolve(null);
      let lookup = byNameCache.get(key);
      if (!lookup) {
        lookup = throttled(() => getMinecraftProfileByName(name));
        byNameCache.set(key, lookup);
      }
      return lookup;
    };
    const profileByUuid = (uuid: string) => {
      const key = normalizeMinecraftUuid(uuid);
      if (!key) return Promise.resolve(null);
      let lookup = byUuidCache.get(key);
      if (!lookup) {
        lookup = throttled(() => getMinecraftProfileByUuid(key));
        byUuidCache.set(key, lookup);
      }
      return lookup;
    };

    for (const account of state.verified) {
      const storedUuid = normalizeMinecraftUuid(account.minecraftUuid);
      if (storedUuid && account.minecraftUuid !== storedUuid) {
        account.minecraftUuid = storedUuid;
        changed = true;
      }
      const profile = storedUuid
        ? await profileByUuid(storedUuid)
        : await profileByName(account.ign);
      if (!profile) continue;
      if (account.minecraftUuid !== profile.uuid) {
        account.minecraftUuid = profile.uuid;
        recordsLinked += 1;
        changed = true;
      }
      if (account.ign !== profile.name) {
        account.ign = profile.name;
        namesUpdated += 1;
        changed = true;
      }
    }

    const verifiedByDiscordId = new Map<string, (typeof state.verified)[number]>();
    for (const account of state.verified) {
      verifiedByDiscordId.set(account.discordUserId, account);
    }
    for (const result of state.results) {
      const storedUuid = normalizeMinecraftUuid(result.minecraftUuid);
      let profile: MinecraftProfile | null = null;
      if (storedUuid) {
        if (result.minecraftUuid !== storedUuid) {
          result.minecraftUuid = storedUuid;
          changed = true;
        }
        profile = await profileByUuid(storedUuid);
      } else {
        const linkedAccount = result.playerDiscordUserId
          ? verifiedByDiscordId.get(result.playerDiscordUserId)
          : undefined;
        const linkedUuid = normalizeMinecraftUuid(linkedAccount?.minecraftUuid);
        if (linkedUuid) {
          result.minecraftUuid = linkedUuid;
          recordsLinked += 1;
          changed = true;
          profile = await profileByUuid(linkedUuid);
        } else {
          profile = await profileByName(result.ign);
          if (profile) {
            result.minecraftUuid = profile.uuid;
            recordsLinked += 1;
            changed = true;
          }
        }
      }
      if (!profile) continue;
      if (result.minecraftUuid !== profile.uuid) {
        result.minecraftUuid = profile.uuid;
        changed = true;
      }
      if (result.ign !== profile.name) {
        result.ign = profile.name;
        namesUpdated += 1;
        changed = true;
      }
    }

    if (changed) await saveState(state);
    const summary = {
      skipped: false,
      checked: byNameCache.size + byUuidCache.size,
      namesUpdated,
      recordsLinked,
    };
    logger.info(summary, "Minecraft username sync completed.");
    return summary;
  } catch (error) {
    logger.error({ error }, "Minecraft username sync failed.");
    throw error;
  } finally {
    syncRunning = false;
  }
}

export function startMinecraftNameSync() {
  if (scheduledRun) return;
  const run = async () => {
    try {
      await syncMinecraftNames();
    } catch {
      // The next scheduled pass retries transient profile-service failures.
    }
    scheduledRun = setTimeout(run, SYNC_INTERVAL_MS);
    scheduledRun.unref?.();
  };
  scheduledRun = setTimeout(run, INITIAL_SYNC_DELAY_MS);
  scheduledRun.unref?.();
  logger.info({ intervalHours: 6 }, "Minecraft username sync scheduled.");
}
