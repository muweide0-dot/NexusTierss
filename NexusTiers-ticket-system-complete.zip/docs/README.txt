NexusTiers all-in-one bundle
Includes the complete uploaded project tree plus the Discord application requirements.
