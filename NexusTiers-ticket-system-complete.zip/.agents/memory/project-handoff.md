---
name: Project handoff files
description: Uploaded project files may remain under the conversation workspace after moving into a project.
---

When a conversation is moved into a project, uploaded files can be preserved under `.local/conversation-workspace/files` instead of being merged into the project root. Restoring generated workspace libraries may also require rebuilding their TypeScript declarations before leaf-package typechecks.

**Why:** The generated project may contain only a starter scaffold, so starting its workflow before copying the uploaded source can run the wrong application.

**How to apply:** If an uploaded archive is the requested application, inspect `.local/conversation-workspace/files` after handoff and merge the relevant source into the project before restarting its workflow; run the library declaration build before checking dependent packages.